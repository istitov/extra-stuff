package xtpipes;
/* XtpipesPrintWriter.java (2026-05-28-12:27), generated from xtpipes.tex
   Copyright (C) 2009-2010 TeX Users Group
   Copyright (C) 2002-2009 Eitan M. Gurari
%
% This work may be distributed and/or modified under the
% conditions of the LaTeX Project Public License, either
% version 1.3c of this license or (at your option) any
% later version. The latest version of this license is in
%   https://www.latex-project.org/lppl.txt
% and version 1.3c or later is part of all distributions
% of LaTeX version 2005/12/01 or later.
%
% This work has the LPPL maintenance status "maintained".
%
% The Current Maintainer of this work
% is the TeX4ht Project <https://tug.org/tex4ht>.
%
% If you modify this program, changing the
% version identification would be appreciated. */
import java.io.*;
public class XtpipesPrintWriter extends PrintWriter {
   public XtpipesPrintWriter() {
     super(System.out, true);
   }
   public XtpipesPrintWriter (PrintStream ps, boolean b){
     super(ps, b);
   }
   public XtpipesPrintWriter (OutputStream ps, boolean b){
     super(ps, b);
   }
   public XtpipesPrintWriter (FileWriter fw){
     super(fw);
   }
   public XtpipesPrintWriter (Writer wr){
     super(wr);
   }
   public void print(String str) {
     super.print( XtpipesUni.toUni(str, "") );
   }
   public void println(String str) {
     super.println( XtpipesUni.toUni(str, "") );
}  }

