package tex4ht;
/* JsmlFilter.java (2026-05-28-12:26), generated from tex4ht-jsml-xtpipes.tex
   Copyright (C) 2009-2010 TeX Users Group
   Copyright (C) 2002-2009 Eitan M. Gurari
%
% This work may be distributed and/or modified under the
% conditions of the LaTeX Project Public License, either
% version 1.3c of this license or (at your option) any
% later version. The latest version of this license is in
%   https://www.latex-project.org/lppl.txt
% and version 1.3c or later is part of all distributions
% of LaTeX version 2005/12/01 or later.
%
% This work has the LPPL maintenance status "maintained".
%
% The Current Maintainer of this work
% is the TeX4ht Project <https://tug.org/tex4ht>.
%
% If you modify this program, changing the
% version identification would be appreciated. */
import org.xml.sax.helpers.*;
import org.xml.sax.*;
import java.io.PrintWriter;

public class JsmlFilter extends XMLFilterImpl {
     PrintWriter out = null;
   public JsmlFilter( PrintWriter out, PrintWriter log, boolean trace ){
     this.out = out;
   }
   public void startElement(String ns, String sName,
                           String qName, Attributes attr) {
      try{
        if(    qName.equals( "p" )
|| qName.equals( "h2" )
|| qName.equals( "h3" )
|| qName.equals( "h4" )
|| qName.equals( "ul" )
|| qName.equals( "ol" )
|| qName.equals( "li" )
|| qName.equals( "dd" )
|| qName.equals( "dl" )
 ){
          Attributes att = new AttributesImpl();
          super.startElement(ns, "PARA", "PARA", att);
        }
        super.startElement(ns, sName, qName, attr);
      } catch( Exception e ){
        System.out.println( "--- JsmlFilter Error 1 --- " + e);
   }  }
   public void endElement(String ns, String sName, String qName){
      try{
        super.endElement(ns, sName, qName);
        if(    qName.equals( "p" )
|| qName.equals( "h2" )
|| qName.equals( "h3" )
|| qName.equals( "h4" )
|| qName.equals( "ul" )
|| qName.equals( "ol" )
|| qName.equals( "li" )
|| qName.equals( "dd" )
|| qName.equals( "dl" )
 ){
             super.endElement(ns, "PARA", "PARA");
        }
      } catch( Exception e ){
        System.out.println( "--- JsmlFilter Error 2 --- " + e);
}  }  }

