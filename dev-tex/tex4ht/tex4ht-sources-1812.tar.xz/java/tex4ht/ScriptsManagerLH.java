/* ScriptsManagerLH.java (2026-05-28-12:27), generated from xtpipes.tex
   Copyright (C) 2009-2010 TeX Users Group
   Copyright (C) 2002-2009 Eitan M. Gurari
%
% This work may be distributed and/or modified under the
% conditions of the LaTeX Project Public License, either
% version 1.3c of this license or (at your option) any
% later version. The latest version of this license is in
%   https://www.latex-project.org/lppl.txt
% and version 1.3c or later is part of all distributions
% of LaTeX version 2005/12/01 or later.
%
% This work has the LPPL maintenance status "maintained".
%
% The Current Maintainer of this work
% is the TeX4ht Project <https://tug.org/tex4ht>.
%
% If you modify this program, changing the
% version identification would be appreciated. */
package xtpipes.util;
import org.xml.sax.ext.LexicalHandler;
// import org.xml.sax.ContentHandler;
import java.io.PrintWriter;
public class ScriptsManagerLH implements LexicalHandler {
       ScriptsManager contentHandler;
       PrintWriter log;
   public ScriptsManagerLH( ScriptsManager contentHandler,
                          PrintWriter log, boolean trace ){
     this.contentHandler = contentHandler;
     this.log = (log==null)? new PrintWriter( System.err ) : log;
   }
   public void comment(char[] ch, int start, int length){
     if( contentHandler.inBody ){
        String s = new String(ch, start, length);
        contentHandler.add(  "<!--" + s + "\n-->");
   } }
   public void startEntity(String x){}
   public void endEntity(String x){}
   public void startCDATA(){}
   public void endCDATA(){}
   public void startDTD(String x, String y, String z){}
   public void endDTD(){}
}

