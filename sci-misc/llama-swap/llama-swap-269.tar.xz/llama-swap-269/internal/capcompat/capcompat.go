// Package capcompat discovers what an upstream inference server can do and
// maps the answer onto llama-swap's model capabilities.
//
// Every supported server exposes /v1/models, and the owned_by field in that
// listing identifies the server family. Detect fetches the listing once, picks
// the matching Prober, and lets it query whatever else it needs. A server
// nobody recognises is not an error worth shouting about: llama-swap also
// fronts image, speech and transcription servers that have no capability
// surface at all.
//
// The data is only readable while the server is running, so callers cache what
// Detect returns. See Service.
package capcompat

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/mostlygeek/llama-swap/internal/config"
	"github.com/mostlygeek/llama-swap/internal/hint"
	"github.com/mostlygeek/llama-swap/internal/logmon"
)

// ErrUnsupportedUpstream is returned by Detect when no prober recognises the
// server. It is an expected outcome, not a failure to report loudly.
var ErrUnsupportedUpstream = errors.New("capcompat: unsupported upstream")

// Info is what Detect produces and what callers cache.
type Info struct {
	// Upstream is the server family that answered, e.g. "llama-server".
	Upstream hint.Upstream `json:"upstream"`
	// Capabilities is the discovered subset. Fields a server cannot report
	// are left at their zero value, never guessed.
	Capabilities config.ModelCapConfig `json:"capabilities"`
	// DetectedAt is when the probe ran.
	DetectedAt time.Time `json:"detected_at"`
}

// ModelEntry is one record of an OpenAI-compatible /v1/models listing. It
// carries the union of the fields the supported servers add to the standard
// shape; a server that omits one leaves it at its zero value.
type ModelEntry struct {
	ID      string `json:"id"`
	Object  string `json:"object"`
	OwnedBy string `json:"owned_by"`

	// MaxModelLen is vLLM's context length for this entry. Halogen reports
	// it too.
	MaxModelLen int `json:"max_model_len"`
	// ContextLength is the same number under the name Halogen also publishes.
	ContextLength int `json:"context_length"`
	// MaxContext is the name yamz publishes.
	MaxContext int `json:"max_context"`
	// Root and Parent are vLLM's adapter lineage. A LoRA adapter has a
	// non-empty Parent naming the base model it is served on top of.
	Root   string `json:"root"`
	Parent string `json:"parent"`

	// Architecture is llama-server's modality block for this entry.
	Architecture struct {
		OutputModalities []string `json:"output_modalities"`
	} `json:"architecture"`

	// Meta is the model metadata block llama-server and Halogen both use.
	Meta struct {
		// NCtx is the context actually loaded. NCtxTrain is the model's
		// training limit, which is usually larger and is never a capability.
		NCtx      int `json:"n_ctx"`
		NCtxTrain int `json:"n_ctx_train"`
		NParams   int `json:"n_params"`
	} `json:"meta"`
}

// ContextTokens returns the usable context length this entry reports, or 0
// when it reports none.
//
// Servers spell it differently, so the names are tried in order of how
// specific they are: max_model_len, then context_length, then max_context,
// then meta.n_ctx. meta.n_ctx_train is deliberately excluded. It is what the model was trained
// for, not what the server loaded, and advertising it would promise a window
// the server will refuse to fill.
func (e ModelEntry) ContextTokens() int {
	switch {
	case e.MaxModelLen > 0:
		return e.MaxModelLen
	case e.ContextLength > 0:
		return e.ContextLength
	case e.MaxContext > 0:
		return e.MaxContext
	default:
		return e.Meta.NCtx
	}
}

// listingOnlyCaps builds capabilities for a server whose model listing is the
// only thing it exposes to this package: text in and out, plus whatever
// context length the matched entry reports.
//
// Find skips adapter entries, whose context belongs to the adapter rather
// than to the base model being served.
func listingOnlyCaps(models ModelsResponse, modelName string) config.ModelCapConfig {
	caps := config.ModelCapConfig{
		In:  []string{"text"},
		Out: []string{"text"},
	}
	if entry, found := models.Find(modelName); found {
		caps.Context = entry.ContextTokens()
	}
	return caps
}

// ModelsResponse is an OpenAI-compatible /v1/models listing.
type ModelsResponse struct {
	Object string       `json:"object"`
	Data   []ModelEntry `json:"data"`
}

// OwnedBy returns the owner reported by the listing. Servers report it per
// entry rather than at the top level, so the first non-empty value wins.
func (m ModelsResponse) OwnedBy() string {
	for _, entry := range m.Data {
		if owner := strings.TrimSpace(entry.OwnedBy); owner != "" {
			return owner
		}
	}
	return ""
}

// Find returns the entry for modelName, or the best stand-in when the name
// does not appear. Servers are free to list a model under a path, an alias or
// a name the client never sees, so an exact miss falls back to the first
// entry that is not an adapter of another model.
func (m ModelsResponse) Find(modelName string) (ModelEntry, bool) {
	name := strings.TrimSpace(modelName)
	if name != "" {
		for _, entry := range m.Data {
			if entry.ID == name {
				return entry, true
			}
		}
	}
	for _, entry := range m.Data {
		if entry.Parent == "" {
			return entry, true
		}
	}
	if len(m.Data) > 0 {
		return m.Data[0], true
	}
	return ModelEntry{}, false
}

// Prober knows one upstream server family: how to recognise it from its model
// listing, and what else to ask it.
type Prober interface {
	// Name identifies the prober in log and error messages.
	Name() string

	// Upstream names the server family behind a matching listing, and is
	// stored in Info.Upstream. One prober can cover several families.
	Upstream(models ModelsResponse) hint.Upstream

	// Matches reports whether the listing came from this family.
	Matches(models ModelsResponse) bool

	// Probe maps the server's answers onto capabilities. It may issue more
	// requests through c. Fields the server cannot report are left unset.
	Probe(ctx context.Context, c *Client, models ModelsResponse, modelName string) (config.ModelCapConfig, error)
}

// defaultProbers is the registry Detect consults, in order.
func defaultProbers() []Prober {
	return []Prober{llamaServerProber{}, halogenProber{}, defaultProber{}}
}

// Detect identifies the upstream behind c and returns what it reports about
// modelName. modelName is the name the upstream knows the model by, which is
// useModelName when set and the llama-swap model ID otherwise; it only matters
// for servers that list more than one model.
//
// It returns ErrUnsupportedUpstream when no prober recognises the server.
func Detect(ctx context.Context, c *Client, modelName string) (Info, error) {
	var models ModelsResponse
	if err := c.GetJSON(ctx, "/v1/models", &models); err != nil {
		return Info{}, fmt.Errorf("capcompat: reading model list: %w", err)
	}

	for _, prober := range defaultProbers() {
		if !prober.Matches(models) {
			continue
		}
		caps, err := prober.Probe(ctx, c, models, modelName)
		if err != nil {
			return Info{}, fmt.Errorf("capcompat: probing %s: %w", prober.Name(), err)
		}
		if err := caps.Validate(); err != nil {
			return Info{}, fmt.Errorf("capcompat: %s reported invalid capabilities: %w", prober.Name(), err)
		}
		return Info{
			Upstream:     prober.Upstream(models),
			Capabilities: caps,
			DetectedAt:   time.Now(),
		}, nil
	}

	owner := models.OwnedBy()
	if owner == "" {
		owner = "unknown"
	}
	return Info{}, fmt.Errorf("%w (owned_by %q)", ErrUnsupportedUpstream, owner)
}

// Client performs GET requests against one upstream server.
type Client struct {
	base       *url.URL
	httpClient *http.Client
	headers    http.Header
	logger     *logmon.Monitor
}

// maxResponseBytes caps how much of an upstream response is read. /props
// carries a full chat template and is comfortably under this; anything
// larger is not a response this package knows how to use.
const maxResponseBytes = 8 << 20

// NewClient returns a Client for base, honouring the model's proxy timeouts.
// A zero timeout in the config means no timeout, matching the rest of
// llama-swap, but the overall request deadline still comes from the context.
// logger receives the warnings a probe logs when a field it reads is
// missing or of the wrong type; nil is fine, the probe just stays quiet.
func NewClient(base *url.URL, timeouts config.TimeoutsConfig, logger *logmon.Monitor) *Client {
	transport := &http.Transport{
		Proxy: http.ProxyFromEnvironment,
		// Same dialer settings the model's own reverse proxy transport uses,
		// so a probe respects timeouts.connect instead of hanging on a dial
		// until the probe deadline.
		DialContext: (&net.Dialer{
			Timeout:   time.Duration(timeouts.Connect) * time.Second,
			KeepAlive: time.Duration(timeouts.KeepAlive) * time.Second,
		}).DialContext,
		TLSHandshakeTimeout:   time.Duration(timeouts.TLSHandshake) * time.Second,
		ResponseHeaderTimeout: time.Duration(timeouts.ResponseHeader) * time.Second,
		ExpectContinueTimeout: time.Duration(timeouts.ExpectContinue) * time.Second,
		IdleConnTimeout:       time.Duration(timeouts.IdleConn) * time.Second,
	}
	return &Client{
		base:       base,
		httpClient: &http.Client{Transport: transport},
		headers:    http.Header{},
		logger:     logger,
	}
}

// SetHeader sets a header sent with every request, such as an API key.
func (c *Client) SetHeader(key, value string) {
	if c == nil || value == "" {
		return
	}
	c.headers.Set(key, value)
}

// Warnf logs a warning about this upstream's answers. The probe continues
// with the degraded value; the warning exists so a skipped field is visible
// in the proxy log.
func (c *Client) Warnf(format string, args ...any) {
	if c == nil || c.logger == nil {
		return
	}
	c.logger.Warnf(format, args...)
}

// GetBody fetches path relative to the client's base URL and returns the
// response body. A non-2xx response is an error carrying the status.
func (c *Client) GetBody(ctx context.Context, path string) ([]byte, error) {
	target := c.base.JoinPath(path)

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, target.String(), nil)
	if err != nil {
		return nil, fmt.Errorf("building %s request: %w", path, err)
	}
	req.Header.Set("Accept", "application/json")
	for key, values := range c.headers {
		for _, value := range values {
			req.Header.Add(key, value)
		}
	}

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("requesting %s: %w", path, err)
	}
	defer resp.Body.Close()

	if resp.StatusCode < 200 || resp.StatusCode > 299 {
		io.Copy(io.Discard, io.LimitReader(resp.Body, 4096))
		return nil, fmt.Errorf("requesting %s: upstream returned %s", path, resp.Status)
	}

	body, err := io.ReadAll(io.LimitReader(resp.Body, maxResponseBytes))
	if err != nil {
		return nil, fmt.Errorf("reading %s: %w", path, err)
	}
	return body, nil
}

// GetJSON fetches path relative to the client's base URL and decodes the
// body into v. A non-2xx response is an error carrying the status.
func (c *Client) GetJSON(ctx context.Context, path string, v any) error {
	body, err := c.GetBody(ctx, path)
	if err != nil {
		return err
	}
	if err := json.Unmarshal(body, v); err != nil {
		return fmt.Errorf("decoding %s: %w", path, err)
	}
	return nil
}
