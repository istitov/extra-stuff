package capcompat

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/mostlygeek/llama-swap/internal/config"
	"github.com/mostlygeek/llama-swap/internal/hint"
	"github.com/mostlygeek/llama-swap/internal/logmon"
)

// The fixtures under testdata/ are built from the documented response shapes:
// llama.cpp's tools/server/README.md for /props and /v1/models, its
// common/jinja/caps.h for the chat_template_caps key names, and vLLM's
// OpenAI-compatible model listing. They are not captures from a live server.
// Before relying on the tools mapping in production, re-capture props.json and
// props_vision.json from real builds and confirm supports_tools actually
// differs between a tool-capable model and a plain completion model; several
// of those flags are initialised to true in llama.cpp's C++ struct.
//
// The exceptions are real captures. props_capture.json,
// v1_models_capture.json and v1_models_capture_qwen.json come from running
// llama-servers, and confirm the modality key set (vision, video, audio).
//
// The first two are from DIFFERENT servers and are only paired in a test to
// exercise the code path: 262144 in that listing is not an integer multiple
// of 220160 in that /props, so llama.cpp could not have produced both from
// one process. Do not read a conclusion about one server out of that pair.
// v1_models_capture.json was also truncated in transit inside its meta
// block; the fields after n_params were dropped rather than invented, and
// the prober does not read them.
//
// v1_models_capture_qwen.json is complete and self-consistent, which is why
// the n_ctx assertions live there.
//
// vllm/v1_models_capture.json is also a verbatim capture. The other vllm
// file, with its LoRA adapter entry, is still synthetic.
//
// The halogen fixtures are the exception: v1_models.json and health.json are
// verbatim captures from a running halogen-flash-server. The two other
// halogen files are that same capture with vision turned off, and with the
// supported list and tool-call block removed, to cover builds configured
// differently. Their derivation is noted where they are used.
//
// gufo/v1_models.json is a verbatim capture from a running Gufo instance
// (AMD Strix Halo gfx1151).
//
// yamz/v1_models.json is the /v1/models response of a yamz (kyojin) server, as
// supplied by a user.
//
// v1_models_capture_clef.json and props_capture_clef.json are one capture from
// a single llama-server (b11429) serving the Clef-Flash decision model. The
// listing is verbatim; the /props file keeps only modalities,
// default_generation_settings and chat_template_caps.

// props_capture_b12017.json is a /props from a newer llama-server (b12017),
// keeping only modalities, default_generation_settings and
// chat_template_caps. Its chat_template_caps mixes types: the supports_*
// keys are booleans, but reasoning_effort_levels is a list. Older code that
// decoded chat_template_caps as map[string]bool rejected the whole response.

// fixture reads a testdata file.
func fixture(t *testing.T, parts ...string) []byte {
	t.Helper()
	data, err := os.ReadFile(filepath.Join(append([]string{"testdata"}, parts...)...))
	require.NoError(t, err)
	return data
}

// upstream is a fake inference server. routes maps a path to a fixture body;
// any path not in the map answers 404.
type upstream struct {
	server *httptest.Server
	hits   map[string]int
}

func newUpstream(t *testing.T, routes map[string][]byte) *upstream {
	t.Helper()
	u := &upstream{hits: map[string]int{}}
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		u.hits[r.URL.Path]++
		body, ok := routes[r.URL.Path]
		if !ok {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.Write(body)
	})
	u.server = httptest.NewServer(mux)
	t.Cleanup(u.server.Close)
	return u
}

func (u *upstream) client(t *testing.T) *Client {
	t.Helper()
	base, err := url.Parse(u.server.URL)
	require.NoError(t, err)
	return NewClient(base, config.TimeoutsConfig{}, nil)
}

// clientWithLogger is like client but with the warnings a probe logs for a
// degraded /props captured in log, for tests that assert on them.
func (u *upstream) clientWithLogger(t *testing.T, log *logmon.Monitor) *Client {
	t.Helper()
	base, err := url.Parse(u.server.URL)
	require.NoError(t, err)
	return NewClient(base, config.TimeoutsConfig{}, log)
}

func TestCapcompat_DetectLlamaServer(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "llama-server", "v1_models.json"),
		"/props":     fixture(t, "llama-server", "props.json"),
	})

	info, err := Detect(context.Background(), up.client(t), "model-a")
	require.NoError(t, err)

	assert.Equal(t, hint.LlamaServer, info.Upstream)
	assert.Equal(t, []string{"text"}, info.Capabilities.In)
	assert.Equal(t, []string{"text"}, info.Capabilities.Out)
	assert.True(t, info.Capabilities.Tools)
	assert.Equal(t, 32768, info.Capabilities.Context, "uses the loaded n_ctx, not n_ctx_train")
	assert.False(t, info.Capabilities.Reranker, "reranker is not discoverable")
	assert.False(t, info.DetectedAt.IsZero())
}

func TestCapcompat_DetectLlamaServerVision(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "llama-server", "v1_models.json"),
		"/props":     fixture(t, "llama-server", "props_vision.json"),
	})

	info, err := Detect(context.Background(), up.client(t), "model-a")
	require.NoError(t, err)

	assert.Equal(t, []string{"text", "image"}, info.Capabilities.In)
	assert.Equal(t, []string{"text"}, info.Capabilities.Out)
	assert.False(t, info.Capabilities.Tools, "template reports no tool support")
	assert.Equal(t, 8192, info.Capabilities.Context)
}

// A decision model answers /v1/systemone and generates no text. Only the
// listing says so, through output_modalities; /props looks like a chat model
// and even reports tool support from its chat template.
func TestCapcompat_DetectLlamaServerDecisionModel(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "llama-server", "v1_models_capture_clef.json"),
		"/props":     fixture(t, "llama-server", "props_capture_clef.json"),
	})

	info, err := Detect(context.Background(), up.client(t), "Clef-Flash-Q8_0")
	require.NoError(t, err)

	assert.Equal(t, []string{"text", "image", "video"}, info.Capabilities.In)
	assert.Equal(t, []string{"decisions"}, info.Capabilities.Out)
	assert.False(t, info.Capabilities.Tools, "no text output, so no tool calls")
	assert.Equal(t, 16384, info.Capabilities.Context)
}

func TestCapcompat_DetectLlamaServerIgnoresUnmappedModalities(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "llama-server", "v1_models.json"),
		"/props":     fixture(t, "llama-server", "props_omni.json"),
	})

	info, err := Detect(context.Background(), up.client(t), "model-a")
	require.NoError(t, err)

	// This fixture reports the three real modality keys plus a made up one.
	// All three map; the unrecognised key must be dropped rather than passed
	// through, where it would fail ModelCapConfig.Validate.
	assert.Equal(t, []string{"text", "image", "audio", "video"}, info.Capabilities.In)
	require.NoError(t, info.Capabilities.Validate())
}

func TestCapcompat_DetectLlamaServerCapture(t *testing.T) {
	// Verbatim from running llama-servers. A text-only build reports all
	// three modality keys as false, which is what confirmed their names.
	//
	// These two files are from different servers, so the only thing the
	// context assertion below shows is that the prober reads /props and not
	// the listing. It is not evidence about any one deployment.
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "llama-server", "v1_models_capture.json"),
		"/props":     fixture(t, "llama-server", "props_capture.json"),
	})

	info, err := Detect(context.Background(), up.client(t), "gemma")
	require.NoError(t, err)

	assert.Equal(t, hint.LlamaServer, info.Upstream)
	assert.Equal(t, []string{"text"}, info.Capabilities.In)
	assert.Equal(t, 220160, info.Capabilities.Context, "context comes from /props")
}

func TestCapcompat_LlamaServerListingNeverUsesTrainingContext(t *testing.T) {
	// A complete capture where the two listing fields disagree: the server
	// loaded 220160 tokens for a model trained at 262144. Nothing may ever
	// advertise the training limit, which is the model's ceiling rather than
	// anything this server will serve.
	var models ModelsResponse
	require.NoError(t, json.Unmarshal(fixture(t, "llama-server", "v1_models_capture_qwen.json"), &models))
	require.Len(t, models.Data, 1)

	entry := models.Data[0]
	require.Equal(t, 220160, entry.Meta.NCtx)
	require.Equal(t, 262144, entry.Meta.NCtxTrain)
	assert.Equal(t, 220160, entry.ContextTokens())
}

func TestCapcompat_DetectLlamaServerIgnoresListingCapabilities(t *testing.T) {
	// The listing carries an Ollama-style models[] block whose capabilities
	// array says "multimodal" for this model, while /props reports every
	// modality false. /props describes what this server will accept, so it
	// wins and nothing reads that array.
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "llama-server", "v1_models_capture.json"),
		"/props":     fixture(t, "llama-server", "props_capture.json"),
	})

	info, err := Detect(context.Background(), up.client(t), "gemma")
	require.NoError(t, err)
	assert.Equal(t, []string{"text"}, info.Capabilities.In,
		"a multimodal model served without a projector accepts text only")
}

func TestCapcompat_DetectLlamaServerAudioAndVideo(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "llama-server", "v1_models.json"),
		"/props":     fixture(t, "llama-server", "props_omni.json"),
	})

	info, err := Detect(context.Background(), up.client(t), "model-a")
	require.NoError(t, err)

	// Order is fixed so the cached blob is byte-stable across probes.
	assert.Equal(t, []string{"text", "image", "audio", "video"}, info.Capabilities.In)
}

// Builds predating chat_template_caps give no signal for tools. The
// template source is not consulted at all, so the answer is false even
// though this fixture's template mentions tools.
func TestCapcompat_DetectLlamaServerNoTemplateCaps(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "llama-server", "v1_models.json"),
		"/props":     fixture(t, "llama-server", "props_no_template_caps.json"),
	})

	info, err := Detect(context.Background(), up.client(t), "model-a")
	require.NoError(t, err)
	assert.False(t, info.Capabilities.Tools)
	assert.Equal(t, 16384, info.Capabilities.Context)
}

// Newer builds added reasoning_effort_levels, a list, to
// chat_template_caps. The prober must decode the caps without rejecting the
// whole response, and still read the boolean keys from it.
func TestCapcompat_DetectLlamaServerNewBuildProps(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "llama-server", "v1_models.json"),
		"/props":     fixture(t, "llama-server", "props_capture_b12017.json"),
	})

	info, err := Detect(context.Background(), up.client(t), "model-a")
	require.NoError(t, err)

	assert.Equal(t, hint.LlamaServer, info.Upstream)
	assert.Equal(t, []string{"text", "image", "audio", "video"}, info.Capabilities.In)
	assert.Equal(t, []string{"text"}, info.Capabilities.Out)
	assert.True(t, info.Capabilities.Tools, "caps report supports_tools and supports_tool_calls")
	assert.Equal(t, 262144, info.Capabilities.Context)
}

// A /props that is not valid JSON must not fail the probe: the server is
// answering, so the model is usable. Every field reads as its zero value
// and one warning says why; the per-field warnings stay suppressed.
func TestCapcompat_DetectLlamaServerInvalidPropsJSON(t *testing.T) {
	tests := map[string]string{
		"garbage body": "this is not json",
		// gjson can still read fields that appear before a truncation,
		// so these readable fields must not make it into the result.
		"truncated body": `{"modalities": {"vision": true, "audio": true}, "default_generation_settings": {"n_ctx": 4096}`,
	}
	for name, body := range tests {
		t.Run(name, func(t *testing.T) {
			var buf bytes.Buffer
			log := logmon.NewWriter(&buf)
			up := newUpstream(t, map[string][]byte{
				"/v1/models": fixture(t, "llama-server", "v1_models.json"),
				"/props":     []byte(body),
			})

			info, err := Detect(context.Background(), up.clientWithLogger(t, log), "model-a")
			require.NoError(t, err)

			assert.Equal(t, hint.LlamaServer, info.Upstream)
			assert.Equal(t, []string{"text"}, info.Capabilities.In)
			assert.Equal(t, []string{"text"}, info.Capabilities.Out)
			assert.False(t, info.Capabilities.Tools)
			assert.Equal(t, 0, info.Capabilities.Context)
			assert.Contains(t, buf.String(), "not valid JSON")
			assert.NotContains(t, buf.String(), "is not a boolean", "one warning explains the whole body")
		})
	}
}

// A field that is present but of the wrong type logs a WARN and reads as
// its zero value; the rest of the probe continues.
func TestCapcompat_DetectLlamaServerContextWrongType(t *testing.T) {
	var buf bytes.Buffer
	log := logmon.NewWriter(&buf)
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "llama-server", "v1_models.json"),
		"/props":     []byte(`{"modalities":{"vision":true},"default_generation_settings":{"n_ctx":"262144"},"chat_template_caps":{"supports_tools":true,"supports_tool_calls":true}}`),
	})

	info, err := Detect(context.Background(), up.clientWithLogger(t, log), "model-a")
	require.NoError(t, err)

	assert.Equal(t, []string{"text", "image"}, info.Capabilities.In, "the other fields still read")
	assert.True(t, info.Capabilities.Tools)
	assert.Equal(t, 0, info.Capabilities.Context)
	assert.Contains(t, buf.String(), "n_ctx is not a number")
}

// A caps value that is not a boolean logs a WARN and reads as false;
// the rest of the probe continues.
func TestCapcompat_DetectLlamaServerCapsWrongType(t *testing.T) {
	var buf bytes.Buffer
	log := logmon.NewWriter(&buf)
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "llama-server", "v1_models.json"),
		"/props":     []byte(`{"modalities":{},"chat_template_caps":{"supports_tools":"yes","supports_tool_calls":true},"default_generation_settings":{"n_ctx":4096}}`),
	})

	info, err := Detect(context.Background(), up.clientWithLogger(t, log), "model-a")
	require.NoError(t, err)

	assert.False(t, info.Capabilities.Tools)
	assert.Equal(t, 4096, info.Capabilities.Context)
	assert.Contains(t, buf.String(), "supports_tools is not a boolean")
}

// A /props that omits a block entirely: the probe continues, the fields
// read as their zero values, and a warning names the missing block.
func TestCapcompat_DetectLlamaServerNoModalities(t *testing.T) {
	var buf bytes.Buffer
	log := logmon.NewWriter(&buf)
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "llama-server", "v1_models.json"),
		"/props":     []byte(`{"default_generation_settings":{"n_ctx":4096}}`),
	})

	info, err := Detect(context.Background(), up.clientWithLogger(t, log), "model-a")
	require.NoError(t, err)

	assert.Equal(t, []string{"text"}, info.Capabilities.In)
	assert.False(t, info.Capabilities.Tools, "no caps and no template, so no tool signal")
	assert.Equal(t, 4096, info.Capabilities.Context)
	assert.Contains(t, buf.String(), "has no modalities")
}

func TestCapcompat_DetectVLLM(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "vllm", "v1_models.json"),
	})

	info, err := Detect(context.Background(), up.client(t), "meta-llama/Llama-3.1-8B-Instruct")
	require.NoError(t, err)

	assert.Equal(t, hint.VLLM, info.Upstream)
	assert.Equal(t, 131072, info.Capabilities.Context)
	assert.Equal(t, []string{"text"}, info.Capabilities.In)
	assert.Equal(t, []string{"text"}, info.Capabilities.Out)
	assert.False(t, info.Capabilities.Tools, "vllm exposes nothing about tool support")
	assert.Equal(t, 0, up.hits["/props"], "vllm has no /props to read")
}

func TestCapcompat_DetectVLLMCapture(t *testing.T) {
	// Verbatim from a running vLLM. Note the served id differs from root,
	// which is the checkpoint path, and parent is JSON null rather than
	// absent: this is a base model, not an adapter.
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "vllm", "v1_models_capture.json"),
	})

	t.Run("exact served name", func(t *testing.T) {
		info, err := Detect(context.Background(), up.client(t), "qwen3-4b-vllm")
		require.NoError(t, err)

		assert.Equal(t, hint.VLLM, info.Upstream)
		assert.Equal(t, 40960, info.Capabilities.Context)
		assert.Equal(t, []string{"text"}, info.Capabilities.In)
		assert.Equal(t, []string{"text"}, info.Capabilities.Out)
		assert.False(t, info.Capabilities.Tools, "vllm exposes nothing about tool support")
		assert.Equal(t, 0, up.hits["/props"], "vllm has no /props to read")
	})

	t.Run("llama-swap model id that vllm does not know", func(t *testing.T) {
		// A model llama-swap calls something else, with no useModelName set.
		// parent is null, so this entry is still the base model to read.
		info, err := Detect(context.Background(), up.client(t), "my-local-name")
		require.NoError(t, err)
		assert.Equal(t, 40960, info.Capabilities.Context)
	})
}

func TestCapcompat_VLLMNullParentIsNotAnAdapter(t *testing.T) {
	// vLLM sends parent as JSON null for a base model. Decoding that into a
	// string has to leave it empty, or Find would treat every base model as
	// an adapter and skip it.
	var models ModelsResponse
	require.NoError(t, json.Unmarshal(fixture(t, "vllm", "v1_models_capture.json"), &models))
	require.Len(t, models.Data, 1)
	assert.Empty(t, models.Data[0].Parent)
	assert.Equal(t, "/models/qwen-4b", models.Data[0].Root)
}

func TestCapcompat_VLLMSkipsLoRAAdapters(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "vllm", "v1_models_lora.json"),
	})

	t.Run("unknown name falls back to the base model", func(t *testing.T) {
		info, err := Detect(context.Background(), up.client(t), "a-name-vllm-never-heard-of")
		require.NoError(t, err)
		assert.Equal(t, 131072, info.Capabilities.Context,
			"the adapter is listed first but its max_model_len is not the base model's")
	})

	t.Run("exact adapter name is honoured", func(t *testing.T) {
		info, err := Detect(context.Background(), up.client(t), "sql-lora")
		require.NoError(t, err)
		assert.Equal(t, 4096, info.Capabilities.Context)
	})
}

func TestCapcompat_DetectGufo(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "gufo", "v1_models.json"),
	})

	info, err := Detect(context.Background(), up.client(t), "qwen3.8-flash-next-gufo")
	require.NoError(t, err)

	assert.Equal(t, hint.OpenAICompatible, info.Upstream)
	assert.Equal(t, 262144, info.Capabilities.Context)
	assert.Equal(t, []string{"text"}, info.Capabilities.In)
	assert.Equal(t, []string{"text"}, info.Capabilities.Out)
	assert.False(t, info.Capabilities.Tools, "gufo exposes nothing about tool support in /v1/models")
	assert.Equal(t, 0, up.hits["/props"], "gufo has no /props to read")
	require.NoError(t, info.Capabilities.Validate())
}

func TestCapcompat_DetectRadiance(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "radiance", "v1_models.json"),
	})

	info, err := Detect(context.Background(), up.client(t), "qwen35")
	require.NoError(t, err)

	assert.Equal(t, hint.Radiance, info.Upstream)
	assert.Equal(t, 200000, info.Capabilities.Context)
	assert.Equal(t, 0, up.hits["/props"], "radiance has no /props to read")
	require.NoError(t, info.Capabilities.Validate())
}

func TestCapcompat_DetectYamz(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "yamz", "v1_models.json"),
	})

	info, err := Detect(context.Background(), up.client(t), "qwen-3.8-next-kyojin")
	require.NoError(t, err)

	assert.Equal(t, hint.Kyojin, info.Upstream, "kyojin lists its models as owned_by yamz")
	assert.Equal(t, 262144, info.Capabilities.Context)
	assert.Equal(t, []string{"text"}, info.Capabilities.In)
	assert.Equal(t, []string{"text"}, info.Capabilities.Out)
	assert.False(t, info.Capabilities.Tools, "yamz exposes nothing about tool support in /v1/models")
	require.NoError(t, info.Capabilities.Validate())
}

func TestCapcompat_DetectHalogen(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "halogen", "v1_models.json"),
		"/health":    fixture(t, "halogen", "health.json"),
	})

	info, err := Detect(context.Background(), up.client(t), "halogen-qwen3.8-flash-next")
	require.NoError(t, err)

	assert.Equal(t, hint.Halogen, info.Upstream)
	assert.Equal(t, []string{"text", "image"}, info.Capabilities.In, "this build has a vision tower")
	assert.Equal(t, []string{"text"}, info.Capabilities.Out)
	assert.True(t, info.Capabilities.Tools)
	assert.Equal(t, 262144, info.Capabilities.Context)
	assert.False(t, info.Capabilities.Reranker, "not reported anywhere")
	require.NoError(t, info.Capabilities.Validate())
}

func TestCapcompat_DetectHalogenVisionDisabled(t *testing.T) {
	// The real capture with the vision tower turned off. Images are off
	// unless the server is started with one, so this is the default build.
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "halogen", "v1_models.json"),
		"/health":    fixture(t, "halogen", "health_no_vision.json"),
	})

	info, err := Detect(context.Background(), up.client(t), "halogen-qwen3.8-flash-next")
	require.NoError(t, err)

	assert.Equal(t, []string{"text"}, info.Capabilities.In)
	assert.True(t, info.Capabilities.Tools)
	assert.Equal(t, 262144, info.Capabilities.Context)
}

func TestCapcompat_DetectHalogenWithoutToolSignals(t *testing.T) {
	// The real capture with the supported list and the tool-call block
	// removed, standing in for a build that publishes neither.
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "halogen", "v1_models.json"),
		"/health":    fixture(t, "halogen", "health_no_tools.json"),
	})

	info, err := Detect(context.Background(), up.client(t), "halogen-qwen3.8-flash-next")
	require.NoError(t, err)

	assert.False(t, info.Capabilities.Tools, "nothing in /health claims tool support")
	assert.Equal(t, 262144, info.Capabilities.Context)
}

func TestCapcompat_DetectHalogenFallsBackToListingContext(t *testing.T) {
	// A build whose /health omits context still has three names for it in
	// the model listing.
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "halogen", "v1_models.json"),
		"/health":    []byte(`{"status":"ok","vision":{"enabled":false},"supported":["tools"]}`),
	})

	info, err := Detect(context.Background(), up.client(t), "halogen-qwen3.8-flash-next")
	require.NoError(t, err)
	assert.Equal(t, 262144, info.Capabilities.Context)
}

func TestCapcompat_DetectHalogenHealthUnreachable(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "halogen", "v1_models.json"),
	})

	_, err := Detect(context.Background(), up.client(t), "halogen-qwen3.8-flash-next")
	require.Error(t, err)
	assert.Contains(t, err.Error(), "halogen")
}

func TestCapcompat_ModelEntryContextTokens(t *testing.T) {
	// Servers spell the context length differently, and n_ctx_train is the
	// training limit rather than the loaded window, so it is never used.
	tests := []struct {
		name  string
		entry ModelEntry
		want  int
	}{
		{"max_model_len wins", ModelEntry{MaxModelLen: 1, ContextLength: 2}, 1},
		{"context_length next", ModelEntry{ContextLength: 2}, 2},
		{"max_context after context_length", ModelEntry{MaxContext: 4, ContextLength: 2}, 2},
		{"max_context next", ModelEntry{MaxContext: 4}, 4},
		{"meta n_ctx last", func() ModelEntry {
			var e ModelEntry
			e.Meta.NCtx = 3
			return e
		}(), 3},
		{"n_ctx_train is never used", func() ModelEntry {
			var e ModelEntry
			e.Meta.NCtxTrain = 999
			return e
		}(), 0},
		{"nothing reported", ModelEntry{}, 0},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			assert.Equal(t, tt.want, tt.entry.ContextTokens())
		})
	}
}

func TestCapcompat_DetectUnsupportedUpstream(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "unsupported_v1_models.json"),
	})

	_, err := Detect(context.Background(), up.client(t), "model-a")
	require.ErrorIs(t, err, ErrUnsupportedUpstream)
	assert.Contains(t, err.Error(), "some-other-server")
}

func TestCapcompat_DetectEmptyListing(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": []byte(`{"object":"list","data":[]}`),
	})

	_, err := Detect(context.Background(), up.client(t), "model-a")
	require.ErrorIs(t, err, ErrUnsupportedUpstream)
	assert.Contains(t, err.Error(), "unknown")
}

func TestCapcompat_DetectModelListUnreachable(t *testing.T) {
	up := newUpstream(t, map[string][]byte{})

	_, err := Detect(context.Background(), up.client(t), "model-a")
	require.Error(t, err)
	assert.NotErrorIs(t, err, ErrUnsupportedUpstream,
		"a server that will not answer is a different problem from one that is unsupported")
	assert.Contains(t, err.Error(), "404")
}

func TestCapcompat_DetectPropsUnreachable(t *testing.T) {
	up := newUpstream(t, map[string][]byte{
		"/v1/models": fixture(t, "llama-server", "v1_models.json"),
	})

	_, err := Detect(context.Background(), up.client(t), "model-a")
	require.Error(t, err)
	assert.Contains(t, err.Error(), "llama-server")
}

func TestCapcompat_ClientJoinsBasePathPrefix(t *testing.T) {
	var gotPath string
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotPath = r.URL.Path
		w.Write(fixture(t, "llama-server", "v1_models.json"))
	}))
	defer server.Close()

	base, err := url.Parse(server.URL + "/upstream/prefix")
	require.NoError(t, err)

	var models ModelsResponse
	require.NoError(t, NewClient(base, config.TimeoutsConfig{}, nil).GetJSON(context.Background(), "/v1/models", &models))
	assert.Equal(t, "/upstream/prefix/v1/models", gotPath)
}

func TestCapcompat_ClientSendsHeaders(t *testing.T) {
	var gotAuth string
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotAuth = r.Header.Get("Authorization")
		w.Write([]byte(`{"object":"list","data":[]}`))
	}))
	defer server.Close()

	base, err := url.Parse(server.URL)
	require.NoError(t, err)
	c := NewClient(base, config.TimeoutsConfig{}, nil)
	c.SetHeader("Authorization", "Bearer secret")

	var models ModelsResponse
	require.NoError(t, c.GetJSON(context.Background(), "/v1/models", &models))
	assert.Equal(t, "Bearer secret", gotAuth)
}

func TestCapcompat_ModelsResponseFind(t *testing.T) {
	models := ModelsResponse{Data: []ModelEntry{
		{ID: "adapter", Parent: "base", MaxModelLen: 1},
		{ID: "base", MaxModelLen: 2},
	}}

	tests := []struct {
		name   string
		search string
		wantID string
	}{
		{"exact match wins", "adapter", "adapter"},
		{"exact base match", "base", "base"},
		{"unknown name skips adapters", "unknown", "base"},
		{"empty name skips adapters", "", "base"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			entry, found := models.Find(tt.search)
			require.True(t, found)
			assert.Equal(t, tt.wantID, entry.ID)
		})
	}

	t.Run("no entries", func(t *testing.T) {
		_, found := ModelsResponse{}.Find("anything")
		assert.False(t, found)
	})

	t.Run("only adapters falls back to the first entry", func(t *testing.T) {
		only := ModelsResponse{Data: []ModelEntry{{ID: "a", Parent: "gone"}}}
		entry, found := only.Find("unknown")
		require.True(t, found)
		assert.Equal(t, "a", entry.ID)
	})
}
