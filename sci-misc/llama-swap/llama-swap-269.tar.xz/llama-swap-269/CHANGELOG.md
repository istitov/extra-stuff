# Changelog

## v269 (Oct 31, 2026)

Happy Halloween!

Lots of small and big treats in this release.

- captures can now be persisted to disk and not lost on restart.
- the metrics capture backend has been refactored to make it easy
  to add support for new inference servers.
- the UI can show models sorted by categories, great if you have
  many different types configured!  
- metrics can be exported as a PNG to make sharing easier.
- add support for the embedding model capability
- small bug and UI improvements

Details below:

- [PR #1274](https://github.com/mostlygeek/llama-swap/pull/1274) go.mod,ui/package-lock.json: dependency updates: picks up security updates for node and moves `shirou/gopsutil` back to the main upstream repository by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1275](https://github.com/mostlygeek/llama-swap/pull/1275) feat(config): add embeddings capability flag: adds `capabilities.embeddings`, mirroring the existing `reranker` flag and rendered into the `/v1/models` capabilities map, because capability discovery reads llama-server `/props` which reports nothing about embeddings, so a probed embed model surfaced as plain text->text and clients and the UI could only pick them out by name prefix by [@noctrex](https://github.com/noctrex)
- [PR #1276](https://github.com/mostlygeek/llama-swap/pull/1276) feat(ui): group Models list into capability-derived class sections: derives each model's class (Chat, Image, Video, Audio, Embeddings, Rerank) client-side from the capability flags and modality lists `/v1/models` already carries and renders one collapsible section per class with a status dot that aggregates its rows, because a long flat list is hard to scan once many models are configured; `/api/events` modelStatus now includes `modalities: {in, out}` from the same `renderCapabilities` call so the dashboard and the OpenAI listing cannot disagree by [@noctrex](https://github.com/noctrex)
- [PR #1279](https://github.com/mostlygeek/llama-swap/pull/1279) ui: move Models display options into a dropdown menu: moves the Categories and Show unlisted models switches into a "Display options" menu pinned to the right of the Models header (with the unlisted count shown in the item) and drops `flex-wrap`, because the header added in #1276 wrapped onto extra rows and made the page too tall; mobile layout improved too by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1280](https://github.com/mostlygeek/llama-swap/pull/1280) Makefile: add native target for the host platform: makes `native` the default target so a bare `make` builds for the platform you are on instead of cross-compiling everything, and fixes `make all` to actually cover Windows and FreeBSD, with `$(LDFLAGS)` factored out and shared by every platform target by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1282](https://github.com/mostlygeek/llama-swap/pull/1282) internal/capcompat: detect context length from yamz servers: reads `max_context` from `/v1/models` (tried after `context_length`) so yamz (kyojin) servers report their context length through the default prober by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1285](https://github.com/mostlygeek/llama-swap/pull/1285) ui: export the activity table as a client-side PNG image: rasterizes the visible table in the browser with html-to-image (SVG foreignObject -> canvas) and adds Markdown / Screenshot tabs to the export dialog with clipboard copy, download and a background resolved from the nearest opaque ancestor, so exporting works without a new backend endpoint; Meta and Capture columns are excluded from the render (#1284) by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1287](https://github.com/mostlygeek/llama-swap/pull/1287) ui: make markdown code highlighting theme aware in light mode: drives highlight.js token colors from `--hljs-*` custom properties (with a per-theme `--link` color and a lighter `--muted` for Midnight Commander) instead of one globally imported dark-only stylesheet, because code was measured at 1.12-1.40:1 contrast and was effectively invisible in all 11 light themes; light-mode code contrast is now 10.76-13.35:1 with dark mode unchanged by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1290](https://github.com/mostlygeek/llama-swap/pull/1290) internal/capcompat: read /props fields with gjson: extracts each `/props` field individually with gjson, so one unexpected field no longer takes the whole probe down, because llama-server b12017 added a list to `chat_template_caps` alongside its booleans which broke the whole-body unmarshal and made capability discovery fail against those builds; bad fields now log a WARN and read as their zero value (#1281) by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1292](https://github.com/mostlygeek/llama-swap/pull/1292) Extract usage parsing into pluggable upstream-specific handlers: splits usage extraction into per-upstream extractors (llama-server, vLLM, Anthropic, OpenAI, TabbyAPI, oMLX and an "auto" fallback that reads every known format) fed by the new `internal/hint` package which carries upstream and task information through the request context, and records task type, route, peer and reasoning tokens in the activity log, so token counts and performance metrics are accurate per upstream instead of assuming one format by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1293](https://github.com/mostlygeek/llama-swap/pull/1293) ui: fix the Model page Logs panel scrolling the whole page: gives the page its own scroll container and a minimum height for the Activity/Logs tabs, so a long log scrolls inside the panel instead of pushing the whole page by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1294](https://github.com/mostlygeek/llama-swap/pull/1294) Store request/response captures in separate SQLite database: moves captures out of the in-memory `internal/cache` into a capture repository backed by its own SQLite database (new `store.persistCaptures`, `captureBuffer` unchanged), so captures can persist across restarts without fragmenting the metrics db, are pruned asynchronously by compressed size and are addressed by a `yymmddhh-xxxx` capture id that activity rows link to; `internal/cache` is removed (#1115) by [@mostlygeek](https://github.com/mostlygeek)

## v268 (Oct 28, 2026)

Many users run llama-swap on their gaming machines. The new Pause and Resume
functionality unloads and pauses all inference, freeing up system resources for
fun! Well llama-swap is fun too but you gotta be weird like me to prefer it
over gaming.

Also a small change to the CUDA 13 container to support Turing architectures,
where the actual cut off is.

- [PR #1272](https://github.com/mostlygeek/llama-swap/pull/1272) docker/unified: add compute capability 75 to cuda13 amd64 build: adds sm 75 to the default `CMAKE_CUDA_ARCHITECTURES` for the amd64 `unified-cuda13` image, because it only compiled for sm 80 and up so Turing GPUs (Quadro T1000, RTX 20xx, GTX 16xx), which CUDA 13 still supports, failed at runtime with "no kernel image is available for execution on the device"; arm64 is unchanged (#1239) by [@mostlygeek](https://github.com/mostlygeek)
- [6c855da](https://github.com/mostlygeek/llama-swap/commit/6c855da82bf7adb235bdf2e4abe9278aea703973) README: add turing architecture notes: lists Turing GPUs (RTX 20xx, GTX 16xx, Quadro T-series) as supported by the `unified-cuda13` image by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1273](https://github.com/mostlygeek/llama-swap/pull/1273) server: add pause/resume inference: adds `/api/models/pause` and `/api/models/resume` endpoints and UI controls that unload all local models and reject new requests until resumed, so system resources can be freed while llama-swap keeps running (#1268) by [@mostlygeek](https://github.com/mostlygeek)

## v267 (Oct 25, 2026)

This is huge release with @JaredHatfield contributing a new capacity based router!

Rather than defining which models fit with other models, the capacity router
allows declaring pools of resources and how much of each resource a model needs.
The new router will automatically evict models to free up enough capacity to
load the new model. For use cases that have a big combinations of models
that can run concurrently, the new router can eliminate a lot of manual
configuration work.

The other big feature is the Help Agent in the UI can now search llama-swap's
source code as well as its knowledge base. Every release of llama-swap includes
the source code it was built from (tests excluded). This is handy for answering
questions about how llama-swap actually works and a knowledge base article
does not exist. One step closer to the singularity!

If you want to try out the new router ask the Help Agent to generate a configuration
example using your existing configuration. Did you know, it can do that!? :)


- [PR #1242](https://github.com/mostlygeek/llama-swap/pull/1242) router: add capacity-based model eviction: adds a capacity router where user-defined pools bound which models can be resident together and `evict_cost` picks what to unload when a model no longer fits, replacing the need to hand-maintain every valid combination in the matrix on systems with lots of unified memory (#1004) by [@JaredHatfield](https://github.com/JaredHatfield)
- [PR #1258](https://github.com/mostlygeek/llama-swap/pull/1258) docs/kb: add guides/tools for the cmd/ programs: adds knowledge base articles for wol-proxy, fake-model and vllm-wrapper (and moves the kubeswap guide under `guides/tools`) so the Help chat can answer questions about the tools in the llama-swap ecosystem, plus a convention for keeping each tool's README and article in sync by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1259](https://github.com/mostlygeek/llama-swap/pull/1259) internal/mcptools: add code search to Help agent: gives the Docs agent `code__grep`, `code__read`, `code__find` and `code__ls` so it can verify knowledge base articles against the code that implements them, adds `helpagent.disable` to hide Help and stop serving `/api/mcp`, and raises the agent loop's max iterations from 16 to 96 so the extra tool calls do not end the answer early by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1265](https://github.com/mostlygeek/llama-swap/pull/1265) internal/mcptools: embed source for code tools instead of git: embeds the Go and TypeScript source (without tests) in the binary via the new `embed_src` build tag and reads it through `fs.FS`, because the runtime `git` checkout made the code tools fail on installs without the git command line tool; `code__status` and `code__update` are removed by [@mostlygeek](https://github.com/mostlygeek)

## v266 (Oct 22, 2026)

This release includes security dependency updates and requested quality of life changes from users:

- the UI no longer expects to be run under a root path making it easier to serve llama-swap behind another proxy
- the max request size is configurable now. Users should be free to OOM as much as they want. llama-swap ain't your mom!
- allow manual override of values in /v1/audio/voices. This is a non-standard endpoint but makes working with upstream audio engines a bit nicer

Details below:

- [PR #1224](https://github.com/mostlygeek/llama-swap/pull/1224) cmd/kubeswap: attach DRA ResourceClaims and mount NFS volumes: add repeatable `--resource-claim` and NFS `--volume` support so Kubernetes backends can share a DRA GPU claim and mount models without a static PV and PVC for each export (#1222) by [@gabrielcosi](https://github.com/gabrielcosi)
- [PR #1225](https://github.com/mostlygeek/llama-swap/pull/1225) Add voices override for speech models: let local models configure `capabilities.voices` so `/v1/audio/voices` returns a reliable list without starting the model or querying the upstream server (#1207) by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1228](https://github.com/mostlygeek/llama-swap/pull/1228) ui,server: serve the UI under a reverse proxy base path: use relative asset, API and redirect paths so the UI works behind a prefix-stripping reverse proxy without routing its endpoints at the proxy root (#1227) by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1249](https://github.com/mostlygeek/llama-swap/pull/1249) internal/server: make the request body size limit configurable: add `maxRequestBodyMB` for model endpoints and Tailcat, replacing the fixed 250 MB cap while retaining 250 MB as the default (#1245) by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1257](https://github.com/mostlygeek/llama-swap/pull/1257) AGENTS.md, go.mod: use go 1.27.3, trim AGENT rules: raise the Go version to 1.27.3, update dependencies and simplify contributor instructions by [@mostlygeek](https://github.com/mostlygeek)

## v265 (Oct 14, 2026)

A couple of small improvements:

- support serving llama-swap behind a path on a reverse proxy. Helpful if you want to front llama-swap with nginx and serve it under a specific path.
- add support for manually defining voices for text to speech models
- a small kubeswap update

- [PR #1228](https://github.com/mostlygeek/llama-swap/pull/1228) ui,server: serve the UI under a reverse proxy base path: makes the browser side base-path agnostic (relative asset, redirect, favicon and PWA URLs plus an `apiUrl()` helper that re-attaches a stripped prefix) so llama-swap works behind a plain prefix-stripping proxy at `https://host/subpath/llama-swap/` without routing `/ui`, `/api` and `/v1` at the proxy root; includes an nginx and Caddy guide (#1227) by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1225](https://github.com/mostlygeek/llama-swap/pull/1225) Add voices override for speech models: adds a `models.capabilities.voices` capability listing the voice ids an upstream server supports, because the non-standard `GET /v1/audio/voices` endpoint returns unreliable responses; falls back to probing that endpoint on a best-effort basis when the list is not set (#1207) by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1224](https://github.com/mostlygeek/llama-swap/pull/1224) cmd/kubeswap: attach DRA ResourceClaims and mount NFS volumes: adds a repeatable `--resource-claim name=claim` flag so backends can get GPUs via the NVIDIA DRA driver (kubeswap only references the claim, pods sharing a claim share its device) and an `nfs:server/export:path[:ro]` kind for `--volume` so models can be mounted from NFS without a static PV/PVC per export (#1222) by [@gabrielcosi](https://github.com/gabrielcosi)

## v264 (Oct 12, 2026)

This release includes a new `auto:orphans` set for swap matrix rules. This new set automatically includes all models that were not explictly added to a set.  It is defined as `(orphan1 | orphan2 | orphan3 | ...)`. The orphans set is handy for definitions like: `+always & +auto:orphans`, where `+always` is a set of models that are always loaded and should never be swapped out.

The /audiocpp endpoint was added to make working with audio.cpp server eaiser. The `audiocpp_auto` model is automatically used when the endpoint is requested. audio.cpp's OpenAI compatible endpoints can be accessed directly via `/audiocpp/v1/audio/*`. Very handy when used with llama-swap's unified docker container which builds audio.cpp with the UI and native model downloader.

Also one tiny commit to improve compatibility with llama-server's decision model functionality.

Thanks to the contributors in this release, especially @knguyen298 for being patient and keeping his PR updated.

- [PR #1026](https://github.com/mostlygeek/llama-swap/pull/1026) internal/matrix: add synthetic auto:orphans set: adds a `+auto:orphans` selector that expands to every model not named in another set, so a catch-all set like `"+always & +auto:orphans"` picks up new models automatically (#1025) by [@knguyen298](https://github.com/knguyen298)
- [PR #1223](https://github.com/mostlygeek/llama-swap/pull/1223) Add /audiocpp endpoint for audio.cpp UI passthrough: serves audio.cpp's web UI and model management through a dedicated `/audiocpp/` endpoint bound to the reserved `audiocpp_auto` model, like `/comfyui/`, so the unified container works without naming a model per request by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1220](https://github.com/mostlygeek/llama-swap/pull/1220) internal/capcompat: detect decision models from llama-server's listing: fix decision models being reported as `out: [text]` (and `capabilities.out: [decisions]` failing validation) because discovery only read `/props`; `output_modalities` from `/v1/models` is now used, and tools are only advertised when the model outputs text (#1219) by [@nazeshinjite](https://github.com/nazeshinjite)

## v263 (Oct 9, 2026)

I've been busy, busy, busy and have not had as much time for llama-swap as I
would like. This release includes reliability improvements, improved
compatibility and some small quality of life improvements. Thank you for the
amazing contributors for this release! Everyone who files issues or submits a
PR is greatly appreciated.

- [PR #1213](https://github.com/mostlygeek/llama-swap/pull/1213) Add confirmation UI and progress tracking for WoL wake: wol-proxy gets a `-require-confirm` flag that shows a "Start server" page instead of waking on every request, plus a retro loading page with a progress bar estimated from the last wake duration by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1215](https://github.com/mostlygeek/llama-swap/pull/1215) internal/router: strip browser headers before proxying to peers: fix UI chats failing with a 401 against an api.anthropic.com peer, which treated the forwarded browser Origin header as a direct browser call; Origin, Referer, Sec-Fetch-* and Access-Control-Request-* are now removed (#1214) by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1212](https://github.com/mostlygeek/llama-swap/pull/1212) internal/process: report loading progress from the health check: parse `progress`/`message` from not-ready health check JSON bodies, show it on the Models and model detail pages, and restart the `healthCheckTimeout` countdown when progress changes so long loads don't time out (#1079, #1208) by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1196](https://github.com/mostlygeek/llama-swap/pull/1196) internal/perf: restart loop to trigger GPU collector when the monitor still running: fix GPU stats stopping for good after `nvidia-smi` exited; the exit error is now logged and the collector restarts with a 5 to 30 second backoff (#1155) by [@hpdkhoa](https://github.com/hpdkhoa)
- [PR #1211](https://github.com/mostlygeek/llama-swap/pull/1211) internal/process: add a per-model disableKeepAlives option (#1205): fix intermittent 502 `proxy error: EOF` when a POST reused a pooled connection that llama-server closed after a streamed response; `disableKeepAlives: true` opens a new connection per request by [@johnnieCR](https://github.com/johnnieCR)
- [PR #1199](https://github.com/mostlygeek/llama-swap/pull/1199) fix(metrics): show oMLX token rates in Activity: read oMLX's `usage.prompt_tokens_per_second` and `usage.generation_tokens_per_second` as a fallback so rates no longer show as unknown by [@junmo-kim](https://github.com/junmo-kim)
- [PR #1198](https://github.com/mostlygeek/llama-swap/pull/1198) internal/capcompat: add Gufo inference engine prober: add a default capability prober that uses only `/v1/models` data as the fallback for servers without a custom prober (vLLM, Gufo, SGLang, etc.), replacing the vLLM-specific one by [@berney](https://github.com/berney)

## v262 (Oct 2, 2026)

systemone models are mega hyped right now. This release adds support for
/v1/systemone for that fast thinking goodness(?). Also requests missing a
Content-Type will get one automatically added for the inference endpoints.

- [PR #1197](https://github.com/mostlygeek/llama-swap/pull/1197) Add /v1/systemone endpoint to POST JSON routes: route llama.cpp's new /v1/systemone decision model endpoint to the model named in the JSON body (#1195) by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1194](https://github.com/mostlygeek/llama-swap/pull/1194) internal/server: accept JSON bodies with a missing or wrong Content-Type: fix a misleading "no model id could be identified" 404 when `curl -d` sent JSON as form-urlencoded; a middleware now relabels JSON object bodies as application/json and returns a 400 naming the expected format for unusable bodies (#1192) by [@mostlygeek](https://github.com/mostlygeek)

## v261 (Sep 30, 2026)

This release has a bunch of small compatibility improvements requested by the community.
Also the changelog summaries have been changed to only AI for the list below. These notes at
the top will be written by humans (or my dog) for humans. The AI's writing more correct but
fuck it we have too much AI slop in our lives already.

- [PR #1189](https://github.com/mostlygeek/llama-swap/pull/1189) Increase ComfyUI concurrency limit from 50 to 999: fix ComfyUI stuck on the splash screen via /comfyui because one tab makes more parallel requests than the old minimum of 50 allowed (#1188) by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1187](https://github.com/mostlygeek/llama-swap/pull/1187) docker/unified: compile sm_70 in the CUDA 12 image for V100: fix ik-llama-server aborting on V100 GPUs, where only sm_61 PTX without a WMMA flash-attention kernel was available (#1185) by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1158](https://github.com/mostlygeek/llama-swap/pull/1158) Hardware Detection: detect Intel GPUs on Linux via xpu-smi, including dedicated Arc memory, and read the Metal version on macOS across system_profiler key names by [@anantshri](https://github.com/anantshri)
- [PR #1183](https://github.com/mostlygeek/llama-swap/pull/1183) docs/kb: document that tailcat.models accepts selectors: note that aliases, selectors, profile pins and peer model names are accepted, with a selector example by [@mostlygeek](https://github.com/mostlygeek)
- [PR #1182](https://github.com/mostlygeek/llama-swap/pull/1182) Build audio.cpp with static eSpeak-ng and install phoneme data: link eSpeak-ng statically and ship its phoneme data so Kokoro, SanoTTS and Inflect phonemization works without a writable cache (#1181) by [@mostlygeek](https://github.com/mostlygeek)

## v260

This release fixes a crash at startup on macOS 27 with Apple M6 hardware
(#1178). Hardware detection reads the CPU frequency through gopsutil, which
expects a voltage-states5-sram property that is missing on M6. It passed the
empty value straight to CFDataGetLength, which segfaulted before the server
could start listening.

As a temporary fix, gopsutil now points at a fork with the patch from
shirou/gopsutil#2163, which checks for the missing property. This will be
removed once the upstream project picks up the patch. Some Go dependencies
were also updated as required by the newer gopsutil.

- [PR #1180](https://github.com/mostlygeek/llama-swap/pull/1180) go.mod: use gopsutil PR #2163 to fix darwin/arm64 crash: replace gopsutil with a patched fork that guards the CPU frequency probe against a missing property on Apple M6

## v259

Logging is split into three separate streams: proxy, upstream and HTTP access
logs. HTTP request lines used to be mixed in with the proxy log, which made it
hard to search. They now have their own stream and their own tab in the log
viewer. The logToStdout setting accepts a comma separated list of streams, such
as "proxy,http", and the old values still work.

Upgrading: log data has moved off GET /api/events to a new GET /api/events/logs
endpoint. Pick streams with ?stream=proxy&stream=http. Tools that read logs
from /api/events need to switch to the new endpoint.

The UI sidebar can be resized by dragging its edge, and the width is
remembered. The model page has a new header that shows the model name, a
copyable ID, its state and how long it has been ready. The API also returns a
new readySince field for models that are ready.

The Hardware page now recognizes DGX Spark (GB10) systems. Before this, it
could not count sockets on arm64, labeled the unified memory as dedicated
memory it could not detect, showed only the efficiency cores and had no power
figure. It now shows the system model, the hybrid CPU layout, shared memory
and the nominal 140 W SoC power.

The "install as app" prompt now works when apiKeys is set. The browser fetches
the web app manifest without an API key, so it got a 401. The manifest is now
served without auth, like the favicon.

The release process now checks for Claude or Codex before generating the
changelog and uses a newer model for it.

- [PR #1177](https://github.com/mostlygeek/llama-swap/pull/1177) internal/server: serve web app manifest without requiring auth: let browsers fetch site.webmanifest when apiKeys is set so the install prompt appears
- AGENTS.md: revise contribution guidelines for PRs: agents check pull requests and issues against CONTRIBUTING.md and ask when there is a problem
- [PR #1172](https://github.com/mostlygeek/llama-swap/pull/1172) Refactor logging to support multiple streams and separate log endpoints: split proxy, upstream and HTTP logs, add /api/events/logs and allow a stream list in logToStdout
- [PR #1163](https://github.com/mostlygeek/llama-swap/pull/1163) hw: detect DGX Spark (GB10) systems: report the system model, hybrid CPU, sockets, shared memory and nominal power on GB10 boxes by [@lemassykoi](https://github.com/lemassykoi)
- [PR #1173](https://github.com/mostlygeek/llama-swap/pull/1173) ui: sidebar resize, model uptime tracking, small tweaks: drag to resize the sidebar and show how long each model has been ready
- scripts/add-changelog.sh: use gpt-6-sol: update the model used to generate changelog entries with Codex
- Makefile: detect harness before release: use Claude or Codex to generate the changelog and stop with an error when neither is installed

## v258

Tailcat is updated to v0.7.0 and now checks allowed clients in the HTTP
handler. A client that is not allowed gets a 403 instead of a TCP timeout,
which makes peer connections much easier to troubleshoot, and changes to
tailcat.allow now apply on hot reload. A bug that dropped the connection when
a node key was not recognized, which could leave clients hanging, now also
returns a 403. Peer connections recover better when the server disconnects,
and they wait longer for the first response header by default.

Upgrading: an empty tailcat.allow list now denies every client. To keep
allowing anyone to connect, set tailcat.allow to "\*".

The output of cmdStop goes to the process log again, the same as cmd. This was
lost in an earlier change (#790). A cmdStop that leaves a background child
holding its output open can no longer hang the stop, and hitting that wait
limit after a successful stop is logged as a warning instead of a failure.

The Models page shows a status icon for each target of the selected profile,
and those models can be loaded and unloaded from the profile pane.

The unified Docker image adds mp3 support and native downloads to audio.cpp.
The image build also stops failing on untagged main-branch commits. Those
builds fell back to looking up the "latest" release through the GitHub API,
which rate limited the shared CI runners. The installers now build the commit
directly and fall back to git tags when the API is not available.

Release notes on GitHub now use the CHANGELOG.md entry for the tag, and
changelog entries are written as plain-language summaries that credit outside
contributors.

- release: improve generated changelog and release notes: generate readable changelog entries, credit outside contributors and use each entry as the GitHub release notes
- [PR #1169](https://github.com/mostlygeek/llama-swap/pull/1169) internal/tailcat: various reliability and bug fixes: return a 403 for unrecognized node keys, improve peer reconnects and raise the default time to first header
- [PR #1170](https://github.com/mostlygeek/llama-swap/pull/1170) ui: link profile targets and add load controls: show status and load/unload controls for profile target models by [@sousekd](https://github.com/sousekd)
- [PR #1165](https://github.com/mostlygeek/llama-swap/pull/1165) internal/process: log cmdStop stdout and stderr: send cmdStop output to the process log and stop a lingering child from hanging it by [@dividehex](https://github.com/dividehex)
- [PR #1166](https://github.com/mostlygeek/llama-swap/pull/1166) internal/tailcat: upgrade to tailcat v0.7.0 and use Server.Listen: check tailcat.allow per request, deny by default when empty and add a "\*" wildcard
- [PR #1157](https://github.com/mostlygeek/llama-swap/pull/1157) docker/unified: audio.cpp add download and mp3 support: add mp3 and native download support
- [PR #1156](https://github.com/mostlygeek/llama-swap/pull/1156) docker/unified: fix vllm-wrapper build on untagged commits: build untagged commits directly and fall back to git tags when the GitHub API is rate limited

## v257

Adds Kubernetes-backed model lifecycle management with a Helm chart, readiness
diagnostics, and publishing fixes. Improves CORS controls and forwarded-client
metrics, automatically discovers backend context and modalities, and refines
ComfyUI support. The Playground now has a searchable, capability-aware model
picker, while activity totals remain accurate after pruning.

- [PR #1114](https://github.com/mostlygeek/llama-swap/pull/1114) cmd/kubeswap: kubernetes backend for llama-swap (wrapper + helm chart)
- [PR #1129](https://github.com/mostlygeek/llama-swap/pull/1129) .github/workflows: fix helm chat publishing
- [PR #1131](https://github.com/mostlygeek/llama-swap/pull/1131) cmd/kubeswap/chart: fix the default demo's loopback bind
- internal/server: support proxy forwarded for headers
- internal/server: fix CORS handler returning too early
- [PR #1136](https://github.com/mostlygeek/llama-swap/pull/1136) internal/store: preserve request totals after pruning
- [PR #1145](https://github.com/mostlygeek/llama-swap/pull/1145) docs,server: improve comfyui endpoint and add a guide
- internal/server,internal/config: Add tighter CORS controls
- internal/capcompat: automatic context and modality discovery
- [PR #1153](https://github.com/mostlygeek/llama-swap/pull/1153) ui/playground: add a searchable model picker

## v256

Refreshes Playground chat with a responsive layout, editable prompts, sampling
controls, and live generation statistics across Chat and the Help agent. Adds a
global inference concurrency cap, richer TabbyAPI activity metrics, leaner zstd
memory use, and a storage-layer refactor, alongside release-changelog tooling.

- CHANGELOG.md,docs: fix pull request link
- [PR #1125](https://github.com/mostlygeek/llama-swap/pull/1125) changelog: add scripts and automation to generate changelog entries
- [PR #1120](https://github.com/mostlygeek/llama-swap/pull/1120) ui: make the playground chat responsive and lighter
- [PR #1123](https://github.com/mostlygeek/llama-swap/pull/1123) internal/server: reduce zstd pool memory consumption
- [PR #1122](https://github.com/mostlygeek/llama-swap/pull/1122) internal/store: split repository interfaces from the sqlite backend
- [PR #1095](https://github.com/mostlygeek/llama-swap/pull/1095) process: start TTL idle window when model becomes ready
- [PR #1110](https://github.com/mostlygeek/llama-swap/pull/1110) internal/server: add global concurrency semaphore
- cmd/vllm-wrapper: use default timeouts
- [PR #1104](https://github.com/mostlygeek/llama-swap/pull/1104) internal/server: add tabbyapi usage data extraction
- ui: show chat stats in Help agent
- [PR #1099](https://github.com/mostlygeek/llama-swap/pull/1099) ui: show live generation stats in Chat
- [PR #1101](https://github.com/mostlygeek/llama-swap/pull/1101) ui: keep Work status bar stable while streaming

## v255

Updates Tailcat to v0.6.0, including WireGuard preshared-key support for
Tailcat addresses.

- [PR #1098](https://github.com/mostlygeek/llama-swap/pull/1098) tailcat: update to v0.6.0

## v254

Adds CUDA 13 and arm64 support to unified Docker images, configurable build
targets, safer Tailcat configuration sharing, and expanded Help-agent limits.

- [PR #1093](https://github.com/mostlygeek/llama-swap/pull/1093) docker/unified: add cuda13 with multi-platform support for arm64
- [PR #1075](https://github.com/mostlygeek/llama-swap/pull/1075) filters: set-if-undefined params via "?" key suffix
- [PR #1091](https://github.com/mostlygeek/llama-swap/pull/1091) ui/tailcat: mask connection token, add shareable peer config
- [PR #1089](https://github.com/mostlygeek/llama-swap/pull/1089) ui/help: raise Docs Agent max_tokens from 4096 to 65536

## v253

Refines the Help experience, adds jq queries for config paths, introduces
private Tailcat peers, and makes unified CUDA builds configurable.

- [PR #1088](https://github.com/mostlygeek/llama-swap/pull/1088) ui/help: refine Help agent topics and controls
- [PR #1087](https://github.com/mostlygeek/llama-swap/pull/1087) Replace config path argument with jq query support
- [PR #1074](https://github.com/mostlygeek/llama-swap/pull/1074) tailcat: add private server and peer connectivity
- [PR #1072](https://github.com/mostlygeek/llama-swap/pull/1072) docker/unified: make CUDA version and architectures configurable

## v252

Speeds unified Docker builds, expands documentation and configuration tooling,
and improves model, WOL proxy, modality, and chat-input support.

- [PR #1071](https://github.com/mostlygeek/llama-swap/pull/1071) Split Docker build into per-project stages for CI
- [PR #1070](https://github.com/mostlygeek/llama-swap/pull/1070) ui: improve Help page
- [PR #1054](https://github.com/mostlygeek/llama-swap/pull/1054) internal/reference: add indexed docs and /api/tools endpoints
- [PR #1053](https://github.com/mostlygeek/llama-swap/pull/1053) config,server: add startup profile hook
- [PR #1063](https://github.com/mostlygeek/llama-swap/pull/1063) expose context_window on models endpoint
- [PR #1055](https://github.com/mostlygeek/llama-swap/pull/1055) cmd/wol-proxy: add -api-key option for use in health checks
- [PR #1057](https://github.com/mostlygeek/llama-swap/pull/1057) cmd/wol-proxy: add liveness check
- [PR #1049](https://github.com/mostlygeek/llama-swap/pull/1049) Typo
- [PR #1048](https://github.com/mostlygeek/llama-swap/pull/1048) config: accept video as an input and output modality
- [PR #1046](https://github.com/mostlygeek/llama-swap/pull/1046) cli: add -validate flag to check config and exit
- [PR #1045](https://github.com/mostlygeek/llama-swap/pull/1045) ui: ignore IME composition Enter in keydown handlers

## v251

Records disconnected clients accurately, improves server and vLLM metrics, and
adds deployment, log-rendering, and activity-export improvements.

- [PR #1040](https://github.com/mostlygeek/llama-swap/pull/1040) internal: record client disconnects as 499, not 200 or 502
- [PR #1043](https://github.com/mostlygeek/llama-swap/pull/1043) internal/server: rate limit sendBuffer full warnings
- [PR #1039](https://github.com/mostlygeek/llama-swap/pull/1039) internal/server: parse vLLM speculative decoding metrics
- [PR #1038](https://github.com/mostlygeek/llama-swap/pull/1038) internal/swaputil: OpenAI-compatible error bodies
- [PR #1023](https://github.com/mostlygeek/llama-swap/pull/1023) docker/unified: build audio.cpp as a deployment build
- [PR #1019](https://github.com/mostlygeek/llama-swap/pull/1019) ui: render ANSI colors in logs
- [PR #1020](https://github.com/mostlygeek/llama-swap/pull/1020) ui-svelte: Add markdown activity export

## v250

Adds audio.cpp, llama-bench, and vLLM-wrapper to the unified image, alongside
audio task APIs, model metadata, and argv-based vLLM startup support.

- [PR #1011](https://github.com/mostlygeek/llama-swap/pull/1011) docker/unified: add llama-bench, vllm-wrapper, audio.cpp
- README.md: reorder list of features
- [PR #979](https://github.com/mostlygeek/llama-swap/pull/979) Support argv-based vLLM startup in vllm-wrapper
- [PR #1007](https://github.com/mostlygeek/llama-swap/pull/1007) ui-svelte,internal/server: show capability tags on Models page
- [PR #982](https://github.com/mostlygeek/llama-swap/pull/982) api: support /v1/task/run for audio.cpp
- AGENTS.md: tweak rules around pull requests
- CONTRIBUTING.md: update rules
- [PR #984](https://github.com/mostlygeek/llama-swap/pull/984) expose meta.n_ctx on models endpoint
- [PR #983](https://github.com/mostlygeek/llama-swap/pull/983) router: add /models endpoint

## v249

Adds a ComfyUI compatibility endpoint and reorganizes configuration and shared
package naming.

- [PR #1003](https://github.com/mostlygeek/llama-swap/pull/1003) various: improvements to code layout and naming
- [PR #1002](https://github.com/mostlygeek/llama-swap/pull/1002) internal/server: add ComfyUI compatibility endpoint

## v248

Preserves percent-encoded paths when proxying requests upstream.

- [PR #988](https://github.com/mostlygeek/llama-swap/pull/988) internal/server,shared: preserve percent encoded in upstream

## v247

Updates the Svelte UI for security and adds inference-host hardware detection.

- ui-svelte: security update
- [PR #978](https://github.com/mostlygeek/llama-swap/pull/978) internal/hw: detect inference host hardware

## v246

Displays configured selectors in the Models page and improves ROCm GPU-memory
reporting and Vulkan image diagnostics.

- [PR #975](https://github.com/mostlygeek/llama-swap/pull/975) ui-svelte: show configured selectors and strategies on Models page
- [PR #973](https://github.com/mostlygeek/llama-swap/pull/973) internal/perf: fix rocm-smi GPU memory utilization
- [PR #968](https://github.com/mostlygeek/llama-swap/pull/968) docker: install rocm-smi for vulkan backend

## v245

Adds profile details to the Models page and supports watching Docker
configuration changes.

- [PR #966](https://github.com/mostlygeek/llama-swap/pull/966) ui-svelte: show profiles on model page
- [PR #964](https://github.com/mostlygeek/llama-swap/pull/964) AGENTS.md,CONTRIBUTING.md: update contribution guidelines
- [PR #963](https://github.com/mostlygeek/llama-swap/pull/963) docker: add -watch-config

## v244

Reworks matrix evaluation to solve expressions symbolically, greatly improving
performance for large configurations.

- [PR #960](https://github.com/mostlygeek/llama-swap/pull/960) internal/matrix: solve matrix expressions symbolically

## v243

Relaxes matrix reference constraints and adds a vLLM-wrapper helper for model
sleep and wake operations.

- [PR #957](https://github.com/mostlygeek/llama-swap/pull/957) internal/config: relax matrix model reference constraints
- [PR #941](https://github.com/mostlygeek/llama-swap/pull/941) cmd/vllm-wrapper: add helper for sleep/wake
- [PR #955](https://github.com/mostlygeek/llama-swap/pull/955) internal/config: refactor macro expansion

## v242

Adds namespaced peer-model support throughout routing and the UI, fixes a
concurrent process-start race, and removes the audio upload size limit.

- [PR #950](https://github.com/mostlygeek/llama-swap/pull/950) internal/server,ui-svelte: add peer model namespaces
- [PR #949](https://github.com/mostlygeek/llama-swap/pull/949) Fix process start race during concurrent stop operations
- [PR #948](https://github.com/mostlygeek/llama-swap/pull/948) ui-svelte: remove audio file size limit

## v241

Introduces selector strategies and profiles, streamlines model request handling,
supports more audio voice formats, and adds FFmpeg to the Docker image.

- [PR #942](https://github.com/mostlygeek/llama-swap/pull/942) internal/server: implement selectors
- [PR #940](https://github.com/mostlygeek/llama-swap/pull/940) internal/server,shared: reduce request model body functions to one
- [PR #935](https://github.com/mostlygeek/llama-swap/pull/935) internal/server: add support for profiles
- [PR #932](https://github.com/mostlygeek/llama-swap/pull/932) ui-svelte: add support for different v1/audio/voices response formats
- [PR #785](https://github.com/mostlygeek/llama-swap/pull/785) docker: add FFmpeg support for whisper.cpp

## v240

Expands inflight request details, adds configurable unload timeouts, and
reduces UI bundle sizes while preserving YAML capability anchors.

- [PR #923](https://github.com/mostlygeek/llama-swap/pull/923) internal/server: expand inflight request details
- [PR #904](https://github.com/mostlygeek/llama-swap/pull/904) Add configurable UnloadTimeout variable
- [PR #925](https://github.com/mostlygeek/llama-swap/pull/925) ui-svelte: code-split routes and trim highlight.js/chart.js bundles
- .coderabbit.yaml: disable annoying unit test creation
- [PR #918](https://github.com/mostlygeek/llama-swap/pull/918) internal/config: preserve yaml anchors in capabilities

## v239

Preserves YAML anchors in capability configuration.

- internal/config: preserve yaml anchors in capabilities

## v238

Improves vLLM response metrics and resolves macros in capability fields.

- [PR #913](https://github.com/mostlygeek/llama-swap/pull/913) internal/server: improve vllm response metric calculation
- [PR #907](https://github.com/mostlygeek/llama-swap/pull/907) internal/config: resolve macros in capabilities fields

## v237

Adds vLLM metrics, timestamps older activity logs, and removes WOL proxy
restart lag.

- [PR #911](https://github.com/mostlygeek/llama-swap/pull/911) ui-svelte: activity logs older than a day show a timestamp
- [PR #910](https://github.com/mostlygeek/llama-swap/pull/910) internal/server: support vLLM metrics
- [PR #909](https://github.com/mostlygeek/llama-swap/pull/909) cmd/wol-proxy: remove lag when llama-swap restarts
- Remove Star History section from README

## v236

Adds llama-server model status and persists activity metrics in SQLite.

- [PR #901](https://github.com/mostlygeek/llama-swap/pull/901) internal/server: add status to v1/models for llama-server
- [PR #898](https://github.com/mostlygeek/llama-swap/pull/898) internal/store: persist activity metrics to sqlite
- fix starhistory

## v235

Shows inflight activity requests, adds llama-tts to builds, and improves build
version stamping.

- [PR #895](https://github.com/mostlygeek/llama-swap/pull/895) internal/server: show inflight activity requests
- [PR #894](https://github.com/mostlygeek/llama-swap/pull/894) Add llama-tts binary
- [PR #891](https://github.com/mostlygeek/llama-swap/pull/891) Makefile: improve build version stamping

## v234

Rejects excess concurrent requests before streaming and adds model route
properties.

- [PR #889](https://github.com/mostlygeek/llama-swap/pull/889) internal/router: reject concurrency excess before streaming
- [PR #886](https://github.com/mostlygeek/llama-swap/pull/886) add /props to modelGetRoutes

## v233

Decouples log broadcasting from writes and makes UI embedding opt-in at build
time.

- [PR #878](https://github.com/mostlygeek/llama-swap/pull/878) internal/logmon: decouple log broadcast from Write
- [PR #880](https://github.com/mostlygeek/llama-swap/pull/880) internal/server: gate UI embed behind embed_ui build tag

## v232

Refreshes the UI with rounded borders and an updated hero image.

- ui-svelte: add rounded borders
- update hero image

## v231

Adds the shadcn-svelte UI foundation, theming, and refreshed screenshots.

- Update screenshots
- [PR #877](https://github.com/mostlygeek/llama-swap/pull/877) ui: add shadcn-svelte foundation and theming
- AGENTS.md: small tweaks

## v230

Adds a configurable configuration-directory option and watcher support.

- [PR #873](https://github.com/mostlygeek/llama-swap/pull/873) internal/config,watcher: add -config-dir

## v229

Adds ignored upstream paths, failed-request captures, and activity columns,
with improved performance-menu visibility.

- [PR #869](https://github.com/mostlygeek/llama-swap/pull/869) config,server: add upstream.ignorePaths
- [PR #832](https://github.com/mostlygeek/llama-swap/pull/832) feat: hide performance menu item if disabled
- [PR #862](https://github.com/mostlygeek/llama-swap/pull/862) server: capture failed (non-200) LLM requests
- [PR #859](https://github.com/mostlygeek/llama-swap/pull/859) internal/server,ui: add new Activity page column - Drafted

## v228

Meters /upstream requests through the metrics middleware.

- [PR #858](https://github.com/mostlygeek/llama-swap/pull/858) proxy: meter /upstream requests via metrics middleware

## v227

Adds experimental Windows GPU monitoring, request metadata, scheduler-based
concurrency limits, and a MacPorts installation option.

- [PR #779](https://github.com/mostlygeek/llama-swap/pull/779) perf: add vendor-agnostic GPU monitoring for Windows (experimental)
- [PR #850](https://github.com/mostlygeek/llama-swap/pull/850) internal/server,shared: support request metadata
- .coderabbit.yaml: disable unit_tests
- [PR #849](https://github.com/mostlygeek/llama-swap/pull/849) schedule,shared: move concurrency 429 limits into scheduler code
- [PR #848](https://github.com/mostlygeek/llama-swap/pull/848) README.md: add macports install option to README

## v226

Improves manual model loading and cancellation in the UI.

- [PR #847](https://github.com/mostlygeek/llama-swap/pull/847) ui: improve manual model load and cancel

## v225

Adds model capabilities and a new scheduler, while refactoring authentication
and showing a warning for network listeners.

- [PR #842](https://github.com/mostlygeek/llama-swap/pull/842) Model capabilities 734
- [PR #839](https://github.com/mostlygeek/llama-swap/pull/839) internal/router,server,shared: refactor auth, libs
- main: gofmt
- [PR #836](https://github.com/mostlygeek/llama-swap/pull/836) main: show message when listening on network
- [PR #823](https://github.com/mostlygeek/llama-swap/pull/823) Implement new scheduler

## v224

Fixes websocket and unload regressions, removes legacy proxy code, and improves
Docker arm64 downloads.

- [PR #830](https://github.com/mostlygeek/llama-swap/pull/830) Makefile,internal: fix websocket regression and other small things
- [PR #828](https://github.com/mostlygeek/llama-swap/pull/828) internal/process,server: fix unload regression
- [PR #822](https://github.com/mostlygeek/llama-swap/pull/822) proxy: remove legacy code
- [PR #819](https://github.com/mostlygeek/llama-swap/pull/819) docker: fix arm64 cpu image downloading amd64 llama-swap binary
- Change cron schedule for container builds

## v223

Adds macOS GPU monitoring using mactop and ioreg.

- [PR #816](https://github.com/mostlygeek/llama-swap/pull/816) perf: add macOS GPU monitoring via mactop and ioreg

## v222

Improves Windows process shutdown behavior.

- [PR #808](https://github.com/mostlygeek/llama-swap/pull/808) internal/process: improve windows shutdown behaviour

## v221

Makes model shutdown and load streaming more robust.

- process,router: make model shutdown and load-streaming robust

## v220

Adds a UI load-testing tool and returns JSON responses for concurrency limits.

- [PR #805](https://github.com/mostlygeek/llama-swap/pull/805) Add load testing tool to the UI
- [PR #798](https://github.com/mostlygeek/llama-swap/pull/798) fix: update the concurrency middleware to respond with a JSON payload

## v219

Includes release refinements and updates the UI build directory.

- Makefile,internal/server: various release tweaks
- [PR #801](https://github.com/mostlygeek/llama-swap/pull/801) ui-svelte: update build directory

## v218

Introduces a new routing backend and adds a power-draw column for ROCm metrics.

- [PR #790](https://github.com/mostlygeek/llama-swap/pull/790) Introduce new routing backend
- [PR #788](https://github.com/mostlygeek/llama-swap/pull/788) Add new power draw column header for rocm-smi monitoring

## v217

Improves ROCm and Windows GPU monitoring, plus configuration and automation
maintenance.

- [PR #775](https://github.com/mostlygeek/llama-swap/pull/775) Improve rocm-smi performance monitoring
- [PR #773](https://github.com/mostlygeek/llama-swap/pull/773) Added Windows performance monitoring using nvidia-smi
- Disable auto review feature in coderabbit config
- Increase inactivity thresholds for stale issues
- config.example.yaml: Improve matrix vs groups info

## v216

Updates the UI link to the performance discussion thread.

- ui-svelte: update link to performance discussion thread

## v215

Adds ROCm GPU statistics through rocm-smi.

- [PR #767](https://github.com/mostlygeek/llama-swap/pull/767) Add ROCm stats via rocm-smi

## v214

Fixes cached-token totals and updates nvidia-smi polling for newer drivers.

- [PR #760](https://github.com/mostlygeek/llama-swap/pull/760) ui-svelte: fix cached tokens total counting -1 sentinel
- [PR #759](https://github.com/mostlygeek/llama-swap/pull/759) fix: use --loop instead of -loop for nvidia-smi

## v213

Updates UI packages and improves compatibility with v1/messages and
v1/responses endpoints.

- ui-svelte: package updates
- [PR #758](https://github.com/mostlygeek/llama-swap/pull/758) proxy,ui-svelte: improve support for v1/messages and v1/responses

## v212

Adds multi-architecture CPU images, Prometheus performance metrics, automatic
themes, and several CI and proxy fixes.

- ci: set go-version-file in release workflow
- ci: fix workflow bugs in release and go-ci
- [PR #750](https://github.com/mostlygeek/llama-swap/pull/750) Changes and fixes before the release (docs/small tweaks)
- [PR #753](https://github.com/mostlygeek/llama-swap/pull/753) perf: ignore LACT devices reporting zero VRAM
- [PR #751](https://github.com/mostlygeek/llama-swap/pull/751) ci: use manifest-aware cleanup action for multi-arch :cpu
- [PR #746](https://github.com/mostlygeek/llama-swap/pull/746) Multi arch cpu
- [PR #748](https://github.com/mostlygeek/llama-swap/pull/748) proxy: fix data race in /running endpoint and typo in error message
- [PR #741](https://github.com/mostlygeek/llama-swap/pull/741) ui: add auto theme switch mode based on system theme
- [PR #743](https://github.com/mostlygeek/llama-swap/pull/743) proxy,ui: add performance monitoring with Prometheus metrics
- [PR #733](https://github.com/mostlygeek/llama-swap/pull/733) proxy: add versionless API endpoint
- [PR #731](https://github.com/mostlygeek/llama-swap/pull/731) llama-swap.go: remove debounce, replace fmt.Printlns

## v211

Fixes process logging when matrix configuration selects processes.

- proxy: fix logger not checking matrix for processes

## v210

Fixes non-streaming response durations and improves no-history and log
monitoring behavior.

- [PR #723](https://github.com/mostlygeek/llama-swap/pull/723) proxy: fix zero duration for non streaming responses
- [PR #721](https://github.com/mostlygeek/llama-swap/pull/721) fix: ?no-history flag and improve /logs monitoring docs

## v209

Refactors the Activity page, removes the macro-length cap, and improves theme
and log-panel controls.

- [PR #710](https://github.com/mostlygeek/llama-swap/pull/710) Refactor Activity Page
- [PR #718](https://github.com/mostlygeek/llama-swap/pull/718) config: remove hard cap on macro length
- [PR #712](https://github.com/mostlygeek/llama-swap/pull/712) ui-svelte: default theme to user preferred color scheme
- ui-svelte: make it easier to toggle panels in logs view

## v208

Adds reasoning-content support and prompt-processing histograms, and fixes
architecture-specific installation downloads.

- [PR #708](https://github.com/mostlygeek/llama-swap/pull/708) ui-svelte: support reasoning and reasoning_content
- [PR #705](https://github.com/mostlygeek/llama-swap/pull/705) ui-svelte: add prompt processing histogram
- [PR #698](https://github.com/mostlygeek/llama-swap/pull/698) fix: support architecture-specific download URLs in install script

## v207

No user-facing changes were included between v206 and v207.

## v206

Fixes UI histogram calculation and publishes unified Docker images on scheduled
runs.

- [PR #695](https://github.com/mostlygeek/llama-swap/pull/695) ui-svelte: fix histogram calculation
- [PR #694](https://github.com/mostlygeek/llama-swap/pull/694) Push unified docker images on scheduled runs

## v205

Replaces the file watcher with stat polling and SIGHUP reloads, and adds uv to
the unified Docker image.

- [PR #685](https://github.com/mostlygeek/llama-swap/pull/685) proxy: replace fsnotify with stat-poll watcher and add SIGHUP reload
- [PR #681](https://github.com/mostlygeek/llama-swap/pull/681) docker/unified: add uv via pip install

## v204

Fixes matrix and process-stop races and improves unified-image build workflows.

- [PR #677](https://github.com/mostlygeek/llama-swap/pull/677) proxy: fix matrix race and process stop bug
- [PR #676](https://github.com/mostlygeek/llama-swap/pull/676) .github/workflows: tweak push ghcr conditional
- [PR #672](https://github.com/mostlygeek/llama-swap/pull/672) .github/workflows: add toggle for pushing unified images to github
- [PR #669](https://github.com/mostlygeek/llama-swap/pull/669) docker/unified: add spirv-headers to fix vulkan build

## v203

Adds zstd capture compression, fixes swap races, and restores Linux arm64 build
targets.

- [PR #668](https://github.com/mostlygeek/llama-swap/pull/668) proxy: compress captures with zstd
- [PR #667](https://github.com/mostlygeek/llama-swap/pull/667) proxy: fix race conditions during swap
- [PR #660](https://github.com/mostlygeek/llama-swap/pull/660) proxy: Refactor tests
- Makefile: restore linux arm64 targets

## v202

Introduces solver-based matrix model swapping, updates matrix documentation,
and fixes UI security issues.

- docs: update configuration.md for matrix
- README.md: update to use matrix instead of groups
- [PR #646](https://github.com/mostlygeek/llama-swap/pull/646) proxy: add swap matrix with solver-based model swapping
- [PR #649](https://github.com/mostlygeek/llama-swap/pull/649) ui-svelte: fix security issues

## v201

Restores proxy timeouts and derives a rootless unified image from the root
container.

- [PR #648](https://github.com/mostlygeek/llama-swap/pull/648) proxy,proxy/config: restore timeouts to pre PR 619
- [PR #644](https://github.com/mostlygeek/llama-swap/pull/644) docker/unified: derive rootless image from root container

## v200

Adds a rootless unified image, configurable HTTP and CUDA settings, preserved
metrics durations, and several Docker and CI improvements.

- [PR #630](https://github.com/mostlygeek/llama-swap/pull/630) docker/unified: publish rootless image variant
- [PR #629](https://github.com/mostlygeek/llama-swap/pull/629) proxy: preserve wall-clock duration in metrics
- [PR #619](https://github.com/mostlygeek/llama-swap/pull/619) proxy: add configurable HTTP timeouts for models and peers
- [PR #627](https://github.com/mostlygeek/llama-swap/pull/627) ci: validate config.example.yaml against config-schema.json
- [PR #625](https://github.com/mostlygeek/llama-swap/pull/625) docker: make CMAKE_CUDA_ARCHITECTURES configurable via build arg
- [PR #620](https://github.com/mostlygeek/llama-swap/pull/620) docker/unified: add ik_llama.cpp to CUDA container
- add /sdapi to list of supported endpoints
- [PR #616](https://github.com/mostlygeek/llama-swap/pull/616) docker/unified: build llama.cpp with static libraries
- [PR #610](https://github.com/mostlygeek/llama-swap/pull/610) ci: fix matrix exclude for scheduled docker workflow
- [PR #606](https://github.com/mostlygeek/llama-swap/pull/606) docker/unified,.github: fix unified build
- [PR #605](https://github.com/mostlygeek/llama-swap/pull/605) build(deps): bump picomatch from 4.0.3 to 4.0.4 in /ui-svelte
