# llama-swap Helm chart

Installs the llama-swap head-end (router + lifecycle manager) into a
namespace, with the ServiceAccount and RBAC it needs, a ConfigMap holding
`config.yaml`, a Service, and optional Ingress / Gateway API exposure.
Because the head-end runs `kubeswap` as its `cmd`/`cmdStop` for every
model, the whole inference fleet — backend pods, their PVCs, teardown —
stays inside the same namespace the chart manages.

The head-end image must ship `/usr/local/bin/llama-swap` and
`/usr/local/bin/kubeswap`. The unified llama-swap images do, and also
ship every backend server (`llama-server`, `sd-server`,
`whisper-server`, `audiocpp_server`), so one image covers the head-end
and all backend pods.

## Install

From the published OCI registry (one chart version per llama-swap
release):

```bash
helm install llama-swap oci://ghcr.io/mostlygeek/charts/llama-swap \
  -n llama-swap --create-namespace \
  --version 256.0.0    # the chart version for release v256; omit for latest
```

Versioning follows the llama-swap release convention: tag `vNNN` publishes
chart version `NNN.0.0` with appVersion `NNN`. The published chart ships
`image.tag` unset, so its default image is derived from the app version
(`unified-vulkan-<appVersion>`) rather than codified into the tag string.
The publish workflow (`.github/workflows/publish-chart.yml`) mints the
versioned docker tags `unified-<variant>-NNN` as manifest aliases of the
current floating `unified-<variant>` tags before publishing, so the names
the chart references exist (each alias's digest is logged). Override
`image.tag` per variant (`unified-cuda-NNN`, `unified-cuda13-NNN`) or to a
floating tag.

The workflow also runs on manual dispatch, which takes the ref to publish
from (a tag, a branch or a commit) and the release number separately. That
is how a chart change reaches the registry without tagging a release, and
how a release tagged before this chart existed gets one; the release
number is required whenever the ref is not a `vNNN` tag.

For development, install from a checkout instead (the chart lives in
`cmd/kubeswap/chart/`, with the floating image tag by default):

```bash
helm install llama-swap ./cmd/kubeswap/chart \
  -n llama-swap --create-namespace
```

The chart never renders a Namespace object — create the release
namespace yourself (`--create-namespace` above) or point the install
at one that already exists.

The default `values.yaml` is a demo config: one tiny model (SmolLM2,
~135MB) that llama-server downloads from Hugging Face on demand into a
per-pod emptyDir — no PVC required. For real use, override
`config.inline` with your models and point them at a model cache (see
"Model cache PVC" below).

```bash
helm install llama-swap cmd/kubeswap/chart -n llama-swap --create-namespace \
  --set-file config.inline=/path/to/your-config.yaml
```

`config.inline` is processed as a Go template, so `{{ .Release.Namespace }}`
works inside model commands (it is how the default config keeps
`--namespace` correct). llama-swap's own `${PORT}` macro is unaffected.

## Values

| key | default | meaning |
| --- | --- | --- |
| `image.repository` | `ghcr.io/mostlygeek/llama-swap` | head-end image |
| `image.tag` | `unified-vulkan` (dev); published release charts ship it unset and derive `unified-vulkan-<appVersion>` | `unified-cuda13` / `unified-cuda` for NVIDIA |
| `image.pullPolicy` | `IfNotPresent` | |
| `imagePullSecrets` | `[]` | list of secret names |
| `replicas` | `1` | must be 1 (the chart fails on more) — never two head-ends per namespace |
| `strategy.type` | `Recreate` | deliberate (see replicas) |
| `config.inline` | demo config | `config.yaml`, templated, into the chart's ConfigMap |
| `config.top` | `{}` | structured: everything except `models:` (scalars, macros, routing); templated |
| `config.defaults` | `{}` | structured: per-model defaults (see "Structured config") |
| `config.models` | `[]` | structured: list of model entries; non-empty ⇒ `config.inline` is ignored |
| `config.existing` | `""` | use this ConfigMap instead (chart renders none) |
| `config.extraFiles` | `{}` | extra ConfigMap keys (e.g. an audio.cpp server JSON) |
| `serviceAccount.create` | `true` | |
| `serviceAccount.name` | fullname | |
| `serviceAccount.annotations` | `{}` | e.g. workload-identity |
| `rbac.create` | `true` | namespaced Role + RoleBinding for kubeswap |
| `rbac.rules` | (kubeswap minimum) | deployments/services CRUD, PVC get/create/delete, pods get/list, pods/log |
| `service.type` | `ClusterIP` | `LoadBalancer` / `NodePort` work unchanged |
| `service.port` | `8080` | |
| `service.annotations` | `{}` | |
| `service.loadBalancerIP` | `""` | LoadBalancer only |
| `service.loadBalancerSourceRanges` | `[]` | LoadBalancer only |
| `service.externalTrafficPolicy` | unset | LoadBalancer/NodePort only |
| `ingress.enabled` | `false` | networking.k8s.io/v1 Ingress |
| `ingress.className` | `""` | |
| `ingress.annotations` | `{}` | |
| `ingress.hosts` | `llama-swap.local` | list of `{host, paths: [{path, pathType}]}` |
| `ingress.tls` | `[]` | standard ingress TLS blocks |
| `gateway.enabled` | `false` | Gateway API; with `name` and `parentRefs` both empty, rendering fails |
| `gateway.gateway.name` | `""` | set to have the chart create a Gateway |
| `gateway.gateway.className` | `""` | required when `name` is set (e.g. `traefik`) |
| `gateway.gateway.listeners` | one HTTP :80 | |
| `gateway.route.name` | fullname | HTTPRoute name |
| `gateway.route.parentRefs` | the chart's Gateway | required when `name` is empty (attach to an existing Gateway) |
| `gateway.route.hostnames` | `[]` | |
| `gcInitContainer.enabled` | `true` | one-shot `kubeswap gc` per head-end start |
| `gcInitContainer.securityContext` | no-escalation, read-only root FS, drop ALL | for the gc init container; `runAsNonRoot` is not defaulted (stock image runs as root) |
| `podAnnotations` / `podLabels` | `{}` | |
| `priorityClassName` | `""` | |
| `nodeSelector` / `tolerations` / `affinity` | standard | schedule the head-end (it needs no GPU) |
| `podSecurityContext` / `securityContext` | `{}` | |
| `resources` | `{}` | |
| `env` / `envFrom` | `[]` | |
| `extraVolumes` / `extraVolumeMounts` | `[]` | head-end pod escape hatches |
| `extraContainers` / `initContainers` | `[]` | sidecars / extra init containers |
| `readinessProbe` / `livenessProbe` | `/health` | |
| `extraResources` | `[]` | full manifests, rendered verbatim |

## Examples

### Model cache PVC via extraResources

The idiomatic multi-node setup: one ReadWriteMany PVC, pre-staged with
model weights, referenced from the models' `kubeswap --volume` flags:

```yaml
extraResources:
  - apiVersion: v1
    kind: PersistentVolumeClaim
    metadata:
      name: llama-swap-models
    spec:
      accessModes: [ReadWriteMany]
      storageClassName: longhorn
      resources:
        requests:
          storage: 35Gi
```

Objects without an explicit namespace get the release namespace; helm
tracks them, so `helm uninstall` removes them too.

### Multi-engine config

Any of the four engine families works in `config.inline`; a complete
verified config (llama-server, sd-server, whisper-server,
audiocpp_server, six models across exclusive swap groups) is
[the kubeswap examples article](../../../../docs/kb/examples/kubeswap-kubernetes.md).
Replace the demo `smollm2` model with entries like:

```yaml
models:
  krea2-turbo:
    proxy: "http://127.0.0.1:${PORT}"
    capabilities: { in: [text], out: [image] }
    cmd: >-
      kubeswap serve
      --listen 127.0.0.1:${PORT}
      --model krea2-turbo
      --namespace {{ .Release.Namespace }}
      --image ghcr.io/mostlygeek/llama-swap:unified-vulkan
      --command sd-server
      --health-path /v1/models
      --gpu amd.com/gpu=1
      --node-selector feature.node.kubernetes.io/amd-gpu=true
      --volume pvc:llama-swap-models:/models:ro
      --
      --diffusion-model /models/krea-2-turbo-Q4_K_M.gguf
      --llm /models/Qwen3VL-4B-Instruct-Q4_K_M.gguf
      --vae /models/wan_2.1_vae.safetensors
      --listen-ip 0.0.0.0
      --listen-port 8080
      --offload-to-cpu
    cmdStop: kubeswap delete --model krea2-turbo --namespace {{ .Release.Namespace }} --wait 60s
    ttl: 7200
```

### Structured config (many models)

For fleets, `config.models` replaces writing the `kubeswap serve`
boilerplate per model: the chart generates each model's `proxy`,
`cmd` (the whole `kubeswap serve ... -- <args>` line) and `cmdStop`.
`config.top` carries everything else (scalars, llama-swap `macros`;
routing comes from `config.matrix` instead, see below) and
`config.defaults` holds what most models share. A key on a
model entry overrides the matching default — an empty list clears it
(`gpu: []` for a CPU-only model).

Kubeswap fields consumed by the chart: `id` (required, unique — a
duplicate fails rendering, since it would overwrite the earlier entry
and share one Deployment), `image`,
`command`, `gpu`, `volumes`, `port`, `extraKubeArgs` (verbatim
`kubeswap serve` flags before `--`, e.g. `"--node-selector k=v"`,
`"--request cpu=4"`), `startupTimeout`, `healthPath`, `livenessPath`,
`checkPath`, `args` (backend command line after `--`), `proxy`,
`cmdStop`. Every other key renders verbatim as a llama-swap model field
(`name`, `ttl`, `capabilities`, `macros`, `filters`, `aliases`, ...).

`args` is rendered verbatim and is **not** Go-templated (unlike
`config.top`, `proxy`, `extraFiles` and the other model fields), so
literal `{{ }}` in backend arguments is safe; everything else in the
rendered config is templated.

```yaml
config:
  top:                        # templated like config.inline
    healthCheckTimeout: 600
    macros:                   # llama-swap macros keep the args DRY
      server_base: --port 8080 -ngl 99
      sd_base: --listen-ip 0.0.0.0 --listen-port 8080 --diffusion-fa --offload-to-cpu
  defaults:
    image: ghcr.io/mostlygeek/llama-swap:unified-vulkan
    command: llama-server
    gpu: [amd.com/gpu=1]
    volumes: [pvc:llama-swap-models:/models:ro]
    extraKubeArgs: ["--node-selector feature.node.kubernetes.io/amd-gpu=true"]
    ttl: 1800
  models:
    - id: lfm25-230m
      args: ${server_base} --model /models/LFM2.5-230M-Q4_0.gguf
    - id: krea2-turbo
      command: sd-server
      healthPath: /v1/models
      capabilities: { in: [text], out: [image] }
      args: ${sd_base} --diffusion-model /models/krea.gguf --llm /models/llm.gguf --vae /models/vae.safetensors
    - id: whisper
      command: whisper-server
      gpu: []                 # empty list clears the default
      args: --host 0.0.0.0 --port 8080 --model /models/whisper.bin
```

`args` still composes with llama-swap's `${...}` macros from
`top.macros`. One limit: model maps render with sorted keys and
llama-swap expands macros in reverse declaration order, so a model
macro must not reference another model macro of the same model (global
macros and literals are fine).

### Matrix router builder

`config.matrix` generates the llama-swap `routing` section from the
`config.models` roster instead of writing matrix DSL by hand. It
replaces a `routing:` block under `config.top` (defining both fails
rendering).

```yaml
config:
  matrix:
    builder: gpu-budget    # gpu-budget | pools | manual
    budget: 5              # gpu-budget: how many GPU models may run at once
    evict_costs:           # optional: model id -> cost (default 1); a high
      qwen3-8-27b: 10      # cost makes the router evict other models first
    exclusive:             # optional: models that run alone, outside the budget
    - gpt-oss-120b
```

**`gpu-budget`** — "any *N* of the GPU models may run; CPU models are
unlimited and do not count toward *N*". A model is in the GPU pool
when its merged `gpu` list is non-empty (so the usual `defaults.gpu`
makes the fleet GPU-by-default) and in the CPU pool when it is
`gpu: []`. It renders the repeated set-reference construction:

```yaml
routing:
  router:
    use: matrix
    settings:
      matrix:
        sets:
          gpu_pool: (model-a | model-b | …)
          cpu_pool: (model-c & model-d)      # omitted when there are no CPU models
          all: +gpu_pool & +gpu_pool & +gpu_pool & +gpu_pool & +gpu_pool & +cpu_pool
```

Each `+gpu_pool` is one slot; the router evicts the cheapest running
GPU model when a sixth is requested. The budget is a hard cap (a set
never contains more than *N* GPU models), CPU models are never
evicted to make room for GPU ones, and models in no set cannot run
with anything else — so every model lands in a pool automatically.

**`pools`** — the generalization: any number of named pools, each with
its own budget (omit `budget` for a pool whose members all coexist).
Every model entry needs a `pool:` key naming one of the pools; each
pool needs at least one member. This covers category spreads like
"1 big LLM, 1 small LLM, 1 TTS, 1 ASR, 1 embeddings, up to 2 image
models" — one pool per category. Fine-grained displacement rules
between pools (e.g. "image displaces the big LLM") are beyond the
builder; use `manual` for those.

**`manual`** — renders your matrix verbatim, the escape hatch:

```yaml
config:
  matrix:
    builder: manual
    manual:
      vars: { q: qwen }
      evict_costs: { q: 10 }
      sets:
        pair: (q | llama) & whisper
```

Model ids used by the generated builders must match the matrix DSL
identifier charset (`[A-Za-z0-9._-]`); ids with other characters fail
rendering with a message instead of breaking the router at runtime.
`exclusive:` models are left out of the generated pools and get their
own single-member set (`alone-<id>`), so they evict everything and are
evicted by everything. The builder requires `config.models` (it reads
the roster) and is not available with `config.existing` or
`config.inline`.

### Ingress

```yaml
ingress:
  enabled: true
  className: traefik
  hosts:
    - host: llama-swap.example.com
      paths:
        - path: /
          pathType: Prefix
  tls:
    - hosts: [llama-swap.example.com]
      secretName: llama-swap-tls
```

### LoadBalancer service

```yaml
service:
  type: LoadBalancer
  loadBalancerSourceRanges: ["203.0.113.0/24"]
```

### Gateway API

```yaml
gateway:
  enabled: true
  gateway:
    name: shared-gw            # omit to route against an existing Gateway
    className: traefik
    listeners:
      - name: http
        protocol: HTTP
        port: 80
        hostname: llama-swap.example.com # singular: a Gateway listener field
  route:
    hostnames: ["llama-swap.example.com"] # plural: the HTTPRoute field
```

### Existing ConfigMap

```yaml
config:
  existing: my-llama-swap-config   # must contain a config.yaml key
```

## Notes

- **Compatibility**: the chart and the kubeswap binary in the image are
  versioned together in this repo; this chart is tested against kubeswap
  as it exists on this branch. If you mix a newer image with an older
  chart (or vice versa), check `rbac.rules`, the probe values and the
  config rendering against the kubeswap changes in between.
- **Upgrade behavior**: `helm upgrade` changes to `config.inline` update
  the ConfigMap; the head-end runs with `-watch-config`, so model
  changes apply on reload (added/removed models are unloaded/reloaded
  through the normal `cmd`/`cmdStop` lifecycle). Changing pod labels
  (`selectorLabels`) is not supported — helm's immutable selector.
- **GPU**: the head-end needs no GPU. Backends request GPUs from inside
  `config.inline` (`kubeswap --gpu ... --node-selector ...`), so the
  chart stays GPU-agnostic.
- **Uninstall**: `helm uninstall` removes head-end, RBAC and
  `extraResources`, but **not** backend workloads created at runtime —
  stop the head-end first (or run
  `kubeswap gc --namespace <ns> --config <path>` /
  `kubectl -n <ns> delete deploy -l llama-swap.io/managed-by=llama-swap`).
