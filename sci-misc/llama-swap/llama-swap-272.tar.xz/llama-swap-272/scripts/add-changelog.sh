#!/usr/bin/env bash
# Add a CHANGELOG.md entry by asking an AI coding harness to follow the
# repository's release-note rules.

set -euo pipefail

usage() {
  cat <<'EOF'
Usage: scripts/add-changelog.sh [harness] [version]
       scripts/add-changelog.sh [version]

Creates changelog/v<version>.md with the release entry. The harness is
codex, claude, opencode or pi and defaults to pi. When version is
omitted it is the highest v<number> tag plus one.

Environment:
  CHANGELOG_MODEL  Model passed to the harness. Defaults to the harness
         specific model (gpt-6-sol for codex, claude-opus-5-5 for claude,
         qwen-3.8-next for pi). Ignored by opencode.
EOF
}

validate_version() {
  local version="$1"

  if [[ ! "$version" =~ ^v[0-9]+$ ]]; then
    printf 'Version must be in the form v<number>, for example v256.\n' >&2
    exit 1
  fi
}

next_version() {
  local highest

  highest="$(git tag --sort=-v:refname | grep -E '^v[0-9]+$' | head -n 1 || true)"
  printf 'v%d\n' "$(( ${highest#v} + 1 ))"
}

check_changelog() {
  local version="$1" file

  file="changelog/${version}.md"

  if ! git diff --quiet -- CHANGELOG.md changelog/; then
    printf 'CHANGELOG.md or changelog/ has unstaged changes. Commit, stage or stash them first.\n' >&2
    exit 1
  fi

  if [[ -e "$file" ]]; then
    printf '%s already exists.\n' "$file" >&2
    exit 1
  fi
}

changelog_prompt() {
  local version="$1"

  printf '%s\n' "Use docs/changelog-rules.md to create the file changelog/${version}.md containing the ${version} release entry. The release changes are committed: inspect them with git log from the last release tag to HEAD (or main as the rules require). Read each commit's full message and use gh pr view to read each pull request's description and author. Do not use Git reflogs or .git/logs paths. Complete the edit before replying; do not only describe the planned work. Make only the required changelog update."
}

run_codex() {
  local prompt="$1"

  codex exec \
    --approve-for-me \
    --model "${CHANGELOG_MODEL:-gpt-6-sol}" \
    -c 'model_reasoning_effort="medium"' \
    "$prompt"
}

run_claude() {
  local prompt="$1"

  claude --print \
    --model "${CHANGELOG_MODEL:-claude-opus-5-5}" \
    --permission-mode acceptEdits \
    --allowedTools 'Read' 'Edit' 'Bash(git log:*)' 'Bash(git tag:*)' \
      'Bash(git show:*)' 'Bash(gh pr view:*)' \
    -- "$prompt" </dev/null
}

run_opencode() {
  local prompt="$1"

  opencode run "$prompt"
}

run_pi() {
  local prompt="$1"

  pi --print \
    --model "${CHANGELOG_MODEL:-qwen-3.8-next}" \
    -- "$prompt" </dev/null
}

main() {
  if [[ $# -gt 2 ]]; then
    usage >&2
    exit 1
  fi

  local harness="pi"
  local version=""

  # The harness is optional: a leading v<number> is taken as the version.
  if [[ $# -gt 0 && "$1" =~ ^v[0-9]+$ ]]; then
    version="$1"
  else
    harness="${1:-pi}"
    version="${2:-}"
  fi
  local repo_root
  local prompt

  repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
  cd "$repo_root"
  if [[ -z "$version" ]]; then
    version="$(next_version)"
  fi
  validate_version "$version"
  check_changelog "$version"
  printf 'Adding changelog entry for %s using %s\n' "$version" "$harness"
  prompt="$(changelog_prompt "$version")"

  case "$harness" in
    codex)
      run_codex "$prompt"
      ;;
    claude)
      run_claude "$prompt"
      ;;
    opencode)
      run_opencode "$prompt"
      ;;
    pi)
      run_pi "$prompt"
      ;;
    *)
      printf 'Unknown harness: %s\n' "$harness" >&2
      usage >&2
      exit 1
      ;;
  esac
}

main "$@"
