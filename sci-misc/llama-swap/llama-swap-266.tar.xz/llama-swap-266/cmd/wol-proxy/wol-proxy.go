package main

import (
	"bufio"
	"context"
	_ "embed"
	"errors"
	"flag"
	"fmt"
	"io"
	"log/slog"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"os/signal"
	"strings"
	"sync"
	"time"
)

//go:embed index.html
var loadingPageHTML string

//go:embed confirm.html
var confirmPageHTML string

// wakePath is the endpoint the confirmation page posts to when -require-confirm is set
const wakePath = "/wol-wake"

// wake durations longer than this are discarded, they most likely mean the
// wake failed and the upstream was started some other way much later
const maxTrackedWake = 10 * time.Minute

var (
	flagMac      = flag.String("mac", "", "mac address to send WoL packet to")
	flagUpstream = flag.String("upstream", "", "upstream proxy address to send requests to")
	flagListen   = flag.String("listen", ":8080", "listen address to listen on")
	flagLog      = flag.String("log", "info", "log level (debug, info, warn, error)")
	flagTimeout  = flag.Int("timeout", 60, "seconds requests wait for upstream response before failing")
	flagAPIKey   = flag.String("api-key", "", "API key sent as Bearer token to the upstream SSE endpoint (falls back to LLAMA_SWAP_API_KEY env var)")

	flagRequireConfirm = flag.Bool("require-confirm", false, "do not wake the upstream automatically; the root page asks for confirmation first and other requests return an error")
)

func main() {
	flag.Parse()

	switch *flagLog {
	case "debug":
		slog.SetLogLoggerLevel(slog.LevelDebug)
	case "info":
		slog.SetLogLoggerLevel(slog.LevelInfo)
	case "warn":
		slog.SetLogLoggerLevel(slog.LevelWarn)
	case "error":
		slog.SetLogLoggerLevel(slog.LevelError)
	default:
		slog.Error("invalid log level", "logLevel", *flagLog)
		return
	}

	// Validate flags
	if *flagListen == "" {
		slog.Error("listen address is required")
		return
	}

	if *flagMac == "" {
		slog.Error("mac address is required")
		return
	}

	if *flagTimeout < 1 {
		slog.Error("timeout must be greater than 0")
		return
	}

	var upstreamURL *url.URL
	var err error
	// validate mac address
	if _, err = net.ParseMAC(*flagMac); err != nil {
		slog.Error("invalid mac address", "error", err)
		return
	}

	if *flagUpstream == "" {
		slog.Error("upstream proxy address is required")
		return
	} else {
		upstreamURL, err = url.ParseRequestURI(*flagUpstream)
		if err != nil {
			slog.Error("error parsing upstream url", "error", err)
			return
		}
	}

	apiKey := *flagAPIKey
	if apiKey == "" {
		apiKey = os.Getenv("LLAMA_SWAP_API_KEY")
	}

	proxy := newProxy(upstreamURL, apiKey)
	server := &http.Server{
		Addr:    *flagListen,
		Handler: proxy,
	}

	// start the server
	go func() {
		slog.Info("server starting on", "address", *flagListen)
		if err := server.ListenAndServe(); err != nil {
			slog.Error("error starting server", "error", err)
		}
	}()

	// graceful shutdown
	ctx, _ := signal.NotifyContext(context.Background(), os.Interrupt)
	<-ctx.Done()
	server.Close()
}

type upstreamStatus string

const (
	notready              upstreamStatus = "not ready"
	ready                 upstreamStatus = "ready"
	initialReconnectDelay                = 100 * time.Millisecond
	maxReconnectDelay                    = 10 * time.Second
	healthCheckInterval                  = 10 * time.Second
	healthCheckTimeout                   = 5 * time.Second
)

type proxyServer struct {
	upstreamProxy *httputil.ReverseProxy
	failCount     int
	statusMutex   sync.RWMutex
	status        upstreamStatus
	sseBodyMu     sync.Mutex
	sseBody       io.Closer

	// guarded by statusMutex
	wakeStart time.Time     // when the pending wake began, zero if none
	lastWake  time.Duration // how long the last wake took, zero if unknown
}

func newProxyServer(url *url.URL) *proxyServer {
	return &proxyServer{
		upstreamProxy: httputil.NewSingleHostReverseProxy(url),
		status:        notready,
		failCount:     0,
	}
}

// newProxy creates a proxy and starts the goroutines that watch the upstream
func newProxy(url *url.URL, apiKey string) *proxyServer {
	proxy := newProxyServer(url)

	// start a goroutine to monitor upstream status via SSE
	go func() {
		eventsUrl := url.Scheme + "://" + url.Host + "/api/events"
		client := &http.Client{
			Timeout: 0, // No timeout for SSE connection
		}

		reconnectDelay := time.Duration(0)

		for {
			if reconnectDelay > 0 {
				time.Sleep(reconnectDelay)
			}

			slog.Debug("connecting to SSE endpoint", "url", eventsUrl)

			req, err := http.NewRequest("GET", eventsUrl, nil)
			if err != nil {
				slog.Warn("failed to create SSE request", "error", err)
				proxy.setStatus(notready)
				proxy.incFail(1)
				reconnectDelay = nextReconnectDelay(reconnectDelay)
				continue
			}

			req.Header.Set("Accept", "text/event-stream")
			req.Header.Set("Cache-Control", "no-cache")
			req.Header.Set("Connection", "keep-alive")
			if apiKey != "" {
				req.Header.Set("Authorization", "Bearer "+apiKey)
			}

			resp, err := client.Do(req)
			if err != nil {
				slog.Error("failed to connect to SSE endpoint", "error", err)
				proxy.setStatus(notready)
				proxy.incFail(1)
				reconnectDelay = nextReconnectDelay(reconnectDelay)
				continue
			}

			if resp.StatusCode != http.StatusOK {
				slog.Warn("SSE endpoint returned non-OK status", "status", resp.StatusCode)
				_, _ = io.Copy(io.Discard, resp.Body)
				_ = resp.Body.Close()
				proxy.setStatus(notready)
				proxy.incFail(1)
				reconnectDelay = nextReconnectDelay(reconnectDelay)
				continue
			}

			// Successfully connected to SSE endpoint
			slog.Info("connected to SSE endpoint, upstream ready")
			proxy.setStatus(ready)
			proxy.resetFailures()
			reconnectDelay = 0
			proxy.setSSEBody(resp.Body)

			// Read from the SSE stream to detect disconnection
			scanner := bufio.NewScanner(resp.Body)

			// use a fairly large buffer to avoid scanner errors when reading large SSE events
			buf := make([]byte, 0, 1024*1024*2)
			scanner.Buffer(buf, 1024*1024*2)
			events := 0
			if slog.Default().Enabled(context.Background(), slog.LevelDebug) {
				fmt.Print("Events: ")
			}
			for scanner.Scan() {
				if slog.Default().Enabled(context.Background(), slog.LevelDebug) {
					// Just read the events to keep connection alive
					// We don't need to process the event data
					events++
					fmt.Printf("%d, ", events)
				}
			}
			fmt.Println()
			if err := scanner.Err(); err != nil {
				slog.Error("error reading from SSE stream", "error", err)
			}

			// Connection closed or error occurred
			proxy.setSSEBody(nil)
			_ = resp.Body.Close()
			slog.Info("SSE connection closed, upstream not ready")
			proxy.setStatus(notready)
			proxy.incFail(1)

		}
	}()

	// start a goroutine that periodically checks upstream liveness so a
	// silently dead connection (e.g. upstream suspended without a TCP close)
	// is detected and the upstream is marked not ready again
	go func() {
		healthUrl := url.Scheme + "://" + url.Host + "/wol-health"
		client := &http.Client{Timeout: healthCheckTimeout}
		ticker := time.NewTicker(healthCheckInterval)
		defer ticker.Stop()
		for range ticker.C {
			resp, err := client.Get(healthUrl)
			if err == nil {
				_, _ = io.Copy(io.Discard, resp.Body)
				_ = resp.Body.Close()
				continue
			}
			slog.Warn("upstream health check failed, marking upstream not ready", "error", err)
			proxy.setStatus(notready)
			proxy.incFail(1)
			if c := proxy.takeSSEBody(); c != nil {
				_ = c.Close() // force the SSE monitor to reconnect
			}
		}
	}()

	return proxy
}

func nextReconnectDelay(current time.Duration) time.Duration {
	if current == 0 {
		return initialReconnectDelay
	}

	next := current * 2
	if next > maxReconnectDelay {
		return maxReconnectDelay
	}
	return next
}

func (p *proxyServer) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" && r.URL.Path == "/status" {
		status := string(p.getStatus())
		failCount := p.getFailures()
		w.Header().Set("Content-Type", "text/plain")
		w.WriteHeader(200)
		fmt.Fprintf(w, "status: %s\n", status)
		fmt.Fprintf(w, "failures: %d\n", failCount)
		return
	}

	if *flagRequireConfirm && r.URL.Path == wakePath {
		switch r.Method {
		case http.MethodPost:
			p.handleWake(w, r)
			return
		case http.MethodGet:
			p.handleWakeProgress(w, r)
			return
		}
	}

	if p.getStatus() == notready {
		path := r.URL.Path
		if strings.HasPrefix(path, "/api/events") {
			slog.Debug("Skipping wake up", "req", path)
			w.WriteHeader(http.StatusNoContent)
			return
		}

		if *flagRequireConfirm {
			// never wake the upstream without the user's consent
			if path == "/" || strings.HasPrefix(path, "/ui/") {
				w.Header().Set("Content-Type", "text/html; charset=utf-8")
				w.WriteHeader(http.StatusOK)
				fmt.Fprint(w, confirmPageHTML)
				return
			}

			slog.Info("upstream not ready, confirmation required", "req", path, "from", r.RemoteAddr)
			http.Error(w, "upstream is not running, open the root page to confirm starting it", http.StatusServiceUnavailable)
			return
		}

		slog.Info("upstream not ready, sending magic packet", "req", path, "from", r.RemoteAddr)
		p.beginWake()
		if err := sendMagicPacket(*flagMac); err != nil {
			slog.Warn("failed to send magic WoL packet", "error", err)
		}

		// For root or UI path requests, return loading page with status polling
		// the web page will do the polling and redirect when ready
		if path == "/" || strings.HasPrefix(path, "/ui/") {
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			w.WriteHeader(http.StatusOK)
			fmt.Fprint(w, loadingPageHTML)
			return
		}

		ticker := time.NewTicker(250 * time.Millisecond)
		timeout, cancel := context.WithTimeout(context.Background(), time.Duration(*flagTimeout)*time.Second)
		defer cancel()
	loop:
		for {
			select {
			case <-timeout.Done():
				slog.Info("timeout waiting for upstream to be ready")
				http.Error(w, "timeout", http.StatusRequestTimeout)
				return
			case <-ticker.C:
				if p.getStatus() == ready {
					ticker.Stop()
					break loop
				}
			}
		}
	}

	p.upstreamProxy.ServeHTTP(w, r)
}

// handleWake sends the WoL packet after the user confirmed on the confirmation
// page. It redirects to a GET page so the browser never has to re-submit the
// form when the loading page reloads itself.
func (p *proxyServer) handleWake(w http.ResponseWriter, r *http.Request) {
	if p.getStatus() == ready {
		http.Redirect(w, r, "/", http.StatusSeeOther)
		return
	}

	slog.Info("start confirmed, sending magic packet", "from", r.RemoteAddr)
	p.beginWake()
	if err := sendMagicPacket(*flagMac); err != nil {
		slog.Warn("failed to send magic WoL packet", "error", err)
	}

	http.Redirect(w, r, wakePath, http.StatusSeeOther)
}

// handleWakeProgress shows the loading page while a confirmed wake is pending.
// Without a pending wake there is nothing to wait for, so it goes back to the
// root page.
func (p *proxyServer) handleWakeProgress(w http.ResponseWriter, r *http.Request) {
	if p.getStatus() == ready || !p.wakePending() {
		http.Redirect(w, r, "/", http.StatusSeeOther)
		return
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.WriteHeader(http.StatusOK)
	fmt.Fprint(w, p.loadingPage())
}

// loadingPage returns the loading page with the duration of the last wake, so
// the progress bar can estimate how long this one will take
func (p *proxyServer) loadingPage() string {
	last := p.lastWakeDuration()
	if last <= 0 {
		return loadingPageHTML // no estimate yet
	}
	expected := fmt.Sprintf(`data-expected="%.1f"`, last.Seconds())
	return strings.Replace(loadingPageHTML, `data-expected="0"`, expected, 1)
}

// beginWake marks the start of a wake, the first request of a wake wins
func (p *proxyServer) beginWake() {
	p.statusMutex.Lock()
	defer p.statusMutex.Unlock()
	if p.status == ready {
		return // came up in the meantime, nothing to time
	}
	if p.wakeStart.IsZero() || time.Since(p.wakeStart) > maxTrackedWake {
		p.wakeStart = time.Now()
	}
}

func (p *proxyServer) wakePending() bool {
	p.statusMutex.RLock()
	defer p.statusMutex.RUnlock()
	return !p.wakeStart.IsZero()
}

func (p *proxyServer) lastWakeDuration() time.Duration {
	p.statusMutex.RLock()
	defer p.statusMutex.RUnlock()
	return p.lastWake
}

func (p *proxyServer) getStatus() upstreamStatus {
	p.statusMutex.RLock()
	defer p.statusMutex.RUnlock()
	return p.status
}

func (p *proxyServer) setStatus(status upstreamStatus) {
	p.statusMutex.Lock()
	defer p.statusMutex.Unlock()
	p.status = status

	if status == ready && !p.wakeStart.IsZero() {
		if d := time.Since(p.wakeStart); d <= maxTrackedWake {
			p.lastWake = d
			slog.Info("upstream ready after wake", "took", d.Round(100*time.Millisecond))
		}
		p.wakeStart = time.Time{}
	}
}

func (p *proxyServer) incFail(num int) {
	p.statusMutex.Lock()
	defer p.statusMutex.Unlock()
	p.failCount += num
}

func (p *proxyServer) getFailures() int {
	p.statusMutex.RLock()
	defer p.statusMutex.RUnlock()
	return p.failCount
}

func (p *proxyServer) resetFailures() {
	p.statusMutex.Lock()
	defer p.statusMutex.Unlock()
	p.failCount = 0
}

func (p *proxyServer) setSSEBody(c io.Closer) {
	p.sseBodyMu.Lock()
	defer p.sseBodyMu.Unlock()
	p.sseBody = c
}

func (p *proxyServer) takeSSEBody() io.Closer {
	p.sseBodyMu.Lock()
	defer p.sseBodyMu.Unlock()
	c := p.sseBody
	p.sseBody = nil
	return c
}

func sendMagicPacket(macAddr string) error {
	hwAddr, err := net.ParseMAC(macAddr)
	if err != nil {
		return err
	}

	if len(hwAddr) != 6 {
		return errors.New("invalid MAC address")
	}

	// Create the magic packet.
	packet := make([]byte, 102)
	// Add 6 bytes of 0xFF.
	for i := 0; i < 6; i++ {
		packet[i] = 0xFF
	}
	// Repeat the MAC address 16 times.
	for i := 1; i <= 16; i++ {
		copy(packet[i*6:], hwAddr)
	}

	// Send the packet using UDP.
	addr := net.UDPAddr{
		IP:   net.IPv4bcast,
		Port: 9,
	}
	conn, err := net.DialUDP("udp", nil, &addr)
	if err != nil {
		return err
	}
	defer conn.Close()

	_, err = conn.Write(packet)
	return err
}
