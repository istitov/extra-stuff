<script lang="ts">
  import { playgroundModels, profileModels, selectorModels } from "../../stores/api";
  import { groupModels } from "../../lib/modelUtils";
  import * as Select from "$lib/components/ui/select/index.js";

  interface Props {
    value: string;
    placeholder?: string;
    disabled?: boolean;
    capabilities?: string[];
    matchAny?: boolean;
  }

  let { value = $bindable(), placeholder = "Select a model...", disabled = false, capabilities, matchAny = false }: Props = $props();

  let grouped = $derived(groupModels(
    $playgroundModels.filter((model) => model.playgroundType === "model" || model.playgroundType === "peer"),
    capabilities,
    matchAny,
  ));
  let hasMatching = $derived(grouped.localMatching.length > 0);
  let hasModels = $derived(
    $profileModels.length > 0
      || $selectorModels.length > 0
      || hasMatching
      || grouped.local.length > 0
      || grouped.peers.length > 0
  );
</script>

{#if hasModels}
  <Select.Root
    type="single"
    {value}
    onValueChange={(v) => v !== undefined && (value = v)}
    {disabled}
  >
    <Select.Trigger class="min-w-0 flex-1 basis-48">{value || placeholder}</Select.Trigger>
    <Select.Content class="max-h-[60vh]">
      <Select.Item value="">{placeholder}</Select.Item>
      {#if $profileModels.length > 0}
        <Select.Group>
          <Select.Label>Profile</Select.Label>
          {#each $profileModels as model (model.id)}
            <Select.Item value={model.id}>{model.id}</Select.Item>
          {/each}
        </Select.Group>
        <Select.Separator />
      {/if}
      {#if hasMatching}
        <Select.Group>
          <Select.Label>Matching Capabilities</Select.Label>
          {#each grouped.localMatching as model (model.id)}
            <Select.Item value={model.id}>{model.id}</Select.Item>
            {#if model.aliases}
              {#each model.aliases as alias (alias)}
                <Select.Item value={alias}>↳ {alias}</Select.Item>
              {/each}
            {/if}
          {/each}
        </Select.Group>
        <Select.Separator />
      {/if}
      {#if $selectorModels.length > 0}
        <Select.Group>
          <Select.Label>Selectors</Select.Label>
          {#each $selectorModels as model (model.id)}
            <Select.Item value={model.id}>{model.id}</Select.Item>
          {/each}
        </Select.Group>
        <Select.Separator />
      {/if}
      {#if grouped.local.length > 0}
        <Select.Group>
          <Select.Label>Local</Select.Label>
          {#each grouped.local as model (model.id)}
            <Select.Item value={model.id}>{model.id}</Select.Item>
            {#if model.aliases}
              {#each model.aliases as alias (alias)}
                <Select.Item value={alias}>↳ {alias}</Select.Item>
              {/each}
            {/if}
          {/each}
        </Select.Group>
        <Select.Separator />
      {/if}
      {#if grouped.peers.length > 0}
        <Select.Group>
          <Select.Label>Peers</Select.Label>
          {#each grouped.peers as model (model.id)}
            <Select.Item value={model.id}>{model.id}</Select.Item>
          {/each}
        </Select.Group>
      {/if}
    </Select.Content>
  </Select.Root>
{/if}
