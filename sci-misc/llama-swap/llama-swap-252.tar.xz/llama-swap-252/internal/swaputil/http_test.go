package swaputil

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"io"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"strconv"
	"strings"
	"testing"

	"github.com/mostlygeek/llama-swap/internal/config"
)

func TestReplaceRequestModel(t *testing.T) {
	withContext := func(r *http.Request) *http.Request {
		return r.WithContext(SetContext(r.Context(), ReqContextData{
			Model:    "public",
			ModelID:  "public",
			Metadata: make(map[string]string),
		}))
	}
	assertContextInvalidated := func(t *testing.T, r *http.Request) {
		t.Helper()
		if _, ok := ReadContext(r.Context()); ok {
			t.Fatal("request model context was not invalidated")
		}
	}
	assertBodyLength := func(t *testing.T, r *http.Request, body []byte) {
		t.Helper()
		if r.ContentLength != int64(len(body)) {
			t.Fatalf("ContentLength = %d, want %d", r.ContentLength, len(body))
		}
		if got, want := r.Header.Get("Content-Length"), strconv.Itoa(len(body)); got != want {
			t.Fatalf("Content-Length = %q, want %q", got, want)
		}
	}

	t.Run("query", func(t *testing.T) {
		r := withContext(httptest.NewRequest(http.MethodGet, "/props?model=public", nil))
		updated, err := ReplaceRequestModel(r, "public", "target")
		if err != nil {
			t.Fatalf("ReplaceRequestModel: %v", err)
		}
		if got := updated.URL.Query().Get("model"); got != "target" {
			t.Fatalf("model = %q, want target", got)
		}
		assertContextInvalidated(t, updated)
	})

	t.Run("json", func(t *testing.T) {
		r := withContext(httptest.NewRequest(http.MethodPost, "/", strings.NewReader(`{"model":"public","prompt":"hello"}`)))
		r.Header.Set("Content-Type", "application/json")
		updated, err := ReplaceRequestModel(r, "public", "target")
		if err != nil {
			t.Fatalf("ReplaceRequestModel: %v", err)
		}
		body, err := io.ReadAll(updated.Body)
		if err != nil {
			t.Fatalf("read body: %v", err)
		}
		if !strings.Contains(string(body), `"model":"target"`) {
			t.Fatalf("body = %s, want target model", body)
		}
		assertBodyLength(t, updated, body)
		assertContextInvalidated(t, updated)
	})

	t.Run("urlencoded", func(t *testing.T) {
		r := withContext(httptest.NewRequest(http.MethodPost, "/", strings.NewReader(url.Values{"model": {"public"}}.Encode())))
		r.Header.Set("Content-Type", "application/x-www-form-urlencoded")
		updated, err := ReplaceRequestModel(r, "public", "target")
		if err != nil {
			t.Fatalf("ReplaceRequestModel: %v", err)
		}
		body, err := io.ReadAll(updated.Body)
		if err != nil {
			t.Fatalf("read body: %v", err)
		}
		values, err := url.ParseQuery(string(body))
		if err != nil {
			t.Fatalf("parse body: %v", err)
		}
		if got := values.Get("model"); got != "target" {
			t.Fatalf("model = %q, want target", got)
		}
		assertBodyLength(t, updated, body)
		assertContextInvalidated(t, updated)
	})

	for _, tc := range []struct {
		name        string
		contentType string
	}{
		{name: "missing content type"},
		{name: "other content type", contentType: "text/plain"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			r := withContext(httptest.NewRequest(http.MethodPost, "/?model=public", nil))
			if tc.contentType != "" {
				r.Header.Set("Content-Type", tc.contentType)
			}
			updated, err := ReplaceRequestModel(r, "public", "target")
			if err != nil {
				t.Fatalf("ReplaceRequestModel: %v", err)
			}
			body, err := io.ReadAll(updated.Body)
			if err != nil {
				t.Fatalf("read body: %v", err)
			}
			values, err := url.ParseQuery(string(body))
			if err != nil {
				t.Fatalf("parse body: %v", err)
			}
			if got := values.Get("model"); got != "target" {
				t.Fatalf("model = %q, want target", got)
			}
			assertBodyLength(t, updated, body)
			assertContextInvalidated(t, updated)
		})
	}

	t.Run("multipart", func(t *testing.T) {
		var body bytes.Buffer
		writer := multipart.NewWriter(&body)
		if err := writer.WriteField("model", "public"); err != nil {
			t.Fatalf("write model: %v", err)
		}
		if err := writer.WriteField("prompt", "hello"); err != nil {
			t.Fatalf("write prompt: %v", err)
		}
		file, err := writer.CreateFormFile("file", "audio.wav")
		if err != nil {
			t.Fatalf("create file: %v", err)
		}
		if _, err := file.Write([]byte("RIFFdata")); err != nil {
			t.Fatalf("write file: %v", err)
		}
		if err := writer.Close(); err != nil {
			t.Fatalf("close multipart: %v", err)
		}
		r := withContext(httptest.NewRequest(http.MethodPost, "/", bytes.NewReader(body.Bytes())))
		r.Header.Set("Content-Type", writer.FormDataContentType())

		updated, err := ReplaceRequestModel(r, "public", "target")
		if err != nil {
			t.Fatalf("ReplaceRequestModel: %v", err)
		}
		rewritten, err := io.ReadAll(updated.Body)
		if err != nil {
			t.Fatalf("read body: %v", err)
		}
		assertBodyLength(t, updated, rewritten)
		updated.Body = io.NopCloser(bytes.NewReader(rewritten))
		if err := updated.ParseMultipartForm(MaxMultiPartSize); err != nil {
			t.Fatalf("parse multipart: %v", err)
		}
		if got := updated.FormValue("model"); got != "target" {
			t.Fatalf("model = %q, want target", got)
		}
		if got := updated.FormValue("prompt"); got != "hello" {
			t.Fatalf("prompt = %q, want hello", got)
		}
		fileHeader := updated.MultipartForm.File["file"][0]
		if got := fileHeader.Filename; got != "audio.wav" {
			t.Fatalf("filename = %q, want audio.wav", got)
		}
		uploaded, err := fileHeader.Open()
		if err != nil {
			t.Fatalf("open file: %v", err)
		}
		fileBody, err := io.ReadAll(uploaded)
		uploaded.Close()
		if err != nil {
			t.Fatalf("read file: %v", err)
		}
		if got := string(fileBody); got != "RIFFdata" {
			t.Fatalf("file body = %q, want RIFFdata", got)
		}
		assertContextInvalidated(t, updated)
	})

	t.Run("multipart temp files cleaned up", func(t *testing.T) {
		tempDir := t.TempDir()
		t.Setenv("TMPDIR", tempDir)
		t.Setenv("TMP", tempDir)
		t.Setenv("TEMP", tempDir)

		var body bytes.Buffer
		writer := multipart.NewWriter(&body)
		if err := writer.WriteField("model", "public"); err != nil {
			t.Fatalf("write model: %v", err)
		}
		file, err := writer.CreateFormFile("file", "audio.wav")
		if err != nil {
			t.Fatalf("create file: %v", err)
		}
		if _, err := file.Write([]byte("file-on-disk")); err != nil {
			t.Fatalf("write file: %v", err)
		}
		if err := writer.Close(); err != nil {
			t.Fatalf("close multipart: %v", err)
		}

		original := append([]byte(nil), body.Bytes()...)
		r := withContext(httptest.NewRequest(http.MethodPost, "/", bytes.NewReader(original)))
		r.Header.Set("Content-Type", writer.FormDataContentType())
		if err := r.ParseMultipartForm(0); err != nil {
			t.Fatalf("parse multipart: %v", err)
		}
		entries, err := os.ReadDir(tempDir)
		if err != nil {
			t.Fatalf("read temp dir: %v", err)
		}
		if len(entries) == 0 {
			t.Fatal("multipart file was not written to disk")
		}
		r.Body = io.NopCloser(bytes.NewReader(original))

		if _, err := ReplaceRequestModel(r, "public", "target"); err != nil {
			t.Fatalf("ReplaceRequestModel: %v", err)
		}

		entries, err = os.ReadDir(tempDir)
		if err != nil {
			t.Fatalf("read temp dir: %v", err)
		}
		if len(entries) != 0 {
			t.Fatalf("multipart temp files were not removed: %v", entries)
		}
	})

	t.Run("upstream path", func(t *testing.T) {
		r := withContext(httptest.NewRequest(http.MethodPost, "/upstream/author/public/v1/chat/completions", nil))
		r.SetPathValue("upstreamPath", "author/public/v1/chat/completions")
		updated, err := ReplaceRequestModel(r, "author/public", "target")
		if err != nil {
			t.Fatalf("ReplaceRequestModel: %v", err)
		}
		if got, want := updated.PathValue("upstreamPath"), "target/v1/chat/completions"; got != want {
			t.Fatalf("upstreamPath = %q, want %q", got, want)
		}
		if got, want := updated.URL.Path, "/upstream/target/v1/chat/completions"; got != want {
			t.Fatalf("URL.Path = %q, want %q", got, want)
		}
		assertContextInvalidated(t, updated)
	})
}

func TestProxy_ReplaceRequestModelUpstreamPreservesEscapedPath(t *testing.T) {
	r := httptest.NewRequest(http.MethodPost, "/upstream/author%2Fmodel/api/x%2Fy", nil)
	r.SetPathValue("upstreamPath", strings.TrimPrefix(r.URL.Path, "/upstream/"))

	updated, err := ReplaceRequestModel(r, "author/model", "target/model")
	if err != nil {
		t.Fatalf("ReplaceRequestModel: %v", err)
	}
	if got, want := updated.URL.Path, "/upstream/target/model/api/x/y"; got != want {
		t.Errorf("URL.Path = %q, want %q", got, want)
	}
	if got, want := updated.URL.EscapedPath(), "/upstream/target/model/api/x%2Fy"; got != want {
		t.Errorf("EscapedPath() = %q, want %q", got, want)
	}
}

func TestExtractContext_GET(t *testing.T) {
	tests := []struct {
		name      string
		query     string
		wantModel string
		wantErr   bool
	}{
		{"model present", "model=llama3", "llama3", false},
		{"model with slashes", "model=author/model-7b", "author/model-7b", false},
		{"model missing", "", "", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			r, _ := http.NewRequest(http.MethodGet, "/?"+tt.query, nil)
			got, err := extractContext(r)
			if (err != nil) != tt.wantErr {
				t.Fatalf("wantErr=%v got err=%v", tt.wantErr, err)
			}
			if got.Model != tt.wantModel {
				t.Errorf("want %q got %q", tt.wantModel, got.Model)
			}
		})
	}
}

func TestExtractContext_JSON(t *testing.T) {
	tests := []struct {
		name      string
		body      string
		wantModel string
		wantErr   bool
	}{
		{"model present", `{"model":"llama3","stream":true}`, "llama3", false},
		{"model with slashes", `{"model":"author/model-7b"}`, "author/model-7b", false},
		{"model empty string", `{"model":""}`, "", false},
		{"model key missing", `{"stream":true}`, "", false},
		{"invalid json", `not-json`, "", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			r, _ := http.NewRequest(http.MethodPost, "/v1/chat/completions", strings.NewReader(tt.body))
			r.Header.Set("Content-Type", "application/json")
			got, err := extractContext(r)
			if (err != nil) != tt.wantErr {
				t.Fatalf("wantErr=%v got err=%v", tt.wantErr, err)
			}
			if got.Model != tt.wantModel {
				t.Errorf("want %q got %q", tt.wantModel, got.Model)
			}
		})
	}
}

func TestExtractContext_URLEncodedForm(t *testing.T) {
	tests := []struct {
		name      string
		formModel string
		wantModel string
		wantErr   bool
	}{
		{"model present", "whisper-1", "whisper-1", false},
		{"model missing", "", "", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			form := url.Values{}
			if tt.formModel != "" {
				form.Set("model", tt.formModel)
			}
			r, _ := http.NewRequest(http.MethodPost, "/v1/audio/transcriptions", strings.NewReader(form.Encode()))
			r.Header.Set("Content-Type", "application/x-www-form-urlencoded")
			got, err := extractContext(r)
			if (err != nil) != tt.wantErr {
				t.Fatalf("wantErr=%v got err=%v", tt.wantErr, err)
			}
			if got.Model != tt.wantModel {
				t.Errorf("want %q got %q", tt.wantModel, got.Model)
			}
		})
	}
}

func TestExtractContext_MultipartForm(t *testing.T) {
	tests := []struct {
		name      string
		formModel string
		wantModel string
		wantErr   bool
	}{
		{"model present", "whisper-1", "whisper-1", false},
		{"model missing", "", "", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var buf bytes.Buffer
			mw := multipart.NewWriter(&buf)
			if tt.formModel != "" {
				fw, _ := mw.CreateFormField("model")
				fw.Write([]byte(tt.formModel))
			}
			mw.Close()

			r, _ := http.NewRequest(http.MethodPost, "/v1/audio/transcriptions", &buf)
			r.Header.Set("Content-Type", mw.FormDataContentType())
			got, err := extractContext(r)
			if (err != nil) != tt.wantErr {
				t.Fatalf("wantErr=%v got err=%v", tt.wantErr, err)
			}
			if got.Model != tt.wantModel {
				t.Errorf("want %q got %q", tt.wantModel, got.Model)
			}
		})
	}
}

func TestExtractContext_JSONBodyRestored(t *testing.T) {
	body := `{"model":"llama3","stream":true}`
	r, _ := http.NewRequest(http.MethodPost, "/v1/chat/completions", strings.NewReader(body))
	r.Header.Set("Content-Type", "application/json")

	if _, err := extractContext(r); err != nil {
		t.Fatalf("ExtractContext: %v", err)
	}

	remaining, err := io.ReadAll(r.Body)
	if err != nil {
		t.Fatalf("reading body after ExtractContext: %v", err)
	}
	if string(remaining) != body {
		t.Errorf("body not restored: want %q got %q", body, string(remaining))
	}
}

func TestExtractContext_MultipartBodyRestored(t *testing.T) {
	var buf bytes.Buffer
	mw := multipart.NewWriter(&buf)
	fw, _ := mw.CreateFormField("model")
	fw.Write([]byte("whisper-1"))
	ff, _ := mw.CreateFormFile("file", "audio.wav")
	ff.Write([]byte("fake-audio-bytes"))
	mw.Close()

	original := buf.Bytes()

	r, _ := http.NewRequest(http.MethodPost, "/v1/audio/transcriptions", bytes.NewReader(original))
	r.Header.Set("Content-Type", mw.FormDataContentType())

	if _, err := extractContext(r); err != nil {
		t.Fatalf("ExtractContext: %v", err)
	}

	remaining, err := io.ReadAll(r.Body)
	if err != nil {
		t.Fatalf("reading body after ExtractContext: %v", err)
	}
	if !bytes.Equal(remaining, original) {
		t.Errorf("multipart body not restored: want %d bytes got %d bytes", len(original), len(remaining))
	}
}

func TestExtractContext_URLEncodedBodyRestored(t *testing.T) {
	body := "model=whisper-1&extra=value"
	r, _ := http.NewRequest(http.MethodPost, "/v1/audio/transcriptions", strings.NewReader(body))
	r.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	if _, err := extractContext(r); err != nil {
		t.Fatalf("ExtractContext: %v", err)
	}

	remaining, err := io.ReadAll(r.Body)
	if err != nil {
		t.Fatalf("reading body after ExtractContext: %v", err)
	}
	if string(remaining) != body {
		t.Errorf("url-encoded body not restored: want %q got %q", body, string(remaining))
	}
}

func TestSetContext(t *testing.T) {
	ctx := SetContext(context.Background(), ReqContextData{Model: "llama3", ModelID: "llama3"})
	data, ok := ctx.Value(ReqContextKey).(ReqContextData)
	if !ok {
		t.Fatalf("ContextKey not set or wrong type")
	}
	if data.Model != "llama3" {
		t.Errorf("want %q got %q", "llama3", data.Model)
	}
	if data.ModelID != "llama3" {
		t.Errorf("want %q got %q", "llama3", data.ModelID)
	}
}

func TestSetContext_WithAlias(t *testing.T) {
	ctx := SetContext(context.Background(), ReqContextData{Model: "llama", ModelID: "llama3"})
	data, _ := ctx.Value(ReqContextKey).(ReqContextData)
	if data.Model != "llama" {
		t.Errorf("want requested %q got %q", "llama", data.Model)
	}
	if data.ModelID != "llama3" {
		t.Errorf("want real %q got %q", "llama3", data.ModelID)
	}
}

func TestSetContext_DoesNotMutateParent(t *testing.T) {
	parent := context.Background()
	_ = SetContext(parent, ReqContextData{Model: "llama3", ModelID: "llama3"})
	if v := parent.Value(ReqContextKey); v != nil {
		t.Errorf("parent context was mutated: %v", v)
	}
}

func TestReadContext(t *testing.T) {
	tests := []struct {
		name     string
		ctx      context.Context
		wantReq  string
		wantReal string
		wantBool bool
	}{
		{
			name:     "model present, same name",
			ctx:      SetContext(context.Background(), ReqContextData{Model: "llama3", ModelID: "llama3"}),
			wantReq:  "llama3",
			wantReal: "llama3",
			wantBool: true,
		},
		{
			name:     "model present, aliased",
			ctx:      SetContext(context.Background(), ReqContextData{Model: "llama", ModelID: "llama3"}),
			wantReq:  "llama",
			wantReal: "llama3",
			wantBool: true,
		},
		{
			name:     "model absent",
			ctx:      context.Background(),
			wantReq:  "",
			wantReal: "",
			wantBool: false,
		},
		{
			name:     "model is empty string",
			ctx:      SetContext(context.Background(), ReqContextData{Model: "", ModelID: ""}),
			wantReq:  "",
			wantReal: "",
			wantBool: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotData, ok := ReadContext(tt.ctx)
			if gotData.Model != tt.wantReq || gotData.ModelID != tt.wantReal || ok != tt.wantBool {
				t.Errorf("want (%q, %q, %v) got (%q, %q, %v)", tt.wantReq, tt.wantReal, tt.wantBool, gotData.Model, gotData.ModelID, ok)
			}
		})
	}
}

func TestExtractContext_Streaming_GET(t *testing.T) {
	tests := []struct {
		name          string
		query         string
		wantStreaming bool
	}{
		{"streaming true", "model=llama3&stream=true", true},
		{"streaming false", "model=llama3&stream=false", false},
		{"no stream param", "model=llama3", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			r, _ := http.NewRequest(http.MethodGet, "/?"+tt.query, nil)
			got, err := extractContext(r)
			if err != nil {
				t.Fatalf("ExtractContext: %v", err)
			}
			if got.Streaming != tt.wantStreaming {
				t.Errorf("Streaming: want %v, got %v", tt.wantStreaming, got.Streaming)
			}
		})
	}
}

func TestExtractContext_Streaming_JSON(t *testing.T) {
	tests := []struct {
		name          string
		body          string
		wantStreaming bool
	}{
		{"streaming true", `{"model":"llama3","stream":true}`, true},
		{"streaming false", `{"model":"llama3","stream":false}`, false},
		{"no stream param", `{"model":"llama3"}`, false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			r, _ := http.NewRequest(http.MethodPost, "/v1/chat/completions", strings.NewReader(tt.body))
			r.Header.Set("Content-Type", "application/json")
			got, err := extractContext(r)
			if err != nil {
				t.Fatalf("ExtractContext: %v", err)
			}
			if got.Streaming != tt.wantStreaming {
				t.Errorf("Streaming: want %v, got %v", tt.wantStreaming, got.Streaming)
			}
		})
	}
}

func TestExtractContext_Streaming_URLEncodedForm(t *testing.T) {
	r, _ := http.NewRequest(http.MethodPost, "/v1/audio/transcriptions", strings.NewReader("model=whisper-1&stream=true"))
	r.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	got, err := extractContext(r)
	if err != nil {
		t.Fatalf("ExtractContext: %v", err)
	}
	if !got.Streaming {
		t.Error("Streaming should be true")
	}
}

func TestExtractContext_ApiKey(t *testing.T) {
	basicHeader := func(user, pass string) string {
		return "Basic " + base64.StdEncoding.EncodeToString([]byte(user+":"+pass))
	}
	cases := []struct {
		name    string
		method  string
		ct      string
		body    string
		auth    string
		xapi    string
		wantKey string
	}{
		{"GET bearer", http.MethodGet, "", "", "Bearer sk-get", "", "sk-get"},
		{"GET x-api-key", http.MethodGet, "", "", "", "xk-get", "xk-get"},
		{"GET basic", http.MethodGet, "", "", basicHeader("u", "pw-get"), "", "pw-get"},
		{"JSON bearer", http.MethodPost, "application/json", `{"model":"m"}`, "Bearer sk-json", "", "sk-json"},
		{"JSON x-api-key", http.MethodPost, "application/json", `{"model":"m"}`, "", "xk-json", "xk-json"},
		{"form bearer", http.MethodPost, "application/x-www-form-urlencoded", "model=m", "Bearer sk-form", "", "sk-form"},
		{"no key", http.MethodGet, "", "", "", "", ""},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			var body io.Reader
			if c.body != "" {
				body = strings.NewReader(c.body)
			}
			r, _ := http.NewRequest(c.method, "/", body)
			if c.ct != "" {
				r.Header.Set("Content-Type", c.ct)
			}
			if c.auth != "" {
				r.Header.Set("Authorization", c.auth)
			}
			if c.xapi != "" {
				r.Header.Set("x-api-key", c.xapi)
			}
			got, err := extractContext(r)
			if err != nil {
				t.Fatalf("extractContext: %v", err)
			}
			if got.ApiKey != c.wantKey {
				t.Errorf("ApiKey = %q, want %q", got.ApiKey, c.wantKey)
			}
		})
	}
}

func TestSetReqData(t *testing.T) {
	ctx := SetContext(context.Background(), ReqContextData{Model: "llama3", ModelID: "llama3", Metadata: make(map[string]string)})

	if err := SetReqData(ctx, "client", "web"); err != nil {
		t.Fatalf("SetReqData: %v", err)
	}
	if err := SetReqData(ctx, "trace", "abc123"); err != nil {
		t.Fatalf("SetReqData: %v", err)
	}

	data, ok := ReadContext(ctx)
	if !ok {
		t.Fatal("context data missing")
	}
	if data.Metadata["client"] != "web" {
		t.Errorf("client = %q, want %q", data.Metadata["client"], "web")
	}
	if data.Metadata["trace"] != "abc123" {
		t.Errorf("trace = %q, want %q", data.Metadata["trace"], "abc123")
	}
}

func TestSetReqData_Errors(t *testing.T) {
	if err := SetReqData(context.Background(), "k", "v"); err == nil {
		t.Error("expected error when no request context data exists")
	}
	ctx := SetContext(context.Background(), ReqContextData{Model: "llama3", ModelID: "llama3"})
	if err := SetReqData(ctx, "k", "v"); err == nil {
		t.Error("expected error when metadata map is missing")
	}
}

func TestServer_ExtractAPIKey(t *testing.T) {
	basicHeader := func(user, pass string) string {
		return "Basic " + base64.StdEncoding.EncodeToString([]byte(user+":"+pass))
	}
	cases := []struct {
		name string
		auth string
		xapi string
		want string
	}{
		{"none", "", "", ""},
		{"bearer", "Bearer tok123", "", "tok123"},
		{"basic", basicHeader("user", "pw-key"), "", "pw-key"},
		{"x-api-key", "", "xkey", "xkey"},
		{"basic beats bearer", basicHeader("u", "bk"), "", "bk"},
		{"bearer beats x-api-key", "Bearer btok", "xkey", "btok"},
		{"malformed basic falls back to x-api-key", "Basic !!!notbase64", "xkey", "xkey"},
		{"lowercase bearer", "bearer tok123", "", "tok123"},
		{"lowercase basic", "basic " + base64.StdEncoding.EncodeToString([]byte("user:pw-key")), "", "pw-key"},
		{"mixed case BEARER", "BEARER tok456", "", "tok456"},
		{"mixed case bAsIc", "bAsIc " + base64.StdEncoding.EncodeToString([]byte("u:bk")), "", "bk"},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			r := httptest.NewRequest(http.MethodGet, "/", nil)
			if c.auth != "" {
				r.Header.Set("Authorization", c.auth)
			}
			if c.xapi != "" {
				r.Header.Set("x-api-key", c.xapi)
			}
			if got := ExtractAPIKey(r); got != c.want {
				t.Errorf("extractAPIKey() = %q, want %q", got, c.want)
			}
		})
	}
}

func TestIsWebSocketUpgrade(t *testing.T) {
	tests := []struct {
		name       string
		connection string
		upgrade    string
		want       bool
	}{
		{name: "standard", connection: "Upgrade", upgrade: "websocket", want: true},
		{name: "case insensitive tokens", connection: "keep-alive, UpGrAdE", upgrade: "WebSocket", want: true},
		{name: "missing connection token", connection: "keep-alive", upgrade: "websocket"},
		{name: "different protocol", connection: "Upgrade", upgrade: "h2c"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			r := httptest.NewRequest(http.MethodGet, "/socket", nil)
			r.Header.Set("Connection", tt.connection)
			r.Header.Set("Upgrade", tt.upgrade)
			if got := IsWebSocketUpgrade(r); got != tt.want {
				t.Errorf("IsWebSocketUpgrade() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestFetchContext_UpstreamPath(t *testing.T) {
	cfg := config.Config{
		Models: map[string]config.ModelConfig{
			"m1":           {},
			"author/model": {},
			"real":         {Aliases: []string{"nick"}},
		},
		Peers: config.PeerDictionaryConfig{
			"remote": {Models: []string{"peer-model"}},
		},
	}

	cases := []struct {
		name        string
		path        string
		wantModel   string
		wantModelID string
		wantErr     bool
	}{
		{"known model", "/upstream/m1/v1/chat/completions", "m1", "m1", false},
		{"model with slash", "/upstream/author/model/v1/chat", "author/model", "author/model", false},
		{"peer model", "/upstream/peer-model/v1/chat", "peer-model", "peer-model", false},
		{"unknown model", "/upstream/nope/v1/chat/completions", "", "", true},
		{"bare model path", "/upstream/m1/", "m1", "m1", false},
	}

	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			r := httptest.NewRequest(http.MethodPost, c.path, strings.NewReader(`{}`))
			data, err := FetchContext(r, cfg)
			if (err != nil) != c.wantErr {
				t.Fatalf("wantErr=%v got err=%v", c.wantErr, err)
			}
			if c.wantErr {
				return
			}
			if data.Model != c.wantModel {
				t.Errorf("model = %q, want %q", data.Model, c.wantModel)
			}
			if data.ModelID != c.wantModelID {
				t.Errorf("modelID = %q, want %q", data.ModelID, c.wantModelID)
			}
			if data.Metadata == nil {
				t.Error("metadata map not initialized")
			}
		})
	}
}

func TestFindModelInPath_PeerNamespaces(t *testing.T) {
	cfg := config.Config{
		Models: map[string]config.ModelConfig{"local": {}},
		Peers: config.PeerDictionaryConfig{
			"p1": {Models: []string{"shared", "org/model"}},
			"p2": {Models: []string{"shared", "unique"}},
		},
	}

	tests := []struct {
		path      string
		wantName  string
		wantModel string
		wantRest  string
		wantFound bool
	}{
		{"/p1/shared/v1/chat", "p1/shared", "p1/shared", "/v1/chat", true},
		{"/p2/shared/v1/chat", "p2/shared", "p2/shared", "/v1/chat", true},
		{"/p1/org/model/v1/chat", "p1/org/model", "p1/org/model", "/v1/chat", true},
		{"/unique/v1/chat", "unique", "unique", "/v1/chat", true},
		{"/shared/v1/chat", "", "", "", false},
	}

	for _, tt := range tests {
		t.Run(tt.path, func(t *testing.T) {
			name, modelID, rest, found := FindModelInPath(cfg, tt.path)
			if name != tt.wantName || modelID != tt.wantModel || rest != tt.wantRest || found != tt.wantFound {
				t.Fatalf(
					"FindModelInPath(%q) = (%q, %q, %q, %v), want (%q, %q, %q, %v)",
					tt.path, name, modelID, rest, found,
					tt.wantName, tt.wantModel, tt.wantRest, tt.wantFound,
				)
			}
		})
	}
}

func TestProxy_EscapedPathSuffix(t *testing.T) {
	tests := []struct {
		escapedPath   string
		decodedPrefix string
		want          string
	}{
		{
			escapedPath:   "/upstream/m1/api/userdata/workflows%2Fexample.json",
			decodedPrefix: "/upstream/m1",
			want:          "/api/userdata/workflows%2Fexample.json",
		},
		{
			escapedPath:   "/upstream/author/model/api/x%2Fy",
			decodedPrefix: "/upstream/author/model",
			want:          "/api/x%2Fy",
		},
		{
			escapedPath:   "/upstream/author%2Fmodel/api/x%2Fy",
			decodedPrefix: "/upstream/author/model",
			want:          "/api/x%2Fy",
		},
		{
			escapedPath:   "/upstream/m1",
			decodedPrefix: "/upstream/m1",
			want:          "",
		},
	}

	for _, tt := range tests {
		t.Run(tt.escapedPath, func(t *testing.T) {
			if got := EscapedPathSuffix(tt.escapedPath, tt.decodedPrefix); got != tt.want {
				t.Errorf("EscapedPathSuffix(%q, %q) = %q, want %q", tt.escapedPath, tt.decodedPrefix, got, tt.want)
			}
		})
	}
}

func TestFetchContext_UpstreamPath_DoesNotReadBody(t *testing.T) {
	cfg := config.Config{Models: map[string]config.ModelConfig{"m1": {}}}
	body := `{"model":"should-not-matter"}`
	r := httptest.NewRequest(http.MethodPost, "/upstream/m1/v1/chat/completions", strings.NewReader(body))

	_, err := FetchContext(r, cfg)
	if err != nil {
		t.Fatalf("FetchContext: %v", err)
	}

	// The body should be untouched so the upstream handler can still read it.
	got, err := io.ReadAll(r.Body)
	if err != nil {
		t.Fatalf("read body: %v", err)
	}
	if string(got) != body {
		t.Errorf("body was consumed: %q", string(got))
	}
}

func TestSendResponse_JSONEnvelope(t *testing.T) {
	r := httptest.NewRequest(http.MethodPost, "/v1/chat/completions", nil)
	w := httptest.NewRecorder()
	SendResponse(w, r, http.StatusBadRequest, "could not read request body")

	if w.Code != http.StatusBadRequest {
		t.Fatalf("status = %d, want 400", w.Code)
	}
	if got := w.Header().Get("Content-Type"); got != "application/json" {
		t.Fatalf("Content-Type = %q, want application/json", got)
	}

	var envelope ErrorEnvelope
	if err := json.Unmarshal(w.Body.Bytes(), &envelope); err != nil {
		t.Fatalf("body is not an OpenAI-style error envelope: %v, body=%s", err, w.Body.String())
	}
	if envelope.Error.Message != "could not read request body" {
		t.Errorf("error.message = %q, want %q", envelope.Error.Message, "could not read request body")
	}
	if envelope.Error.Type != ErrorTypeInvalidRequest {
		t.Errorf("error.type = %q, want %q", envelope.Error.Type, ErrorTypeInvalidRequest)
	}
	if envelope.Src != "llama-swap" {
		t.Errorf("src = %q, want llama-swap", envelope.Src)
	}
}

func TestSendResponse_TextFormats(t *testing.T) {
	t.Run("plain", func(t *testing.T) {
		r := httptest.NewRequest(http.MethodGet, "/", nil)
		r.Header.Set("Accept", "text/plain")
		w := httptest.NewRecorder()
		SendResponse(w, r, http.StatusNotFound, "model not found")

		if got := w.Header().Get("Content-Type"); got != "text/plain" {
			t.Fatalf("Content-Type = %q, want text/plain", got)
		}
		if got, want := w.Body.String(), "llama-swap: model not found"; got != want {
			t.Errorf("body = %q, want %q", got, want)
		}
	})

	t.Run("html", func(t *testing.T) {
		r := httptest.NewRequest(http.MethodGet, "/", nil)
		r.Header.Set("Accept", "text/html")
		w := httptest.NewRecorder()
		SendResponse(w, r, http.StatusNotFound, "model not found")

		if got := w.Header().Get("Content-Type"); got != "text/html" {
			t.Fatalf("Content-Type = %q, want text/html", got)
		}
		if !strings.Contains(w.Body.String(), "model not found") {
			t.Errorf("body = %q, want it to contain the message", w.Body.String())
		}
	})
}

func TestSendError_HTTPErrorIsWrittenVerbatim(t *testing.T) {
	r := httptest.NewRequest(http.MethodPost, "/v1/chat/completions", nil)
	w := httptest.NewRecorder()
	SendError(w, r, ConcurrencyLimitError{})

	if w.Code != http.StatusTooManyRequests {
		t.Fatalf("status = %d, want 429", w.Code)
	}
	if got := w.Header().Get("Retry-After"); got != "1" {
		t.Errorf("Retry-After = %q, want 1", got)
	}

	var envelope ErrorEnvelope
	if err := json.Unmarshal(w.Body.Bytes(), &envelope); err != nil {
		t.Fatalf("body is not an OpenAI-style error envelope: %v, body=%s", err, w.Body.String())
	}
	if envelope.Error.Type != ErrorTypeRateLimit || envelope.Error.Code != "concurrency_limit" {
		t.Errorf("error = %+v, want a rate_limit_error/concurrency_limit", envelope.Error)
	}
}

func TestSendError_MapsSentinelErrors(t *testing.T) {
	tests := []struct {
		name       string
		err        error
		wantStatus int
	}{
		{"no model in context", ErrNoModelInContext, http.StatusNotFound},
		{"no peer model", ErrNoPeerModelFound, http.StatusNotFound},
		{"no local model", ErrNoLocalModelFound, http.StatusNotFound},
		{"no router", ErrNoRouterFound, http.StatusNotFound},
		{"unknown", errors.New("boom"), http.StatusInternalServerError},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			r := httptest.NewRequest(http.MethodPost, "/v1/chat/completions", nil)
			w := httptest.NewRecorder()
			SendError(w, r, tc.err)

			if w.Code != tc.wantStatus {
				t.Fatalf("status = %d, want %d", w.Code, tc.wantStatus)
			}
			var envelope ErrorEnvelope
			if err := json.Unmarshal(w.Body.Bytes(), &envelope); err != nil {
				t.Fatalf("body is not an OpenAI-style error envelope: %v, body=%s", err, w.Body.String())
			}
			if envelope.Error.Message == "" || envelope.Error.Type == "" {
				t.Errorf("error = %+v, want message and type set", envelope.Error)
			}
		})
	}
}
