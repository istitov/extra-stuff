package server

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/mostlygeek/llama-swap/internal/config"
	"github.com/mostlygeek/llama-swap/internal/event"
	"github.com/mostlygeek/llama-swap/internal/perf"
	"github.com/mostlygeek/llama-swap/internal/store"
	"github.com/mostlygeek/llama-swap/internal/swaputil"
)

// apiModel is one entry in the /api/events modelStatus payload.
type apiModel struct {
	Id            string         `json:"id"`
	Name          string         `json:"name"`
	Description   string         `json:"description"`
	State         string         `json:"state"`
	Unlisted      bool           `json:"unlisted"`
	PeerID        string         `json:"peerID"`
	Aliases       []string       `json:"aliases,omitempty"`
	Capabilities  map[string]any `json:"capabilities,omitempty"`
	ContextLength int            `json:"context_length,omitempty"`
}

type apiProfile struct {
	ID          string            `json:"id"`
	Description string            `json:"description"`
	Pins        map[string]string `json:"pins"`
}

func nullableProfile(name string) any {
	if name == "" {
		return nil
	}
	return name
}

func (s *Server) handleAPIProfiles(w http.ResponseWriter, r *http.Request) {
	ids := make([]string, 0, len(s.cfg.Profiles))
	for id := range s.cfg.Profiles {
		ids = append(ids, id)
	}
	sort.Strings(ids)

	profiles := make([]apiProfile, 0, len(ids))
	for _, id := range ids {
		profile := s.cfg.Profiles[id]
		profiles = append(profiles, apiProfile{
			ID:          id,
			Description: profile.Description,
			Pins:        profile.Pins,
		})
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{
		"active":   nullableProfile(s.ActiveProfile()),
		"profiles": profiles,
	})
}

func (s *Server) handleAPIActiveProfile(w http.ResponseWriter, r *http.Request) {
	var body map[string]json.RawMessage
	decoder := json.NewDecoder(r.Body)
	if err := decoder.Decode(&body); err != nil {
		swaputil.SendResponse(w, r, http.StatusBadRequest, "invalid profile request")
		return
	}
	raw, ok := body["name"]
	if !ok {
		swaputil.SendResponse(w, r, http.StatusBadRequest, "profile name is required")
		return
	}

	var name string
	if string(raw) != "null" {
		if err := json.Unmarshal(raw, &name); err != nil {
			swaputil.SendResponse(w, r, http.StatusBadRequest, "profile name must be a string or null")
			return
		}
	}
	if _, err := s.setActiveProfile(name); err != nil {
		swaputil.SendResponse(w, r, http.StatusNotFound, err.Error())
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{"active": nullableProfile(s.ActiveProfile())})
}

// modelStatus returns every configured model joined with its current process
// state (defaulting to "stopped"), followed by peer models.
func (s *Server) modelStatus() []apiModel {
	running := s.local.RunningModels()

	ids := make([]string, 0, len(s.cfg.Models))
	for id := range s.cfg.Models {
		ids = append(ids, id)
	}
	sort.Strings(ids)

	models := make([]apiModel, 0, len(ids))
	for _, id := range ids {
		mc := s.cfg.Models[id]
		state := "stopped"
		if st, ok := running[id]; ok {
			state = string(st)
		}
		_, capsMap, _, ctxLen := renderCapabilities(mc.Capabilities)
		models = append(models, apiModel{
			Id:            id,
			Name:          mc.Name,
			Description:   mc.Description,
			State:         state,
			Unlisted:      mc.Unlisted,
			Aliases:       mc.Aliases,
			Capabilities:  capsMap,
			ContextLength: ctxLen,
		})
	}

	for peerID, peer := range s.cfg.Peers {
		for _, modelID := range peer.Models {
			models = append(models, apiModel{Id: config.PeerModelFQN(peerID, modelID), PeerID: peerID})
		}
	}

	return models
}

// handleAPIUnloadAll stops every running local process.
func (s *Server) handleAPIUnloadAll(w http.ResponseWriter, r *http.Request) {
	s.local.Unload(0)
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"msg": "ok"})
}

// handleAPIUnloadModel stops a single named local process.
func (s *Server) handleAPIUnloadModel(w http.ResponseWriter, r *http.Request) {
	requested := strings.TrimPrefix(r.PathValue("model"), "/")
	realName, found := s.cfg.RealModelName(requested)
	if !found {
		swaputil.SendResponse(w, r, http.StatusNotFound, "model not found")
		return
	}
	if !s.local.Handles(realName) {
		swaputil.SendResponse(w, r, http.StatusNotFound, "no local server found for requested model")
		return
	}
	s.local.Unload(0, realName)
	w.WriteHeader(http.StatusOK)
	w.Write([]byte("OK"))
}

// handleAPIActivity serves paginated activity table rows.
func (s *Server) handleAPIActivity(w http.ResponseWriter, r *http.Request) {
	query, err := parseActivityQuery(r)
	if err != nil {
		swaputil.SendResponse(w, r, http.StatusBadRequest, err.Error())
		return
	}
	page, err := s.store.ListActivity(r.Context(), query)
	if err != nil {
		swaputil.SendResponse(w, r, http.StatusInternalServerError, "failed to get activity")
		return
	}
	s.metrics.overlayCaptureState(page.Data)
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(page)
}

// handleAPIActivityStats serves aggregate activity statistics and histograms.
func (s *Server) handleAPIActivityStats(w http.ResponseWriter, r *http.Request) {
	stats, err := s.store.ActivityStats(r.Context(), store.ActivityStatsQuery{
		Model: strings.TrimSpace(r.URL.Query().Get("model")),
	})
	if err != nil {
		swaputil.SendResponse(w, r, http.StatusInternalServerError, "failed to get activity stats")
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(stats)
}

func parseActivityLimit(raw string) (int, error) {
	limit, err := strconv.Atoi(raw)
	if err != nil {
		return 0, fmt.Errorf("invalid limit")
	}
	if limit > 0 && limit < 1000 {
		return limit, nil
	}
	return 0, fmt.Errorf("limit must be between 1 and 999")
}

// parseActivityTime reads an optional RFC3339 timestamp param, matching the
// ?after= convention used by handleAPIPerformance. A missing param is the zero
// time, which the store treats as unbounded. The UI does not send these; they
// exist for direct API consumers.
func parseActivityTime(r *http.Request, param string) (time.Time, error) {
	raw := strings.TrimSpace(r.URL.Query().Get(param))
	if raw == "" {
		return time.Time{}, nil
	}
	parsed, err := time.Parse(time.RFC3339, raw)
	if err != nil {
		return time.Time{}, fmt.Errorf("invalid '%s' timestamp, use RFC3339 format", param)
	}
	return parsed, nil
}

// parseActivityID reads an optional row id bound. A missing param is 0, which
// the store treats as unbounded.
func parseActivityID(r *http.Request, param string) (int, error) {
	raw := strings.TrimSpace(r.URL.Query().Get(param))
	if raw == "" {
		return 0, nil
	}
	id, err := strconv.Atoi(raw)
	if err != nil || id < 1 {
		return 0, fmt.Errorf("%s must be >= 1", param)
	}
	return id, nil
}

func parseActivityQuery(r *http.Request) (store.ActivityQuery, error) {
	const defaultLimit = 25
	query := store.ActivityQuery{
		Limit: defaultLimit,
		Page:  1,
	}

	// model repeats to filter on several models at once (?model=a&model=b).
	// A single ?model=x stays a plain exact match.
	for _, raw := range r.URL.Query()["model"] {
		if model := strings.TrimSpace(raw); model != "" {
			query.Models = append(query.Models, model)
		}
	}

	start, err := parseActivityTime(r, "start")
	if err != nil {
		return store.ActivityQuery{}, err
	}
	end, err := parseActivityTime(r, "end")
	if err != nil {
		return store.ActivityQuery{}, err
	}
	if !start.IsZero() && !end.IsZero() && start.After(end) {
		return store.ActivityQuery{}, fmt.Errorf("start must be before end")
	}
	query.Start, query.End = start, end

	minID, err := parseActivityID(r, "min_id")
	if err != nil {
		return store.ActivityQuery{}, err
	}
	maxID, err := parseActivityID(r, "max_id")
	if err != nil {
		return store.ActivityQuery{}, err
	}
	if minID > 0 && maxID > 0 && minID > maxID {
		return store.ActivityQuery{}, fmt.Errorf("min_id must be <= max_id")
	}
	query.MinID, query.MaxID = minID, maxID

	if raw := strings.TrimSpace(r.URL.Query().Get("limit")); raw != "" {
		limit, err := parseActivityLimit(raw)
		if err != nil {
			return store.ActivityQuery{}, err
		}
		query.Limit = limit
	}

	if raw := strings.TrimSpace(r.URL.Query().Get("page")); raw != "" {
		page, err := strconv.Atoi(raw)
		if err != nil || page < 1 {
			return store.ActivityQuery{}, fmt.Errorf("page must be >= 1")
		}
		query.Page = page
	}

	if raw := strings.TrimSpace(r.URL.Query().Get("sort")); raw != "" {
		if _, ok := store.ActivitySortColumn(raw); !ok {
			return store.ActivityQuery{}, fmt.Errorf("invalid sort column")
		}
		query.Sort = raw
	}

	if raw := strings.TrimSpace(r.URL.Query().Get("order")); raw != "" {
		switch strings.ToLower(raw) {
		case "asc", "desc":
			query.Order = strings.ToLower(raw)
		default:
			return store.ActivityQuery{}, fmt.Errorf("order must be asc or desc")
		}
	}

	return query, nil
}

// handleAPIPerformance serves the buffered system/GPU stats, optionally
// filtered to samples after the ?after=<RFC3339> timestamp.
func (s *Server) handleAPIPerformance(w http.ResponseWriter, r *http.Request) {
	if s.perf == nil {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusServiceUnavailable)
		json.NewEncoder(w).Encode(map[string]bool{"enabled": false})
		return
	}

	sysStats, gpuStats := s.perf.Current()

	if afterStr := r.URL.Query().Get("after"); afterStr != "" {
		after, err := time.Parse(time.RFC3339, afterStr)
		if err != nil {
			swaputil.SendResponse(w, r, http.StatusBadRequest, "invalid 'after' timestamp, use RFC3339 format")
			return
		}
		filteredSys := make([]perf.SysStat, 0, len(sysStats))
		for _, st := range sysStats {
			if st.Timestamp.After(after) {
				filteredSys = append(filteredSys, st)
			}
		}
		sysStats = filteredSys

		filteredGpu := make([]perf.GpuStat, 0, len(gpuStats))
		for _, g := range gpuStats {
			if g.Timestamp.After(after) {
				filteredGpu = append(filteredGpu, g)
			}
		}
		gpuStats = filteredGpu
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{
		"enabled":   true,
		"sys_stats": sysStats,
		"gpu_stats": gpuStats,
	})
}

// handleAPIVersion serves the build metadata.
func (s *Server) handleAPIVersion(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{
		"version":    s.build.Version,
		"commit":     s.build.Commit,
		"build_date": s.build.Date,
	})
}

// handleAPIHardware serves the hardware snapshot captured at process startup.
func (s *Server) handleAPIHardware(w http.ResponseWriter, r *http.Request) {
	if s.hardware == nil {
		swaputil.SendResponse(w, r, http.StatusServiceUnavailable, "hardware detection unavailable")
		return
	}
	w.Header().Set("Content-Type", "application/json")
	if err := json.NewEncoder(w).Encode(s.hardware); err != nil {
		s.proxylog.Warnf("failed to encode hardware snapshot: %v", err)
	}
}

// handleAPICapture returns the stored request/response capture for a metric ID.
func (s *Server) handleAPICapture(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.Atoi(r.PathValue("id"))
	if err != nil {
		swaputil.SendResponse(w, r, http.StatusBadRequest, "invalid capture ID")
		return
	}

	capture := s.metrics.getCaptureByID(id)
	if capture == nil {
		swaputil.SendResponse(w, r, http.StatusNotFound, "capture not found")
		return
	}

	jsonBytes, err := json.Marshal(capture)
	if err != nil {
		swaputil.SendResponse(w, r, http.StatusInternalServerError, "failed to marshal capture")
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Write(jsonBytes)
}

// handleAPICancelInflight cancels an active model-dispatched request by its
// inflight ID. Normal request cleanup removes the row and emits the update.
func (s *Server) handleAPICancelInflight(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	if id == "" || !s.inflight.Cancel(id) {
		swaputil.SendResponse(w, r, http.StatusNotFound, "inflight request not found")
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"msg": "ok"})
}

type messageType string

const (
	msgTypeModelStatus messageType = "modelStatus"
	msgTypeLogData     messageType = "logData"
	msgTypeActivity    messageType = "activity"
	msgTypeInFlight    messageType = "inflight"
	msgTypeUIConfig    messageType = "uiConfig"
	msgTypeProfile     messageType = "profileChanged"
)

// sendDropReportInterval is how often handleAPIEvents reports messages that
// were dropped because the send buffer was full.
const sendDropReportInterval = 5 * time.Second

type messageEnvelope struct {
	Type messageType `json:"type"`
	Data string      `json:"data"`
}

// handleAPIEvents streams server events (model status, log data, metrics,
// in-flight counts) to the client as Server-Sent Events.
func (s *Server) handleAPIEvents(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("Connection", "keep-alive")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	// prevent nginx from buffering SSE
	w.Header().Set("X-Accel-Buffering", "no")

	flusher, ok := w.(http.Flusher)
	if !ok {
		swaputil.SendResponse(w, r, http.StatusInternalServerError, "streaming unsupported")
		return
	}

	// internal/event already has a 50K event buffer
	// a 1K message buffer should be enough, watch the logs for the warning that the sendBuffer is full
	sendBuffer := make(chan messageEnvelope, 1024)
	ctx, cancel := context.WithCancel(r.Context())
	defer cancel()

	// Dropped messages are counted and reported at most once per interval.
	// Logging every drop floods the logs because each warning becomes a log
	// event that is sent over this same buffer, which drops again.
	dropped := newSuppressionCounter(sendDropReportInterval)
	cancelled := newSuppressionCounter(sendDropReportInterval)
	reportDropped := func(n int) {
		s.proxylog.Warnf("handleAPIEvents sendBuffer full, %d messages suppressed", n)
	}
	reportCancelled := func(n int) {
		s.proxylog.Warnf("handleAPIEvents send suppressed due to context done, %d messages suppressed", n)
	}
	// runs after the event handlers below are unsubscribed so any remaining
	// counts are reported before the connection goes away
	defer func() {
		if n, ok := dropped.Flush(); ok {
			reportDropped(n)
		}
		if n, ok := cancelled.Flush(); ok {
			reportCancelled(n)
		}
	}()

	send := func(msg messageEnvelope) {
		select {
		case sendBuffer <- msg:
		case <-ctx.Done():
			if n, ok := cancelled.Add(); ok {
				reportCancelled(n)
			}
		default:
			if n, ok := dropped.Add(); ok {
				reportDropped(n)
			}
		}
	}
	sendModels := func() {
		if data, err := json.Marshal(s.modelStatus()); err == nil {
			send(messageEnvelope{Type: msgTypeModelStatus, Data: string(data)})
		}
	}
	sendLogData := func(source string, data []byte) {
		if j, err := json.Marshal(map[string]string{"source": source, "data": string(data)}); err == nil {
			send(messageEnvelope{Type: msgTypeLogData, Data: string(j)})
		}
	}
	sendActivity := func(id int) {
		if j, err := json.Marshal(map[string]int{"id": id}); err == nil {
			send(messageEnvelope{Type: msgTypeActivity, Data: string(j)})
		}
	}
	sendInFlight := func(update swaputil.InFlightRequestsEvent) {
		if update.Operation == inflightOperationSnapshot && update.Requests == nil {
			update.Requests = []swaputil.InflightRequestEntry{}
		}
		if j, err := json.Marshal(update); err == nil {
			send(messageEnvelope{Type: msgTypeInFlight, Data: string(j)})
		}
	}
	sendUIConfig := func() {
		if j, err := json.Marshal(s.cfg.UI); err == nil {
			send(messageEnvelope{Type: msgTypeUIConfig, Data: string(j)})
		}
	}
	sendProfile := func() {
		if j, err := json.Marshal(map[string]any{"active": nullableProfile(s.ActiveProfile())}); err == nil {
			send(messageEnvelope{Type: msgTypeProfile, Data: string(j)})
		}
	}

	defer event.On(func(e swaputil.ProcessStateChangeEvent) { sendModels() })()
	defer event.On(func(e swaputil.ConfigFileChangedEvent) { sendModels() })()
	defer event.On(func(e swaputil.ProfileChangedEvent) {
		sendProfile()
		sendModels()
	})()
	defer s.proxylog.OnLogData(func(data []byte) { sendLogData("proxy", data) })()
	defer s.upstreamlog.OnLogData(func(data []byte) { sendLogData("upstream", data) })()
	defer event.On(func(e ActivityLogEvent) { sendActivity(e.Metrics.ID) })()
	defer event.On(func(e swaputil.InFlightRequestsEvent) { sendInFlight(e) })()

	// initial payload
	sendLogData("proxy", s.proxylog.GetHistory())
	sendLogData("upstream", s.upstreamlog.GetHistory())
	sendModels()
	sendUIConfig()
	sendProfile()
	sendInFlight(s.inflight.Current())

	for {
		select {
		case <-r.Context().Done():
			return
		case <-s.shutdownCtx.Done():
			return
		case msg := <-sendBuffer:
			data, err := json.Marshal(msg)
			if err != nil {
				continue
			}
			fmt.Fprintf(w, "event:message\ndata:%s\n\n", data)
			flusher.Flush()
		}
	}
}
