package config

import (
	"fmt"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestConfig_Selectors_LoadDefaultsAndFields(t *testing.T) {
	cfg, err := LoadConfigFromReader(strings.NewReader(`
models:
  a:
    cmd: echo ${PORT}
  b:
    cmd: echo ${PORT}
groups:
  balanced:
    swap: false
    members: [a, b]
selectors:
  coding:
    strategy: warm
    targets: [a, b]
    name: Coding Model
    description: Best available coding model
    unlisted: true
    metadata:
      family: coding
  workers:
    strategy: spillover
    targets: [a, b]
`))
	require.NoError(t, err)

	coding := cfg.Selectors["coding"]
	assert.Equal(t, SelectorStrategyWarm, coding.Strategy)
	assert.Equal(t, []string{"a", "b"}, coding.Targets)
	assert.Equal(t, 1, coding.Settings.Spillover)
	assert.Equal(t, "Coding Model", coding.Name)
	assert.Equal(t, "Best available coding model", coding.Description)
	assert.True(t, coding.Unlisted)
	assert.Equal(t, "coding", coding.Metadata["family"])

	workers := cfg.Selectors["workers"]
	assert.Equal(t, 1, workers.Settings.Spillover)
}

func TestConfig_Selectors_Validation(t *testing.T) {
	tests := []struct {
		name    string
		config  string
		wantErr string
	}{
		{
			name: "empty selector id",
			config: `
selectors:
  " ":
    strategy: pin
    targets: [a]
`,
			wantErr: "selector names cannot be empty",
		},
		{
			name: "missing strategy",
			config: `
selectors:
  public:
    targets: [a]
`,
			wantErr: "strategy is required",
		},
		{
			name: "unknown strategy",
			config: `
selectors:
  public:
    strategy: random
    targets: [a]
`,
			wantErr: "unknown strategy",
		},
		{
			name: "missing targets",
			config: `
selectors:
  public:
    strategy: pin
`,
			wantErr: "targets must contain at least one entry",
		},
		{
			name: "unknown target",
			config: `
selectors:
  public:
    strategy: pin
    targets: [missing]
`,
			wantErr: `references unknown model "missing"`,
		},
		{
			name: "selector chaining",
			config: `
selectors:
  first:
    strategy: pin
    targets: [a]
  second:
    strategy: pin
    targets: [first]
`,
			wantErr: "selector chaining is not supported",
		},
		{
			name: "model id collision",
			config: `
selectors:
  a:
    strategy: pin
    targets: [a]
`,
			wantErr: "name conflicts with model ID",
		},
		{
			name: "explicit alias collision",
			config: `
selectors:
  alias-a:
    strategy: pin
    targets: [a]
`,
			wantErr: "name conflicts with model alias",
		},
		{
			name: "generated alias collision",
			config: `
selectors:
  variant:
    strategy: pin
    targets: [a]
`,
			wantErr: "name conflicts with model alias",
		},
		{
			name: "warm peer target",
			config: `
selectors:
  public:
    strategy: warm
    targets: [remote-model]
`,
			wantErr: `must resolve to a local model for strategy "warm"`,
		},
		{
			name: "invalid spillover",
			config: `
selectors:
  public:
    strategy: spillover
    targets: [a]
    settings:
      spillover: 0
`,
			wantErr: "settings.spillover must be >= 1",
		},
		{
			name: "duplicate resolved spillover target",
			config: `
selectors:
  public:
    strategy: spillover
    targets: [a, alias-a]
`,
			wantErr: `duplicate resolved model "a"`,
		},
		{
			name: "duplicate resolved peer spillover target",
			config: `
selectors:
  public:
    strategy: spillover
    targets: [remote-model, remote/remote-model]
`,
			wantErr: `duplicate resolved model "remote/remote-model"`,
		},
		{
			name: "spillover swapping group",
			config: `
selectors:
  public:
    strategy: spillover
    targets: [a, b]
`,
			wantErr: "must share a group with swap: false",
		},
	}

	const base = `
models:
  a:
    cmd: echo ${PORT}
    aliases: [alias-a]
    filters:
      setParamsByID:
        variant:
          temperature: 0
  b:
    cmd: echo ${PORT}
peers:
  remote:
    proxy: http://example.com
    models: [remote-model]
`

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			_, err := LoadConfigFromReader(strings.NewReader(base + tc.config))
			require.Error(t, err)
			assert.Contains(t, err.Error(), tc.wantErr)
		})
	}
}

func TestConfig_Selectors_PeerModelFQN(t *testing.T) {
	cfg, err := LoadConfigFromReader(strings.NewReader(`
peers:
  remote:
    proxy: http://example.com
    models: [remote-model]
selectors:
  remote-model:
    strategy: spillover
    targets: [remote/remote-model]
`))
	require.NoError(t, err)
	assert.Equal(t, []string{"remote/remote-model"}, cfg.Selectors["remote-model"].Targets)
}

func TestConfig_Selectors_SpilloverCoexistence(t *testing.T) {
	t.Run("group", func(t *testing.T) {
		cfg, err := LoadConfigFromReader(strings.NewReader(`
models:
  a:
    cmd: echo ${PORT}
  b:
    cmd: echo ${PORT}
groups:
  pool:
    swap: false
    members: [a, b]
selectors:
  public:
    strategy: spillover
    targets: [a, b]
    settings:
      spillover: 4
`))
		require.NoError(t, err)
		assert.Equal(t, 4, cfg.Selectors["public"].Settings.Spillover)
	})

	t.Run("matrix common set", func(t *testing.T) {
		_, err := LoadConfigFromReader(strings.NewReader(`
models:
  a:
    cmd: echo ${PORT}
  b:
    cmd: echo ${PORT}
matrix:
  vars:
    A: a
    B: b
  sets:
    pool: "A & B"
selectors:
  public:
    strategy: spillover
    targets: [a, b]
`))
		require.NoError(t, err)
	})

	t.Run("matrix separate sets", func(t *testing.T) {
		_, err := LoadConfigFromReader(strings.NewReader(`
models:
  a:
    cmd: echo ${PORT}
  b:
    cmd: echo ${PORT}
matrix:
  vars:
    A: a
    B: b
  sets:
    pool: "A | B"
selectors:
  public:
    strategy: spillover
    targets: [a, b]
`))
		require.Error(t, err)
		assert.Contains(t, err.Error(), "must all appear together in one expanded matrix set")
	})

	t.Run("matrix symbolic large", func(t *testing.T) {
		const (
			dimensions = 4
			choices    = 11
		)

		var yaml strings.Builder
		yaml.WriteString("models:\n  target:\n    cmd: echo ${PORT}\n")
		groups := make([]string, dimensions)
		for dimension := range dimensions {
			alternatives := make([]string, choices)
			for choice := range choices {
				name := fmt.Sprintf("model-%d-%d", dimension, choice)
				alternatives[choice] = name
				fmt.Fprintf(&yaml, "  %s:\n    cmd: echo ${PORT}\n", name)
			}
			groups[dimension] = "(" + strings.Join(alternatives, " | ") + ")"
		}
		fmt.Fprintf(&yaml, "matrix:\n  sets:\n    large: \"target & %s\"\n", strings.Join(groups, " & "))
		yaml.WriteString("selectors:\n  public:\n    strategy: spillover\n    targets: [target, model-0-0]\n")

		_, err := LoadConfigFromReader(strings.NewReader(yaml.String()))
		require.NoError(t, err)
	})

	t.Run("remote targets", func(t *testing.T) {
		_, err := LoadConfigFromReader(strings.NewReader(`
peers:
  remote:
    proxy: http://example.com
    models: [a, b]
selectors:
  public:
    strategy: spillover
    targets: [remote/a, remote/b]
`))
		require.NoError(t, err)
	})

	t.Run("mixed local and remote targets", func(t *testing.T) {
		_, err := LoadConfigFromReader(strings.NewReader(`
models:
  local:
    cmd: echo ${PORT}
peers:
  remote:
    proxy: http://example.com
    models: [remote-model]
selectors:
  public:
    strategy: spillover
    targets: [local, remote/remote-model]
`))
		require.NoError(t, err)
	})
}

func TestConfig_Selectors_ProfileTargetsSelector(t *testing.T) {
	cfg, err := LoadConfigFromReader(strings.NewReader(`
models:
  a:
    cmd: echo ${PORT}
selectors:
  public:
    strategy: pin
    targets: [a]
profiles:
  coding:
    pins:
      llm-code: public
`))
	require.NoError(t, err)
	assert.Equal(t, "public", cfg.Profiles["coding"].Pins["llm-code"])
}

func TestConfig_Selectors_MergeDuplicate(t *testing.T) {
	dir := t.TempDir()
	writeYAML(t, dir, "a.yaml", `
models:
  a:
    cmd: echo ${PORT}
selectors:
  public:
    strategy: pin
    targets: [a]
`)
	writeYAML(t, dir, "b.yaml", `
selectors:
  public:
    strategy: pin
    targets: [a]
`)

	_, err := LoadConfigSources("", dir)
	require.Error(t, err)
	assert.Contains(t, err.Error(), `duplicate selectors "public"`)
}
