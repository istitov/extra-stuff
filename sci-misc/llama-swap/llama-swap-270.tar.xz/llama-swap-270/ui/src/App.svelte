<script lang="ts">
  import { onMount } from "svelte";
  import type { Component, ComponentType, SvelteComponent } from "svelte";
  import Router, { replace } from "svelte-spa-router";
  import { wrap } from "svelte-spa-router/wrap";
  import AppSidebar from "./components/AppSidebar.svelte";
  import RouteLoadingImpl from "./components/RouteLoading.svelte";
  import AlwaysMountedStub from "./routes/AlwaysMountedStub.svelte";
  import * as Sidebar from "$lib/components/ui/sidebar/index.js";
  import * as Tooltip from "$lib/components/ui/tooltip/index.js";
  import { Separator } from "$lib/components/ui/separator/index.js";
  import * as Select from "$lib/components/ui/select/index.js";
  import * as DropdownMenu from "$lib/components/ui/dropdown-menu/index.js";
  import { Check, ChevronDown, Loader2, Pause, Play } from "@lucide/svelte";
  import {
    activeProfile,
    checkPerformanceEnabled,
    enableAPIEvents,
    helpAgentEnabled,
    inferencePaused,
    profiles,
    resumeInference,
    setActiveProfile,
  } from "./stores/api";
  import { initScreenWidth, initSystemThemeListener, isDarkMode, themeName, appTitle, connectionState } from "./stores/theme";
  import { currentRoute } from "./stores/route";
  import { selectedPlaygroundTab, playgroundTabs } from "./stores/playground";
  import { sidebarOpen, sidebarWidth } from "./stores/sidebar";

  // svelte-spa-router's types predate Svelte 5 (loadingComponent wants the
  // old class-component ComponentType); the cast is safe since Router.svelte
  // just instantiates whatever component object it's given.
  const RouteLoading = RouteLoadingImpl as unknown as ComponentType<SvelteComponent>;

  // Routes are lazy-loaded so their (and their dependencies') code isn't part
  // of the initial bundle; each becomes its own chunk fetched on first visit.
  // loadingComponent covers the (usually brief) fetch with a themed
  // placeholder instead of a blank/white flash.
  const routes = {
    "/": wrap({ asyncComponent: () => import("./routes/Activity.svelte"), loadingComponent: RouteLoading }),
    "/playground": AlwaysMountedStub,
    "/help": AlwaysMountedStub,
    "/models": wrap({ asyncComponent: () => import("./routes/ModelsDash.svelte"), loadingComponent: RouteLoading }),
    "/models/:id": wrap({ asyncComponent: () => import("./routes/ModelDetail.svelte"), loadingComponent: RouteLoading }),
    "/logs": wrap({ asyncComponent: () => import("./routes/LogViewer.svelte"), loadingComponent: RouteLoading }),
    "/activity": wrap({ asyncComponent: () => import("./routes/Activity.svelte"), loadingComponent: RouteLoading }),
    "/settings": wrap({ asyncComponent: () => import("./routes/Settings.svelte"), loadingComponent: RouteLoading }),
    "/performance": wrap({ asyncComponent: () => import("./routes/Performance.svelte"), loadingComponent: RouteLoading }),
    "/hardware": wrap({ asyncComponent: () => import("./routes/Hardware.svelte"), loadingComponent: RouteLoading }),
    "/tailcat": wrap({ asyncComponent: () => import("./routes/Tailcat.svelte"), loadingComponent: RouteLoading }),
    "*": wrap({ asyncComponent: () => import("./routes/Activity.svelte"), loadingComponent: RouteLoading }),
  };

  const routeTitles: Record<string, string> = {
    "/": "Activity",
    "/playground": "Playground",
    "/help": "Help",
    "/models": "Models",
    "/activity": "Activity",
    "/logs": "Logs",
    "/settings": "Settings",
    "/performance": "Performance",
    "/hardware": "Hardware",
    "/tailcat": "Tailcat",
  };

  // The phone header is tight (sidebar button, title, profile picker), so the
  // Playground's tab picker there shows the tab name alone rather than the
  // full "Playground / Chat", which would truncate to nothing useful.
  let playgroundTabLabel = $derived(
    playgroundTabs.find((t) => t.id === $selectedPlaygroundTab)?.label ?? "Playground"
  );

  let sectionTitle = $derived.by(() => {
    if ($currentRoute === "/playground") {
      const tab = playgroundTabs.find((t) => t.id === $selectedPlaygroundTab);
      return `Playground / ${tab?.label ?? ""}`;
    }
    if ($currentRoute.startsWith("/models/")) {
      const id = $currentRoute.slice("/models/".length);
      return id ? `Models / ${decodeURIComponent(id)}` : "Models";
    }
    if ($currentRoute === "/models") {
      return "Models";
    }
    return routeTitles[$currentRoute] ?? "Activity";
  });

  // While inference is paused a banner is fixed across the top of the window.
  // --banner-h pushes the layout, including the fixed sidebar, down by its
  // height; it is 0px otherwise.
  let bannerHeight = $derived($inferencePaused ? "2.25rem" : "0px");
  let resuming = $state(false);

  async function handleResume(): Promise<void> {
    resuming = true;
    try {
      await resumeInference();
    } catch (error) {
      console.error(error);
    } finally {
      resuming = false;
    }
  }

  const noProfileValue = "__none__";
  let switchingProfile = $state(false);

  async function handleProfileChange(value: string): Promise<void> {
    switchingProfile = true;
    try {
      await setActiveProfile(value === noProfileValue ? null : value);
    } catch (error) {
      console.error(error);
    } finally {
      switchingProfile = false;
    }
  }

  function handleRouteLoaded(event: { detail: { route: string | RegExp; location?: string } }) {
    const route = event.detail.route;
    // Prefer the actual URL path so parameterised routes (e.g. /models/:id)
    // are reflected accurately in currentRoute for sidebar highlighting.
    const loc = event.detail.location;
    currentRoute.set(loc ?? (typeof route === "string" ? route : "/"));
  }

  $effect(() => {
    document.documentElement.classList.toggle("dark", $isDarkMode);
  });

  $effect(() => {
    const el = document.documentElement;
    if ($themeName === "default") el.removeAttribute("data-theme");
    else el.setAttribute("data-theme", $themeName);
  });

  $effect(() => {
    const icon = $connectionState === "connecting" ? "\u{1F7E1}" : $connectionState === "connected" ? "\u{1F7E2}" : "\u{1F534}";
    document.title = `${icon} ${$appTitle}`;
  });

  // Playground and Help are always mounted (rather than routed) so they keep
  // their state when the user navigates away -- a chat that is still streaming
  // survives a look at the logs. Both are still lazy-loaded on app start so
  // their dependencies (chat markdown/KaTeX/highlight.js rendering) don't
  // block the initial page load.
  let PlaygroundComponent = $state<Component | null>(null);
  let HelpComponent = $state<Component | null>(null);

  // helpagent.disable in the config hides Help; a bookmarked /help goes home.
  $effect(() => {
    if (!$helpAgentEnabled && $currentRoute === "/help") replace("/");
  });

  onMount(() => {
    const cleanupScreenWidth = initScreenWidth();
    const cleanupSystemTheme = initSystemThemeListener();
    enableAPIEvents(true);
    checkPerformanceEnabled();
    import("./routes/Playground.svelte").then((m) => {
      PlaygroundComponent = m.default;
    });
    import("./routes/Help.svelte").then((m) => {
      HelpComponent = m.default;
    });

    return () => {
      cleanupScreenWidth();
      cleanupSystemTheme();
      enableAPIEvents(false);
    };
  });
</script>

<Tooltip.Provider>
  {#if $inferencePaused}
    <div
      role="status"
      class="bg-warning text-black fixed inset-x-0 top-0 z-30 flex h-9 items-center justify-center gap-2 px-4 text-sm font-medium"
    >
      <Pause class="size-4 shrink-0" />
      <span class="truncate">
        Inference is paused.<span class="hidden sm:inline">{" "}All inference requests are rejected until you resume.</span>
      </span>
      <button
        type="button"
        class="ml-1 flex h-6 shrink-0 items-center gap-1 rounded-md border border-black/30 bg-white/80 px-2 text-xs font-medium text-black hover:bg-white disabled:opacity-60"
        onclick={handleResume}
        disabled={resuming}
      >
        {#if resuming}
          <Loader2 class="size-3 animate-spin" />
        {:else}
          <Play class="size-3" />
        {/if}
        Resume
      </button>
    </div>
  {/if}
  <Sidebar.Provider
    class="pt-(--banner-h)"
    style="--banner-h: {bannerHeight};"
    open={$sidebarOpen}
    onOpenChange={(v) => sidebarOpen.set(v)}
    width={$sidebarWidth}
    onWidthChange={(w) => sidebarWidth.set(w)}
  >
    <AppSidebar />
    <Sidebar.Inset class="h-[calc(100vh-var(--banner-h))] min-w-0 overflow-hidden">
      <header
        class="bg-background sticky top-0 z-10 flex h-14 shrink-0 items-center gap-2 border-b px-4"
      >
        <Sidebar.Trigger class="-ml-1" />
        <Separator orientation="vertical" class="mr-2 !h-4" />
        {#if $currentRoute === "/playground"}
          <!-- Phones hide the Playground's tab strip so the full height goes to
               the tab itself, so the header title doubles as the tab picker
               there. Wider screens keep the strip and a plain title. -->
          <DropdownMenu.Root>
            <DropdownMenu.Trigger
              class="hover:bg-muted -mx-1 flex min-w-0 items-center gap-1 rounded-md px-1 py-1 sm:hidden"
              aria-label="Switch playground tab"
            >
              <span class="truncate text-sm font-semibold">{playgroundTabLabel}</span>
              <ChevronDown class="text-muted-foreground size-4 shrink-0" />
            </DropdownMenu.Trigger>
            <DropdownMenu.Content align="start" class="min-w-44">
              {#each playgroundTabs as tab (tab.id)}
                <DropdownMenu.Item class="gap-2 py-2 text-base" onSelect={() => selectedPlaygroundTab.set(tab.id)}>
                  <Check
                    class="size-4 {$selectedPlaygroundTab === tab.id ? '' : 'invisible'}"
                  />
                  {tab.label}
                </DropdownMenu.Item>
              {/each}
            </DropdownMenu.Content>
          </DropdownMenu.Root>
          <h2 class="hidden truncate pb-0 text-sm font-semibold sm:block">{sectionTitle}</h2>
        {:else}
          <h2 class="truncate pb-0 text-sm font-semibold">{sectionTitle}</h2>
        {/if}
        {#if $profiles.length > 0}
          <div class="ml-auto flex items-center gap-2">
            <span class="text-muted-foreground hidden text-xs sm:inline">Profile</span>
            <Select.Root
              type="single"
              value={$activeProfile ?? noProfileValue}
              onValueChange={(value) => value && void handleProfileChange(value)}
            >
              <Select.Trigger
                class="w-40"
                aria-label="Active profile"
                disabled={switchingProfile}
              >
                {$activeProfile ?? "None"}
              </Select.Trigger>
              <Select.Content>
                <Select.Item value={noProfileValue}>None</Select.Item>
                {#each $profiles as profile (profile.id)}
                  <Select.Item value={profile.id}>{profile.id}</Select.Item>
                {/each}
              </Select.Content>
            </Select.Root>
          </div>
        {/if}
      </header>

      <main class="min-h-0 flex-1 overflow-auto p-2 sm:p-4">
        <div class="h-full" class:hidden={$currentRoute !== "/playground"}>
          {#if PlaygroundComponent}
            <PlaygroundComponent />
          {:else}
            <RouteLoading />
          {/if}
        </div>
        {#if $helpAgentEnabled}
          <div class="h-full" class:hidden={$currentRoute !== "/help"}>
            {#if HelpComponent}
              <HelpComponent />
            {:else}
              <RouteLoading />
            {/if}
          </div>
        {/if}
        <div class="h-full" class:hidden={$currentRoute === "/playground" || $currentRoute === "/help"}>
          <Router {routes} on:routeLoaded={handleRouteLoaded} />
        </div>
      </main>
    </Sidebar.Inset>
  </Sidebar.Provider>
</Tooltip.Provider>
