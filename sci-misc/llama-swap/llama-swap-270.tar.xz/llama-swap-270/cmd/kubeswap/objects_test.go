package main

import (
	"strings"
	"testing"

	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	"k8s.io/apimachinery/pkg/util/intstr"
)

// testConfig Returns a serveConfig with every rendered field group populated, for the rendering tests.
func testConfig() *serveConfig {
	cfg := &serveConfig{
		Model:        "author/model:tag",
		Sanitized:    "author-model-tag",
		Namespace:    "llama-swap",
		Image:        "ghcr.io/ggml-org/llama.cpp:server-vulkan",
		Args:         []string{"--model", "/models/m.gguf", "--port", "8080"},
		Port:         8080,
		HealthPath:   "/health",
		CheckPath:    "/health",
		LivenessPath: "",
		ProbeTimeout: 5,
		Env:          []envVar{{Key: "HSA_FORCE_FINE_GRAIN_PCIE", Value: "1"}},
		GPUs:         map[string]string{"amd.com/gpu": "1"},
		NodeSel:      map[string]string{"feature.node.kubernetes.io/amd-gpu": "true"},
		Tolerations:  []toleration{{Key: "dedicated", Operator: "Exists", Effect: "NoSchedule"}},
		Volumes: []volumeSpec{
			{Kind: volPVC, Name: "llama-swap-models", Path: "/models", ReadOnly: true},
			{Kind: volEmptyDir, Name: "slots", Path: "/slots"},
		},
		ExtraLabels:  map[string]string{"team": "inference"},
		PVCSize:      "5Gi",
		PVCClass:     "local-path",
		GraceSeconds: 30,
	}
	cfg.DepName, _ = deploymentName(cfg.Model)
	cfg.SvcName, _ = serviceName(cfg.Model)
	return cfg
}

// TestKubeswap_RenderDeployment Verifies the rendered Deployment: labels, probes, volumes and GPU resources.
func TestKubeswap_RenderDeployment(t *testing.T) {
	cfg := testConfig()
	dep, err := cfg.renderDeployment()
	if err != nil {
		t.Fatalf("renderDeployment: %v", err)
	}

	if dep.Name != cfg.DepName || dep.Namespace != "llama-swap" {
		t.Errorf("name/namespace: %s/%s", dep.Namespace, dep.Name)
	}
	if dep.Labels[labelModel] != "author-model-tag" || dep.Labels[labelManagedBy] != managedByValue {
		t.Errorf("labels: %v", dep.Labels)
	}
	if dep.Spec.Selector.MatchLabels[labelDeployment] != cfg.DepName {
		t.Errorf("deployment selector must carry the deployment label: %v", dep.Spec.Selector.MatchLabels)
	}
	tpl := dep.Spec.Template
	if tpl.Labels[labelDeployment] != cfg.DepName {
		t.Errorf("pod template deployment label: %v", tpl.Labels)
	}
	if dep.Annotations[annotationModelID] != "author/model:tag" {
		t.Errorf("annotation model-id: %v", dep.Annotations)
	}
	if dep.Spec.Replicas == nil || *dep.Spec.Replicas != 1 {
		t.Error("expected replicas=1")
	}
	if dep.Spec.Strategy.Type != "Recreate" {
		t.Errorf("expected Recreate strategy, got %s", dep.Spec.Strategy.Type)
	}

	pod := &dep.Spec.Template
	if pod.Labels[labelModel] != "author-model-tag" || pod.Labels[labelAppName] != appNameValue {
		t.Errorf("pod template labels: %v", pod.Labels)
	}
	if pod.Labels["team"] != "inference" {
		t.Errorf("extra pod labels missing: %v", pod.Labels)
	}

	c := pod.Spec.Containers[0]
	if c.Name != containerName || c.Image != cfg.Image {
		t.Errorf("container name/image: %s %s", c.Name, c.Image)
	}
	if strings.Join(c.Args, " ") != strings.Join(cfg.Args, " ") {
		t.Errorf("args: %v", c.Args)
	}
	if len(c.Env) != 1 || c.Env[0].Name != "HSA_FORCE_FINE_GRAIN_PCIE" || c.Env[0].Value != "1" {
		t.Errorf("env: %v", c.Env)
	}
	if got := c.Resources.Limits[corev1.ResourceName("amd.com/gpu")]; got.String() != "1" {
		t.Errorf("gpu limit: %v", c.Resources.Limits)
	}
	if got := c.Resources.Requests[corev1.ResourceName("amd.com/gpu")]; got.String() != "1" {
		t.Errorf("gpu request: %v", c.Resources.Requests)
	}
	if c.ReadinessProbe == nil || c.ReadinessProbe.HTTPGet == nil ||
		c.ReadinessProbe.HTTPGet.Path != "/health" {
		t.Errorf("readiness probe: %v", c.ReadinessProbe)
	}
	if c.LivenessProbe == nil || c.LivenessProbe.HTTPGet == nil ||
		c.LivenessProbe.HTTPGet.Path != "/health" {
		t.Errorf("liveness probe: %v", c.LivenessProbe)
	}
	if c.StartupProbe == nil || c.StartupProbe.HTTPGet == nil ||
		c.StartupProbe.HTTPGet.Path != "/health" ||
		c.StartupProbe.FailureThreshold != int32(defaultStartupTimeout/5) {
		t.Errorf("startup probe: %v", c.StartupProbe)
	}
	if len(c.Ports) != 1 || c.Ports[0].Name != "http" || c.Ports[0].ContainerPort != 8080 {
		t.Errorf("container ports: %v", c.Ports)
	}
	if len(c.VolumeMounts) != 2 {
		t.Fatalf("expected 2 mounts, got %d", len(c.VolumeMounts))
	}
	if c.VolumeMounts[0].MountPath != "/models" || !c.VolumeMounts[0].ReadOnly {
		t.Errorf("models mount: %v", c.VolumeMounts[0])
	}
	if c.VolumeMounts[1].MountPath != "/slots" || c.VolumeMounts[1].ReadOnly {
		t.Errorf("slots mount: %v", c.VolumeMounts[1])
	}
	if len(pod.Spec.Volumes) != 2 {
		t.Fatalf("expected 2 volumes, got %d", len(pod.Spec.Volumes))
	}
	if pod.Spec.Volumes[0].PersistentVolumeClaim == nil ||
		pod.Spec.Volumes[0].PersistentVolumeClaim.ClaimName != "llama-swap-models" {
		t.Errorf("pvc volume: %v", pod.Spec.Volumes[0])
	}
	if pod.Spec.Volumes[1].EmptyDir == nil {
		t.Errorf("emptydir volume: %v", pod.Spec.Volumes[1])
	}
	if pod.Spec.NodeSelector["feature.node.kubernetes.io/amd-gpu"] != "true" {
		t.Errorf("nodeSelector: %v", pod.Spec.NodeSelector)
	}
	if len(pod.Spec.Tolerations) != 1 || pod.Spec.Tolerations[0].Key != "dedicated" {
		t.Errorf("tolerations: %v", pod.Spec.Tolerations)
	}
	if pod.Spec.TerminationGracePeriodSeconds == nil || *pod.Spec.TerminationGracePeriodSeconds != 30 {
		t.Error("grace period not set to 30")
	}
}

// TestKubeswap_RenderDeploymentCPU Verifies a GPU-less config renders a CPU-only pod spec.
func TestKubeswap_RenderDeploymentCPU(t *testing.T) {
	cfg := testConfig()
	cfg.GPUs = nil
	cfg.NodeSel = nil
	dep, err := cfg.renderDeployment()
	if err != nil {
		t.Fatalf("renderDeployment: %v", err)
	}
	pod := &dep.Spec.Template
	if len(pod.Spec.Containers[0].Resources.Limits) != 0 {
		t.Errorf("expected no resource limits, got %v", pod.Spec.Containers[0].Resources.Limits)
	}
	if pod.Spec.NodeSelector != nil {
		t.Errorf("expected no nodeSelector, got %v", pod.Spec.NodeSelector)
	}
}

// TestKubeswap_RenderDeploymentResourceClaims Verifies --resource-claim renders the pod-level claim and the container reference.
func TestKubeswap_RenderDeploymentResourceClaims(t *testing.T) {
	cfg := testConfig()
	cfg.ResourceClaims = []resourceClaimSpec{{Name: "gpu", Claim: "pro2000"}}
	dep, err := cfg.renderDeployment()
	if err != nil {
		t.Fatalf("renderDeployment: %v", err)
	}
	pod := dep.Spec.Template.Spec
	if len(pod.ResourceClaims) != 1 || pod.ResourceClaims[0].Name != "gpu" ||
		pod.ResourceClaims[0].ResourceClaimName == nil || *pod.ResourceClaims[0].ResourceClaimName != "pro2000" ||
		pod.ResourceClaims[0].ResourceClaimTemplateName != nil {
		t.Errorf("pod resource claims: %+v", pod.ResourceClaims)
	}
	c := pod.Containers[0]
	if len(c.Resources.Claims) != 1 || c.Resources.Claims[0] != (corev1.ResourceClaim{Name: "gpu"}) {
		t.Errorf("container resource claims: %+v", c.Resources.Claims)
	}
	// Claims add to, not replace, the --gpu requests and limits.
	if got := c.Resources.Limits[corev1.ResourceName("amd.com/gpu")]; got.String() != "1" {
		t.Errorf("gpu limit: %v", c.Resources.Limits)
	}

	// A claim alone (no --gpu/--request/--limit) leaves requests and
	// limits unset.
	cfg.GPUs = nil
	dep, err = cfg.renderDeployment()
	if err != nil {
		t.Fatalf("renderDeployment: %v", err)
	}
	r := dep.Spec.Template.Spec.Containers[0].Resources
	if r.Requests != nil || r.Limits != nil || len(r.Claims) != 1 {
		t.Errorf("claim-only resources: %+v", r)
	}

	// Without --resource-claim nothing is rendered.
	cfg.ResourceClaims = nil
	dep, _ = cfg.renderDeployment()
	if dep.Spec.Template.Spec.ResourceClaims != nil || dep.Spec.Template.Spec.Containers[0].Resources.Claims != nil {
		t.Errorf("expected no resource claims: %+v", dep.Spec.Template.Spec)
	}
}

// TestKubeswap_RenderService Verifies the Service rendered for a model.
func TestKubeswap_RenderService(t *testing.T) {
	cfg := testConfig()
	svc := cfg.renderService()
	if svc.Name != cfg.SvcName || svc.Namespace != "llama-swap" {
		t.Errorf("service name/namespace: %s/%s", svc.Namespace, svc.Name)
	}
	if svc.Spec.Selector[labelModel] != "author-model-tag" {
		t.Errorf("selector: %v", svc.Spec.Selector)
	}
	if svc.Spec.Selector[labelDeployment] != cfg.DepName {
		t.Errorf("service selector must carry the deployment label: %v", svc.Spec.Selector)
	}
	if len(svc.Spec.Ports) != 1 || svc.Spec.Ports[0].Port != 8080 {
		t.Errorf("ports: %v", svc.Spec.Ports)
	}
	if svc.Annotations[annotationModelID] != "author/model:tag" {
		t.Errorf("annotation: %v", svc.Annotations)
	}
}

// TestKubeswap_ServiceSpecMatches Verifies the Service comparison detects
// selector and port drift (primary port, extra service ports, TargetPort)
// while ignoring order and non-owned fields.
func TestKubeswap_ServiceSpecMatches(t *testing.T) {
	cfg := testConfig()
	cfg.ServicePorts = []servicePortSpec{{Name: "metrics", Port: 9090}}
	want := cfg.renderService()

	// Identical specs match.
	if !serviceSpecMatches(want, want) {
		t.Error("identical services should match")
	}

	// Port order is irrelevant.
	shuffled := want.DeepCopy()
	shuffled.Spec.Ports = []corev1.ServicePort{shuffled.Spec.Ports[1], shuffled.Spec.Ports[0]}
	if !serviceSpecMatches(shuffled, want) {
		t.Error("port reordering should match")
	}

	// Primary port drift.
	drifted := want.DeepCopy()
	drifted.Spec.Ports[0].Port = 9999
	if serviceSpecMatches(drifted, want) {
		t.Error("primary port drift should not match")
	}

	// TargetPort drift.
	drifted = want.DeepCopy()
	drifted.Spec.Ports[0].TargetPort = intstr.FromInt32(1234)
	if serviceSpecMatches(drifted, want) {
		t.Error("target port drift should not match")
	}

	// An added service port is drift.
	drifted = want.DeepCopy()
	drifted.Spec.Ports = append(drifted.Spec.Ports, corev1.ServicePort{Name: "extra", Port: 8443, TargetPort: intstr.FromInt32(8443)})
	if serviceSpecMatches(drifted, want) {
		t.Error("added service port should not match")
	}

	// A removed service port is drift.
	drifted = want.DeepCopy()
	drifted.Spec.Ports = drifted.Spec.Ports[:1]
	if serviceSpecMatches(drifted, want) {
		t.Error("removed service port should not match")
	}

	// Selector drift.
	drifted = want.DeepCopy()
	drifted.Spec.Selector = map[string]string{labelModel: "someone-else"}
	if serviceSpecMatches(drifted, want) {
		t.Error("selector drift should not match")
	}

	// Nil handling.
	if serviceSpecMatches(nil, want) || serviceSpecMatches(want, nil) {
		t.Error("nil and non-nil services should not match")
	}
	if !serviceSpecMatches(nil, nil) {
		t.Error("two nil services should match")
	}
}

// TestKubeswap_RenderDeploymentCommandPortsProbes Verifies command overrides, extra service ports and probe paths in the rendered spec.
func TestKubeswap_RenderDeploymentCommandPortsProbes(t *testing.T) {
	cfg := testConfig()
	cfg.GPUs = nil
	cfg.Command = []string{"sd-server"}
	cfg.ServicePorts = []servicePortSpec{{Name: "metrics", Port: 9090}}
	cfg.LivenessPath = "/live"
	cfg.ProbeTimeout = 10
	cfg.Requests = map[string]string{"cpu": "2"}
	cfg.Limits = map[string]string{"memory": "4Gi"}

	dep, err := cfg.renderDeployment()
	if err != nil {
		t.Fatalf("renderDeployment: %v", err)
	}
	c := dep.Spec.Template.Spec.Containers[0]

	if strings.Join(c.Command, " ") != "sd-server" {
		t.Errorf("command: %v", c.Command)
	}
	if len(c.Ports) != 2 || c.Ports[1].Name != "metrics" || c.Ports[1].ContainerPort != 9090 {
		t.Errorf("container ports: %v", c.Ports)
	}
	if c.ReadinessProbe.HTTPGet.Path != "/health" || c.ReadinessProbe.TimeoutSeconds != 10 {
		t.Errorf("readiness probe: %v", c.ReadinessProbe)
	}
	if c.LivenessProbe.HTTPGet.Path != "/live" || c.LivenessProbe.TimeoutSeconds != 10 {
		t.Errorf("liveness probe: %v", c.LivenessProbe)
	}
	if got := c.Resources.Requests[corev1.ResourceCPU]; got.String() != "2" {
		t.Errorf("cpu request: %v", c.Resources.Requests)
	}
	if got := c.Resources.Limits[corev1.ResourceMemory]; got.String() != "4Gi" {
		t.Errorf("memory limit: %v", c.Resources.Limits)
	}

	svc := cfg.renderService()
	if len(svc.Spec.Ports) != 2 || svc.Spec.Ports[1].Name != "metrics" ||
		svc.Spec.Ports[1].Port != 9090 {
		t.Errorf("service ports: %v", svc.Spec.Ports)
	}
}

// TestKubeswap_RenderResourcesGPUPriority Verifies explicit --request/--limit entries override the --gpu resources.
func TestKubeswap_RenderResourcesGPUPriority(t *testing.T) {
	cfg := testConfig()                                  // gpu: amd.com/gpu=1
	cfg.Requests = map[string]string{"amd.com/gpu": "2"} // explicit wins
	cfg.Limits = map[string]string{"cpu": "8"}
	dep, err := cfg.renderDeployment()
	if err != nil {
		t.Fatalf("renderDeployment: %v", err)
	}
	r := dep.Spec.Template.Spec.Containers[0].Resources
	if got := r.Requests[corev1.ResourceName("amd.com/gpu")]; got.String() != "2" {
		t.Errorf("gpu request (explicit override): %v", r.Requests)
	}
	if got := r.Limits[corev1.ResourceName("amd.com/gpu")]; got.String() != "1" {
		t.Errorf("gpu limit (from --gpu): %v", r.Limits)
	}
	if got := r.Limits[corev1.ResourceCPU]; got.String() != "8" {
		t.Errorf("cpu limit: %v", r.Limits)
	}
}

// TestKubeswap_RenderResourcesRejectsInvalidQuantity Verifies rendering refuses to paper over an unparseable quantity.
func TestKubeswap_RenderResourcesRejectsInvalidQuantity(t *testing.T) {
	cfg := testConfig()
	cfg.GPUs = map[string]string{"amd.com/gpu": "many"}
	if _, err := cfg.renderResources(); err == nil {
		t.Error("expected error for unparseable GPU quantity")
	}
	cfg = testConfig()
	cfg.Requests = map[string]string{"cpu": "lots"}
	if _, err := cfg.renderResources(); err == nil {
		t.Error("expected error for unparseable request quantity")
	}
}

// TestKubeswap_StartupFailureThreshold Verifies the startup probe failure threshold derives from the startup timeout.
func TestKubeswap_StartupFailureThreshold(t *testing.T) {
	cases := []struct {
		secs int64
		want int32
	}{
		{0, int32(defaultStartupTimeout / 5)},  // unset -> default
		{600, 120},                             // default value
		{30, 6},                                // short load
		{31, 7},                                // rounds up
		{3, 1},                                 // clamped to at least 1
		{-5, int32(defaultStartupTimeout / 5)}, // negative -> default
	}
	for _, tc := range cases {
		c := &serveConfig{StartupTimeout: tc.secs}
		if got := c.startupFailureThreshold(); got != tc.want {
			t.Errorf("startupFailureThreshold(%d) = %d, want %d", tc.secs, got, tc.want)
		}
	}
}

// TestKubeswap_LivenessPathDefault Verifies the liveness path defaults to the readiness path.
func TestKubeswap_LivenessPathDefault(t *testing.T) {
	cfg := testConfig()
	if cfg.livenessPath() != "/health" {
		t.Errorf("livenessPath default: %q", cfg.livenessPath())
	}
	cfg.LivenessPath = "/live"
	if cfg.livenessPath() != "/live" {
		t.Errorf("livenessPath: %q", cfg.livenessPath())
	}
	cfg.ProbeTimeout = 0
	if cfg.probeTimeout() != 5 {
		t.Errorf("probeTimeout default: %d", cfg.probeTimeout())
	}
}

// TestKubeswap_RenderPVC Verifies the PVC rendered for a missing volume (size, class, access mode).
func TestKubeswap_RenderPVC(t *testing.T) {
	cfg := testConfig()
	pvc, err := cfg.renderPVC("llama-swap-models")
	if err != nil {
		t.Fatalf("renderPVC: %v", err)
	}
	if pvc.Spec.StorageClassName == nil || *pvc.Spec.StorageClassName != "local-path" {
		t.Errorf("storage class: %v", pvc.Spec.StorageClassName)
	}
	if got := pvc.Spec.Resources.Requests[corev1.ResourceStorage]; got.String() != "5Gi" {
		t.Errorf("size: %v", got)
	}
	if pvc.Labels[labelModel] != "author-model-tag" {
		t.Errorf("labels: %v", pvc.Labels)
	}
}

// TestKubeswap_DeploymentSpecMatches Verifies the spec comparison detects image, args, command and resource drift.
func TestKubeswap_DeploymentSpecMatches(t *testing.T) {
	cfg := testConfig()
	dep, err := cfg.renderDeployment()
	if err != nil {
		t.Fatal(err)
	}

	// Identical spec matches.
	dep2, _ := cfg.renderDeployment()
	if !deploymentSpecMatches(dep, dep2) {
		t.Error("identical specs should match")
	}

	// Image drift.
	dep2.Spec.Template.Spec.Containers[0].Image = "other:tag"
	if deploymentSpecMatches(dep, dep2) {
		t.Error("image drift should not match")
	}

	// Args drift.
	dep2, _ = cfg.renderDeployment()
	dep2.Spec.Template.Spec.Containers[0].Args = []string{"--model", "/other.gguf"}
	if deploymentSpecMatches(dep, dep2) {
		t.Error("args drift should not match")
	}

	// GPU drift.
	dep2, _ = cfg.renderDeployment()
	dep2.Spec.Template.Spec.Containers[0].Resources.Limits = nil
	if deploymentSpecMatches(dep, dep2) {
		t.Error("resource drift should not match")
	}

	// Command drift.
	dep2, _ = cfg.renderDeployment()
	dep2.Spec.Template.Spec.Containers[0].Command = []string{"other-server"}
	if deploymentSpecMatches(dep, dep2) {
		t.Error("command drift should not match")
	}

	// Liveness probe path drift.
	dep2, _ = cfg.renderDeployment()
	dep2.Spec.Template.Spec.Containers[0].LivenessProbe.HTTPGet.Path = "/other"
	if deploymentSpecMatches(dep, dep2) {
		t.Error("probe path drift should not match")
	}
}

// TestKubeswap_DeploymentSpecMatchesLabels Verifies the spec comparison
// detects drift in the deployment-level labels (the extra --label entries
// land there, so a label change must trigger a --strict replacement).
func TestKubeswap_DeploymentSpecMatchesLabels(t *testing.T) {
	cfg := testConfig()
	cfg.ExtraLabels = map[string]string{"team": "inference"}
	dep, err := cfg.renderDeployment()
	if err != nil {
		t.Fatal(err)
	}

	// Same labels match.
	dep2, _ := cfg.renderDeployment()
	if !deploymentSpecMatches(dep, dep2) {
		t.Error("identical labels should match")
	}

	// An added label is drift.
	dep2.Labels["extra"] = "label"
	if deploymentSpecMatches(dep, dep2) {
		t.Error("added label should not match")
	}

	// A changed value is drift.
	dep2, _ = cfg.renderDeployment()
	dep2.Labels["team"] = "other"
	if deploymentSpecMatches(dep, dep2) {
		t.Error("changed label value should not match")
	}

	// A removed label is drift.
	dep2, _ = cfg.renderDeployment()
	delete(dep2.Labels, "team")
	if deploymentSpecMatches(dep, dep2) {
		t.Error("removed label should not match")
	}
}

// TestKubeswap_RenderDeploymentExtraAnnotations Verifies extra --annotation
// entries land on both the Deployment and the pod template, alongside the
// managed model-id annotation (which the extra entries must not override).
func TestKubeswap_RenderDeploymentExtraAnnotations(t *testing.T) {
	cfg := testConfig()
	cfg.ExtraAnnotations = map[string]string{
		"prometheus.io/scrape": "true",
		"note":                 "v=free form",
	}
	dep, err := cfg.renderDeployment()
	if err != nil {
		t.Fatal(err)
	}
	for _, anns := range []map[string]string{dep.Annotations, dep.Spec.Template.Annotations} {
		if anns["prometheus.io/scrape"] != "true" || anns["note"] != "v=free form" {
			t.Errorf("extra annotations missing: %v", anns)
		}
		if anns[annotationModelID] != "author/model:tag" {
			t.Errorf("model-id annotation must survive: %v", anns)
		}
	}
	// A second render must not share maps with the first.
	dep2, _ := cfg.renderDeployment()
	dep2.Annotations["extra"] = "added"
	if _, ok := dep.Annotations["extra"]; ok {
		t.Error("rendered annotations must be independent copies")
	}
}

// TestKubeswap_DeploymentSpecMatches Verifies the spec comparison detects drift in the rendered annotations (the extra --annotation entries land on the Deployment and the pod template, so a change must trigger a --strict replacement).
func TestKubeswap_DeploymentSpecMatchesAnnotations(t *testing.T) {
	cfg := testConfig()
	cfg.ExtraAnnotations = map[string]string{"team": "inference"}
	dep, err := cfg.renderDeployment()
	if err != nil {
		t.Fatal(err)
	}

	// Same annotations match.
	dep2, _ := cfg.renderDeployment()
	if !deploymentSpecMatches(dep, dep2) {
		t.Error("identical annotations should match")
	}

	// An added deployment-level annotation is drift.
	dep2, _ = cfg.renderDeployment()
	dep2.Annotations["extra"] = "annotation"
	if deploymentSpecMatches(dep, dep2) {
		t.Error("added annotation should not match")
	}

	// A changed value is drift.
	dep2, _ = cfg.renderDeployment()
	dep2.Annotations["team"] = "other"
	if deploymentSpecMatches(dep, dep2) {
		t.Error("changed annotation value should not match")
	}

	// A removed annotation is drift.
	dep2, _ = cfg.renderDeployment()
	delete(dep2.Annotations, "team")
	if deploymentSpecMatches(dep, dep2) {
		t.Error("removed annotation should not match")
	}

	// A pod-template annotation change is drift too.
	dep2, _ = cfg.renderDeployment()
	dep2.Spec.Template.Annotations["team"] = "other"
	if deploymentSpecMatches(dep, dep2) {
		t.Error("changed pod template annotation should not match")
	}
}

// TestKubeswap_RenderDeploymentServiceAccount Verifies --service-account
// lands on the pod spec, and the pod runs with the namespace default when
// the flag is unset.
func TestKubeswap_RenderDeploymentServiceAccount(t *testing.T) {
	cfg := testConfig()
	dep, err := cfg.renderDeployment()
	if err != nil {
		t.Fatal(err)
	}
	if got := dep.Spec.Template.Spec.ServiceAccountName; got != "" {
		t.Errorf("unset --service-account should render empty (namespace default), got %q", got)
	}
	cfg.ServiceAccount = "my-backend"
	dep2, err := cfg.renderDeployment()
	if err != nil {
		t.Fatal(err)
	}
	if got := dep2.Spec.Template.Spec.ServiceAccountName; got != "my-backend" {
		t.Errorf("service account: got %q", got)
	}
}

// TestKubeswap_DeploymentSpecMatchesServiceAccount Verifies the spec
// comparison detects a --service-account change (a drift that must trigger
// a --strict replacement).
func TestKubeswap_DeploymentSpecMatchesServiceAccount(t *testing.T) {
	cfg := testConfig()
	dep, err := cfg.renderDeployment()
	if err != nil {
		t.Fatal(err)
	}
	cfg.ServiceAccount = "my-backend"
	dep2, err := cfg.renderDeployment()
	if err != nil {
		t.Fatal(err)
	}
	if deploymentSpecMatches(dep, dep2) {
		t.Error("service account drift should not match")
	}
}

// TestKubeswap_DeploymentSpecMatchesNodeSelector Verifies the spec comparison detects node-selector drift.
func TestKubeswap_DeploymentSpecMatchesNodeSelector(t *testing.T) {
	cfg := testConfig()
	dep, _ := cfg.renderDeployment()
	dep2, _ := cfg.renderDeployment()
	dep2.Spec.Template.Spec.NodeSelector["other.node.kubernetes.io/label"] = "yes"
	if deploymentSpecMatches(dep, dep2) {
		t.Error("node selector drift should not match")
	}
}

// TestKubeswap_DeploymentSpecMatchesRevisionAnnotation Verifies that the
// rollout controller's own annotations (deployment.kubernetes.io/revision,
// written to the Deployment after a rollout) do not count as drift, while
// kubeswap-owned annotations are still compared.
func TestKubeswap_DeploymentSpecMatchesRevisionAnnotation(t *testing.T) {
	cfg := testConfig()
	dep, _ := cfg.renderDeployment()
	dep2, _ := cfg.renderDeployment()
	dep2.Annotations["deployment.kubernetes.io/revision"] = "3"
	if !deploymentSpecMatches(dep, dep2) {
		t.Error("controller-written revision annotation should not count as drift")
	}
	dep2.Annotations[annotationModelID] = "other-model"
	if deploymentSpecMatches(dep, dep2) {
		t.Error("drift in a kubeswap-owned annotation should not match")
	}
}

// TestKubeswap_DeploymentSpecMatchesTolerations Verifies the spec comparison detects toleration drift.
func TestKubeswap_DeploymentSpecMatchesTolerations(t *testing.T) {
	cfg := testConfig()
	dep, _ := cfg.renderDeployment()
	dep2, _ := cfg.renderDeployment()
	dep2.Spec.Template.Spec.Tolerations[0].Effect = corev1.TaintEffectNoExecute
	if deploymentSpecMatches(dep, dep2) {
		t.Error("toleration drift should not match")
	}

	// Rendered tolerations leave TolerationSeconds nil (tolerate the
	// taint forever). A drifted NoExecute toleration with zero seconds
	// means immediate eviction and must not match, even though both
	// dereference to 0.
	dep2, _ = cfg.renderDeployment()
	zero := int64(0)
	dep2.Spec.Template.Spec.Tolerations[0].Effect = corev1.TaintEffectNoExecute
	dep2.Spec.Template.Spec.Tolerations[0].TolerationSeconds = &zero
	if deploymentSpecMatches(dep, dep2) {
		t.Error("nil vs zero TolerationSeconds should not match")
	}
}

// TestKubeswap_DeploymentSpecMatchesVolumes Verifies the spec comparison detects volume drift.
func TestKubeswap_DeploymentSpecMatchesVolumes(t *testing.T) {
	cfg := testConfig()
	dep, _ := cfg.renderDeployment()
	dep2, _ := cfg.renderDeployment()
	dep2.Spec.Template.Spec.Volumes[0].PersistentVolumeClaim.ClaimName = "other-pvc"
	if deploymentSpecMatches(dep, dep2) {
		t.Error("volume drift should not match")
	}
}

// TestKubeswap_RenderDeploymentNFSVolume Verifies an nfs volume renders its server, export and access mode, and that changing any of them is drift.
func TestKubeswap_RenderDeploymentNFSVolume(t *testing.T) {
	cfg := testConfig()
	cfg.Volumes = []volumeSpec{{Kind: volNFS, Name: "nas.lan/export/models", Path: "/library", ReadOnly: true}}
	dep, err := cfg.renderDeployment()
	if err != nil {
		t.Fatalf("render: %v", err)
	}
	pod := dep.Spec.Template.Spec
	want := corev1.NFSVolumeSource{Server: "nas.lan", Path: "/export/models", ReadOnly: true}
	if got := pod.Volumes[0].NFS; got == nil || *got != want {
		t.Errorf("nfs source = %+v, want %+v", got, want)
	}
	if m := pod.Containers[0].VolumeMounts[0]; m.MountPath != "/library" || !m.ReadOnly {
		t.Errorf("mount = %+v, want read-only /library", m)
	}
	for name, mutate := range map[string]func(*corev1.NFSVolumeSource){
		"server":   func(n *corev1.NFSVolumeSource) { n.Server = "other.lan" },
		"export":   func(n *corev1.NFSVolumeSource) { n.Path = "/export/other" },
		"readOnly": func(n *corev1.NFSVolumeSource) { n.ReadOnly = false },
	} {
		dep2, _ := cfg.renderDeployment()
		mutate(dep2.Spec.Template.Spec.Volumes[0].NFS)
		if deploymentSpecMatches(dep, dep2) {
			t.Errorf("nfs %s drift should not match", name)
		}
	}
}

// TestKubeswap_DeploymentSpecMatchesResourceClaims Verifies the spec comparison detects pod and container resource-claim drift, ignoring order.
func TestKubeswap_DeploymentSpecMatchesResourceClaims(t *testing.T) {
	cfg := testConfig()
	cfg.ResourceClaims = []resourceClaimSpec{{Name: "gpu", Claim: "pro2000"}, {Name: "nic", Claim: "rdma"}}
	dep, _ := cfg.renderDeployment()

	// Reordered claims still match.
	reordered := *cfg
	reordered.ResourceClaims = []resourceClaimSpec{cfg.ResourceClaims[1], cfg.ResourceClaims[0]}
	dep2, _ := reordered.renderDeployment()
	if !deploymentSpecMatches(dep, dep2) {
		t.Error("reordered resource claims should match")
	}

	// A different referenced claim is drift.
	dep2, _ = cfg.renderDeployment()
	other := "pro4000"
	dep2.Spec.Template.Spec.ResourceClaims[0].ResourceClaimName = &other
	if deploymentSpecMatches(dep, dep2) {
		t.Error("referenced claim drift should not match")
	}

	// A claim template in place of the claim is drift.
	dep2, _ = cfg.renderDeployment()
	dep2.Spec.Template.Spec.ResourceClaims[0].ResourceClaimName = nil
	dep2.Spec.Template.Spec.ResourceClaims[0].ResourceClaimTemplateName = &other
	if deploymentSpecMatches(dep, dep2) {
		t.Error("claim template in place of the claim should not match")
	}

	// A removed pod-level claim is drift.
	dep2, _ = cfg.renderDeployment()
	dep2.Spec.Template.Spec.ResourceClaims = dep2.Spec.Template.Spec.ResourceClaims[:1]
	if deploymentSpecMatches(dep, dep2) {
		t.Error("removed pod resource claim should not match")
	}

	// The container no longer naming a claim is drift.
	dep2, _ = cfg.renderDeployment()
	dep2.Spec.Template.Spec.Containers[0].Resources.Claims = dep2.Spec.Template.Spec.Containers[0].Resources.Claims[:1]
	if deploymentSpecMatches(dep, dep2) {
		t.Error("removed container resource claim should not match")
	}

	// A container claim narrowed to one request is drift.
	dep2, _ = cfg.renderDeployment()
	dep2.Spec.Template.Spec.Containers[0].Resources.Claims[0].Request = "gpu-0"
	if deploymentSpecMatches(dep, dep2) {
		t.Error("container claim request drift should not match")
	}

	// A deployment created before --resource-claim was added is drift.
	cfg.ResourceClaims = nil
	dep2, _ = cfg.renderDeployment()
	if deploymentSpecMatches(dep, dep2) || deploymentSpecMatches(dep2, dep) {
		t.Error("added resource claims should not match")
	}
}

// TestKubeswap_DeploymentSpecMatchesServicePorts Verifies the spec comparison detects service-port drift.
func TestKubeswap_DeploymentSpecMatchesServicePorts(t *testing.T) {
	cfg := testConfig()
	cfg.ServicePorts = []servicePortSpec{{Name: "metrics", Port: 9090}}
	dep, _ := cfg.renderDeployment()
	dep2, _ := cfg.renderDeployment()
	dep2.Spec.Template.Spec.Containers[0].Ports[1].ContainerPort = 9091
	if deploymentSpecMatches(dep, dep2) {
		t.Error("service port drift should not match")
	}
}

// TestKubeswap_DeploymentSpecMatchesStartupTimeout Verifies the spec comparison detects startup-timeout drift.
func TestKubeswap_DeploymentSpecMatchesStartupTimeout(t *testing.T) {
	cfg := testConfig()
	cfg.StartupTimeout = 600
	dep, _ := cfg.renderDeployment()
	dep2, _ := cfg.renderDeployment()
	dep2.Spec.Template.Spec.Containers[0].StartupProbe.FailureThreshold = 1
	if deploymentSpecMatches(dep, dep2) {
		t.Error("startup timeout drift should not match")
	}
}

// TestKubeswap_DeploymentSpecMatchesProbePort Verifies the spec comparison detects probe-port drift.
func TestKubeswap_DeploymentSpecMatchesProbePort(t *testing.T) {
	cfg := testConfig()
	dep, _ := cfg.renderDeployment()
	dep2, _ := cfg.renderDeployment()
	dep2.Spec.Template.Spec.Containers[0].ReadinessProbe.HTTPGet.Port.IntVal = 9999
	if deploymentSpecMatches(dep, dep2) {
		t.Error("readiness probe port drift should not match")
	}
	dep2, _ = cfg.renderDeployment()
	dep2.Spec.Template.Spec.Containers[0].LivenessProbe.HTTPGet.Port.IntVal = 9999
	if deploymentSpecMatches(dep, dep2) {
		t.Error("liveness probe port drift should not match")
	}
}

// TestKubeswap_DeploymentSpecMatchesProbeTimeout Verifies the spec comparison detects probe-timeout drift.
func TestKubeswap_DeploymentSpecMatchesProbeTimeout(t *testing.T) {
	cfg := testConfig()
	dep, _ := cfg.renderDeployment()
	dep2, _ := cfg.renderDeployment()
	dep2.Spec.Template.Spec.Containers[0].ReadinessProbe.TimeoutSeconds = 40
	if deploymentSpecMatches(dep, dep2) {
		t.Error("readiness probe timeout drift should not match")
	}
	dep2, _ = cfg.renderDeployment()
	dep2.Spec.Template.Spec.Containers[0].LivenessProbe.TimeoutSeconds = 40
	if deploymentSpecMatches(dep, dep2) {
		t.Error("liveness probe timeout drift should not match")
	}
}

// TestKubeswap_DeploymentSpecMatchesGracePeriod Verifies the spec comparison detects grace-period drift.
func TestKubeswap_DeploymentSpecMatchesProbeInitialDelay(t *testing.T) {
	cfg := testConfig()
	dep, _ := cfg.renderDeployment()
	dep2, _ := cfg.renderDeployment()
	dep2.Spec.Template.Spec.Containers[0].ReadinessProbe.InitialDelaySeconds = 99
	if deploymentSpecMatches(dep, dep2) {
		t.Error("readiness probe initial delay drift should not match")
	}
	dep2, _ = cfg.renderDeployment()
	dep2.Spec.Template.Spec.Containers[0].LivenessProbe.InitialDelaySeconds = 99
	if deploymentSpecMatches(dep, dep2) {
		t.Error("liveness probe initial delay drift should not match")
	}
}

// TestKubeswap_StringMapEqualMissingKeys verifies that keys missing from
// the second map are not compared against the zero value.
func TestKubeswap_StringMapEqualMissingKeys(t *testing.T) {
	if stringMapEqual(map[string]string{"x": ""}, map[string]string{"y": ""}) {
		t.Error("same-length maps with different keys and empty values should not be equal")
	}
	if stringMapEqual(map[string]string{"x": "1"}, map[string]string{"y": "1"}) {
		t.Error("same-length maps with different keys should not be equal")
	}
	if !stringMapEqual(map[string]string{"x": "1"}, map[string]string{"x": "1"}) {
		t.Error("identical maps should be equal")
	}
}

// TestKubeswap_HelperEqualMissingKeys verifies that the remaining spec
// comparison helpers do not treat a missing key as its zero value.
func TestKubeswap_HelperEqualMissingKeys(t *testing.T) {
	// envs: empty values are legal (--env FOO=), so different names with
	// empty values must not compare equal.
	if envsEqual(
		[]corev1.EnvVar{{Name: "FOO", Value: ""}},
		[]corev1.EnvVar{{Name: "BAR", Value: ""}},
	) {
		t.Error("envs with different names and empty values should not be equal")
	}
	if !envsEqual(
		[]corev1.EnvVar{{Name: "FOO", Value: ""}},
		[]corev1.EnvVar{{Name: "FOO", Value: ""}},
	) {
		t.Error("identical envs should be equal")
	}
	// ports: a missing name must not compare against port 0.
	if portsEqual(
		[]corev1.ContainerPort{{Name: "a", ContainerPort: 1}},
		[]corev1.ContainerPort{{Name: "b", ContainerPort: 1}},
	) {
		t.Error("ports with different names should not be equal")
	}
	// mounts: a missing name must not compare against an empty path.
	if mountsEqual(
		[]corev1.VolumeMount{{Name: "a", MountPath: "/x"}},
		[]corev1.VolumeMount{{Name: "b", MountPath: "/x"}},
	) {
		t.Error("mounts with different names should not be equal")
	}
	// resources: a missing name must not compare against the zero quantity.
	zero := resource.MustParse("0")
	if resourceListEqual(
		corev1.ResourceList{"cpu": zero},
		corev1.ResourceList{"memory": zero},
	) {
		t.Error("resource lists with different names and zero quantities should not be equal")
	}
}

func TestKubeswap_DeploymentSpecMatchesGracePeriod(t *testing.T) {
	cfg := testConfig()
	dep, _ := cfg.renderDeployment()
	dep2, _ := cfg.renderDeployment()
	grace := int64(90)
	dep2.Spec.Template.Spec.TerminationGracePeriodSeconds = &grace
	if deploymentSpecMatches(dep, dep2) {
		t.Error("grace period drift should not match")
	}
}
