//go:build !windows

package config

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"golang.org/x/sys/unix"
)

func validateStorePath(key, path string) error {
	if strings.TrimSpace(path) == "" {
		return fmt.Errorf("%s must not be empty", key)
	}

	if info, err := os.Stat(path); err != nil {
		if !os.IsNotExist(err) {
			return fmt.Errorf("%s: %w", key, err)
		}
		// File does not exist; ensure the parent directory is writable.
		dir := filepath.Dir(path)
		if err := unix.Access(dir, unix.W_OK); err != nil {
			return fmt.Errorf("%s: directory %s is not writable: %w", key, dir, err)
		}
		return nil
	} else if info.IsDir() {
		return fmt.Errorf("%s: %s is a directory, not a file", key, path)
	}

	// File exists; ensure it is writable.
	if err := unix.Access(path, unix.W_OK); err != nil {
		return fmt.Errorf("%s: %s is not writable: %w", key, path, err)
	}
	return nil
}
