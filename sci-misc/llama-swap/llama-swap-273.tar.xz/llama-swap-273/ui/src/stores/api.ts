import { writable, derived } from "svelte/store";
import type {
  Model,
  ActivityPage,
  ActivityStatsData,
  VersionInfo,
  APIEventEnvelope,
  ReqRespCapture,
  InFlightStats,
  InflightRequestEntry,
  PerformanceResponse,
  UIConfig,
  Profile,
  ProfileState,
  PlaygroundModelType,
  HardwareSnapshot,
  TailcatStatus,
} from "../lib/types";
import { appendActivityFilters, type ActivityFilters } from "../lib/activityFilters";
import { apiUrl } from "../lib/apiPath";
import { connectionState } from "./theme";

// Stores
export const models = writable<Model[]>([]);
export const playgroundModels = writable<Model[]>([]);
export const profiles = writable<Profile[]>([]);
export const activeProfile = writable<string | null>(null);
/** True while inference is paused: the server rejects requests for local models. */
export const inferencePaused = writable<boolean>(false);

// Model records used by Playground come from the OpenAI-compatible listing.
export const profileModels = derived(
  playgroundModels,
  ($playgroundModels) => $playgroundModels.filter((model) => model.playgroundType === "profile"),
);
export const selectorModels = derived(
  playgroundModels,
  ($playgroundModels) => $playgroundModels.filter((model) => model.playgroundType === "selector"),
);

export const hasListedModels = derived(playgroundModels, ($playgroundModels) => $playgroundModels.length > 0);
export const activityRevision = writable<number>(0);
export const inFlightRequests = writable<number>(0);
export const inflightRequestEntries = writable<InflightRequestEntry[]>([]);
const defaultUIConfig = (): UIConfig => ({
  activity: { session_id: ["X-Session-ID", "X-Litellm-Session-Id"] },
  helpagent: { disable: false },
});
export const uiConfig = writable<UIConfig>(defaultUIConfig());
/** False when the config sets helpagent.disable, which hides the Help page. */
export const helpAgentEnabled = derived(uiConfig, ($uiConfig) => !$uiConfig.helpagent?.disable);
export const performanceEnabled = writable<boolean>(false);
export const tailcatStatus = writable<TailcatStatus>({ enabled: false, address: "", models: [] });
export const versionInfo = writable<VersionInfo>({
  build_date: "unknown",
  commit: "unknown",
  version: "unknown",
});

let apiEventSource: EventSource | null = null;
let profileRevision = 0;
// Bumped by every pause/resume request and pauseChanged event, so an HTTP
// response that arrives after newer state cannot overwrite it.
let pauseRevision = 0;
let playgroundModelsRequest = 0;
let playgroundModelsFetch: Promise<Model[]> | null = null;
let playgroundModelsRefreshQueued = false;

export function enableAPIEvents(enabled: boolean): void {
  if (!enabled) {
    apiEventSource?.close();
    apiEventSource = null;
    activityRevision.set(0);
    inFlightRequests.set(0);
    inflightRequestEntries.set([]);
    uiConfig.set(defaultUIConfig());
    playgroundModelsRequest++;
    playgroundModelsRefreshQueued = false;
    playgroundModels.set([]);
    profiles.set([]);
    activeProfile.set(null);
    profileRevision++;
    pauseRevision++;
    inferencePaused.set(false);
    return;
  }

  let retryCount = 0;
  const initialDelay = 1000; // 1 second

  const connect = () => {
    apiEventSource?.close();
    apiEventSource = new EventSource(apiUrl("/api/events"));

    connectionState.set("connecting");

    apiEventSource.onopen = () => {
      // Clear everything on connect to keep things in sync
      activityRevision.update((n) => n + 1);
      inFlightRequests.set(0);
      inflightRequestEntries.set([]);
      uiConfig.set(defaultUIConfig());
      models.set([]);
      playgroundModelsRequest++;
      playgroundModelsRefreshQueued = false;
      playgroundModels.set([]);
      profiles.set([]);
      activeProfile.set(null);
      profileRevision++;
      pauseRevision++;
      inferencePaused.set(false);
      retryCount = 0;
      connectionState.set("connected");
      void fetchProfiles().catch((error) => console.error(error));
      void fetchTailcatStatus().catch((error) => console.error(error));
    };

    apiEventSource.onmessage = (e: MessageEvent) => {
      try {
        handleAPIEventMessage(e.data);
      } catch (err) {
        console.error(e.data, err);
      }
    };

    apiEventSource.onerror = () => {
      apiEventSource?.close();
      retryCount++;
      const delay = Math.min(initialDelay * Math.pow(2, retryCount - 1), 5000);
      connectionState.set("disconnected");
      setTimeout(connect, delay);
    };
  };

  connect();
}

export function handleAPIEventMessage(data: string): void {
  const message = JSON.parse(data) as APIEventEnvelope;
  switch (message.type) {
    case "modelStatus": {
      const receivedAt = Date.now();
      const newModels = (JSON.parse(message.data) as Model[]).map((m) =>
        m.uptimeMs !== undefined ? { ...m, readyAt: receivedAt - m.uptimeMs } : m,
      );
      // Sort models by name and id
      newModels.sort((a, b) => {
        return (a.name + a.id).localeCompare(b.name + b.id, undefined, { numeric: true });
      });
      models.set(newModels);
      break;
    }

    case "activity": {
      activityRevision.update((n) => n + 1);
      break;
    }

    case "inflight": {
      const stats = JSON.parse(message.data) as InFlightStats;
      const withReceiptTime = (request: InflightRequestEntry): InflightRequestEntry => ({
        ...request,
        client_received_at_ms: performance.now(),
      });
      inflightRequestEntries.update((current) => {
        let requests = current;
        switch (stats.operation) {
          case "snapshot":
            requests = (stats.requests ?? []).map(withReceiptTime);
            break;
          case "upsert": {
            if (!stats.request) break;
            const received = withReceiptTime(stats.request);
            const index = current.findIndex((request) => request.id === received.id);
            requests = index === -1
              ? [...current, received]
              : current.map((request, i) => i === index ? received : request);
            break;
          }
          case "remove":
            requests = current.filter((request) => request.id !== stats.id);
            break;
        }
        requests.sort((a, b) => {
          const byTime = Date.parse(a.timestamp) - Date.parse(b.timestamp);
          return byTime || a.id.localeCompare(b.id, undefined, { numeric: true });
        });
        inFlightRequests.set(requests.length);
        return requests;
      });
      break;
    }

    case "uiConfig": {
      uiConfig.set(JSON.parse(message.data) as UIConfig);
      break;
    }

    case "profileChanged": {
      const state = JSON.parse(message.data) as Pick<ProfileState, "active">;
      profileRevision++;
      activeProfile.set(state.active);
      break;
    }

    case "pauseChanged": {
      const state = JSON.parse(message.data) as { paused: boolean };
      pauseRevision++;
      inferencePaused.set(state.paused);
      break;
    }
  }
}

export async function fetchProfiles(): Promise<ProfileState> {
  const revision = profileRevision;
  const response = await fetch(apiUrl("/api/profiles"));
  if (!response.ok) {
    throw new Error(`Failed to list profiles: ${response.status}`);
  }
  const state = await response.json() as ProfileState;
  profiles.set(state.profiles);
  if (profileRevision === revision) activeProfile.set(state.active);
  return state;
}

export async function setActiveProfile(name: string | null): Promise<void> {
  const revision = profileRevision;
  const response = await fetch(apiUrl("/api/profiles/active"), {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name }),
  });
  if (!response.ok) {
    throw new Error(`Failed to switch profile: ${response.status}`);
  }
  const state = await response.json() as Pick<ProfileState, "active">;
  if (profileRevision === revision) activeProfile.set(state.active);
}

// Fetch version info when connected
connectionState.subscribe(async (status) => {
  if (status === "connected") {
    try {
      const response = await fetch(apiUrl("/api/version"));
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data: VersionInfo = await response.json();
      versionInfo.set(data);
    } catch (error) {
      console.error(error);
    }
  }
});

interface ModelListRecord {
  id: string;
  name?: string;
  description?: string;
  capabilities?: Model["capabilities"];
  architecture?: {
    input_modalities?: string[];
    output_modalities?: string[];
  };
  context_length?: number;
  meta?: {
    llamaswap?: {
      type?: PlaygroundModelType | "alias";
      aliases?: string[];
      modelID?: string;
      peerID?: string;
      strategy?: string;
      targets?: string[];
      spillover?: number;
      no_evict?: boolean;
    };
  };
}

async function loadPlaygroundModels(request: number): Promise<Model[]> {
  try {
    const response = await fetch(apiUrl("/v1/models"));
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const responseData = await response.json() as { data?: ModelListRecord[] };
    const records = responseData.data ?? [];
    const aliasesByModel = new Map<string, Set<string>>();
    for (const record of records) {
      const metadata = record.meta?.llamaswap;
      if (metadata?.aliases) {
        aliasesByModel.set(record.id, new Set(metadata.aliases));
      }
      if (metadata?.type === "alias" && metadata.modelID) {
        const aliases = aliasesByModel.get(metadata.modelID) ?? new Set<string>();
        aliases.add(record.id);
        aliasesByModel.set(metadata.modelID, aliases);
      }
    }
    const newModels = records
      .filter((record) => record.meta?.llamaswap?.type !== "alias")
      .map((record): Model => {
        const metadata = record.meta?.llamaswap;
        const metadataType = metadata?.type;
        const playgroundType: PlaygroundModelType = metadataType && metadataType !== "alias"
          ? metadataType
          : "model";
        return {
          id: record.id,
          state: "unknown",
          name: record.name ?? "",
          description: record.description ?? "",
          unlisted: false,
          peerID: metadata?.peerID ?? "",
          playgroundType,
          aliases: [...(aliasesByModel.get(record.id) ?? [])],
          capabilities: record.capabilities,
          modalities: {
            in: record.architecture?.input_modalities ?? [],
            out: record.architecture?.output_modalities ?? [],
          },
          context_length: record.context_length,
          strategy: metadata?.strategy,
          targets: metadata?.targets ?? [],
          spillover: metadata?.spillover,
          noEvict: metadata?.no_evict,
        };
      });
    newModels.sort((a, b) => {
      return (a.name + a.id).localeCompare(b.name + b.id, undefined, { numeric: true });
    });
    if (request === playgroundModelsRequest) playgroundModels.set(newModels);
    return newModels;
  } catch (error) {
    console.error("Failed to fetch Playground models:", error);
    return [];
  }
}

export function fetchPlaygroundModels(): Promise<Model[]> {
  if (playgroundModelsFetch) {
    playgroundModelsRefreshQueued = true;
    return playgroundModelsFetch;
  }

  const request = ++playgroundModelsRequest;
  const currentFetch = loadPlaygroundModels(request).finally(() => {
    if (playgroundModelsFetch !== currentFetch) return;
    playgroundModelsFetch = null;
    if (playgroundModelsRefreshQueued) {
      playgroundModelsRefreshQueued = false;
      void fetchPlaygroundModels();
    }
  });
  playgroundModelsFetch = currentFetch;
  return currentFetch;
}

export async function getActivity(params: {
  model?: string;
  page?: number;
  limit?: number;
  sort?: string;
  order?: "asc" | "desc";
  filters?: ActivityFilters;
  srcPrefix?: string;
} = {}): Promise<ActivityPage> {
  const query = new URLSearchParams();
  if (params.model) query.set("model", params.model);
  if (params.page) query.set("page", String(params.page));
  if (params.limit) query.set("limit", String(params.limit));
  if (params.sort) query.set("sort", params.sort);
  if (params.order) query.set("order", params.order);
  if (params.srcPrefix) query.set("src_prefix", params.srcPrefix);
  // Drawer filters only ever add id bounds, so they never conflict with a
  // model pinned above. The API also accepts repeated "model" params and
  // start/end timestamps, which no UI control currently produces.
  if (params.filters) appendActivityFilters(query, params.filters);
  const url = query.size > 0 ? `/api/metrics/activity?${query}` : "/api/metrics/activity";

  const response = await fetch(apiUrl(url));
  if (!response.ok) {
    throw new Error(`Failed to fetch activity: ${response.status}`);
  }
  return await response.json();
}

export async function fetchTailcatStatus(): Promise<TailcatStatus> {
  const response = await fetch(apiUrl("/api/tailcat"));
  if (!response.ok) {
    throw new Error(`Failed to fetch Tailcat status: ${response.status}`);
  }
  const status = await response.json() as TailcatStatus;
  tailcatStatus.set(status);
  return status;
}

export async function getActivityStats(model?: string): Promise<ActivityStatsData> {
  const query = new URLSearchParams();
  if (model) query.set("model", model);
  const url = query.size > 0 ? `/api/metrics/stats?${query}` : "/api/metrics/stats";

  const response = await fetch(apiUrl(url));
  if (!response.ok) {
    throw new Error(`Failed to fetch activity stats: ${response.status}`);
  }
  return await response.json();
}

export async function unloadAllModels(): Promise<void> {
  try {
    const response = await fetch(apiUrl(`/api/models/unload`), {
      method: "POST",
    });
    if (!response.ok) {
      throw new Error(`Failed to unload models: ${response.status}`);
    }
  } catch (error) {
    console.error("Failed to unload models:", error);
    throw error;
  }
}

/** Pauses inference and unloads every local model. */
export async function pauseInference(): Promise<void> {
  await setInferencePaused(true);
}

export async function resumeInference(): Promise<void> {
  await setInferencePaused(false);
}

async function setInferencePaused(paused: boolean): Promise<void> {
  const action = paused ? "pause" : "resume";
  const revision = ++pauseRevision;
  const response = await fetch(apiUrl(`/api/models/${action}`), { method: "POST" });
  if (!response.ok) {
    throw new Error(`Failed to ${action} inference: ${response.status}`);
  }
  const state = await response.json() as { paused: boolean };
  // A pause blocks until every model stops, so a resume can be sent and
  // answered, and its event delivered, before the pause returns.
  if (pauseRevision === revision) inferencePaused.set(state.paused);
}

export async function unloadSingleModel(model: string): Promise<void> {
  try {
    const response = await fetch(apiUrl(`/api/models/unload/${model}`), {
      method: "POST",
    });
    if (!response.ok) {
      throw new Error(`Failed to unload model: ${response.status}`);
    }
  } catch (error) {
    console.error("Failed to unload model", model, error);
    throw error;
  }
}

export async function cancelInflightRequest(id: string): Promise<void> {
  try {
    const response = await fetch(apiUrl(`/api/inflight/${encodeURIComponent(id)}/cancel`), {
      method: "POST",
    });
    if (!response.ok) {
      throw new Error(`Failed to cancel request: ${response.status}`);
    }
  } catch (error) {
    console.error("Failed to cancel inflight request", id, error);
    throw error;
  }
}

export async function loadModel(model: string, signal?: AbortSignal): Promise<void> {
  try {
    const response = await fetch(apiUrl(`/upstream/${model}/?_=${Date.now()}`), {
      method: "GET",
      signal,
    });
    if (!response.ok) {
      throw new Error(`Failed to load model: ${response.status}`);
    }
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") {
      return;
    }
    console.error("Failed to load model:", error);
    throw error;
  }
}

export async function getCapture(captureId: string): Promise<ReqRespCapture | null> {
  try {
    const response = await fetch(apiUrl(`/api/captures/${encodeURIComponent(captureId)}`));
    if (response.status === 404) {
      return null;
    }
    if (!response.ok) {
      throw new Error(`Failed to fetch capture: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error("Failed to fetch capture:", error);
    return null;
  }
}

export async function checkPerformanceEnabled(): Promise<void> {
  try {
    const response = await fetch(apiUrl("/api/performance"));
    if (!response.ok) {
      performanceEnabled.set(false);
      return;
    }
    const data = await response.json();
    performanceEnabled.set(data.enabled);
  } catch {
    performanceEnabled.set(false);
  }
}

export async function fetchPerformance(after?: string): Promise<PerformanceResponse | null> {
  try {
    const url = after ? `/api/performance?after=${encodeURIComponent(after)}` : "/api/performance";
    const response = await fetch(apiUrl(url));
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error("Failed to fetch performance data:", error);
    return null;
  }
}

export async function getHardware(): Promise<HardwareSnapshot> {
  const response = await fetch(apiUrl("/api/hardware"));
  if (!response.ok) {
    throw new Error(`Failed to fetch hardware: ${response.status}`);
  }
  return await response.json() as HardwareSnapshot;
}
